#Application Overview

Veo Integration extractor is a worker, that runs every day and extracts the data directly from
Postgres database managed by Heroku Connect, creates an XML message and puts it into RabbitMQ.
With every run, it performs 4 kinds of jobs:
1. Master load - performed once, when deployed.
2. Inital load for new plan - worker checks if there is any new Plan starting by the time worker is running.
3. Delta Load 1 - worker checks if there is any change in Product Group Detail table within active plan.
4. Delta Load 2 - worker checks if there is any change in Product Master table within active plan.

## Deployment instructions

###Dependencies

1. Attached Postgres database (with unique database user eg. ```veo_integration```)
2. Attached CloudAMQP add-on (RabbitMQ)

###Heroku app configuration

1. Create app in space with name of ```bat-app-veo-message-ext```
2. Set up environment variables:
    * ```SCHEDULE_CRON_EXPRESSION = 0 0 1 * * *``` - run everyday at minute past midnight
    * ```FORCE_MASTER_LOAD=false``` - forcing to perform master-load
    Provided vars by add-ons:
    * ```DATABASE_URL```
    * ```PAPERTRAIL_API_TOKEN```
    * ```CLOUDAMQP_APIKEY```
    * ```CLOUDAMQP_URL```
