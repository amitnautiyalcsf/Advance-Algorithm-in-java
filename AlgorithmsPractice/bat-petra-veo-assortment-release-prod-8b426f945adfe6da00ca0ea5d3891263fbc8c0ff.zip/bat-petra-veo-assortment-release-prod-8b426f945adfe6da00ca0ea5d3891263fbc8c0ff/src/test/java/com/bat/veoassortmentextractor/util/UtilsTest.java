package com.bat.veoassortmentextractor.util;

import org.junit.jupiter.api.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

import static org.junit.jupiter.api.Assertions.*;

class UtilsTest {

    @Test
    void trimLeadingZeros() {
        String testData = "0000-rest string";
        String trimmingResult = Utils.trimLeadingZeros(testData);

        assertEquals("-rest string", trimmingResult);

        testData = "not trimmed";
        trimmingResult = Utils.trimLeadingZeros(testData);
        assertEquals(testData, trimmingResult);

        testData = "000000";
        trimmingResult = Utils.trimLeadingZeros(testData);
        assertEquals("", trimmingResult);
    }

    @Test
    void trimZerosFromEmptyObject() {
        String testData = "";
        String trimmingResult = Utils.trimLeadingZeros(testData);

        assertEquals("", trimmingResult);
    }

    @Test
    void trimLeadingChars() {
        char charToTrim = '0';
        String testData = "" + charToTrim + charToTrim + "alibaba";
        String trimmingResult = Utils.trimLeadingChars(testData, charToTrim);
        assertEquals("alibaba", trimmingResult);

        testData = "" + charToTrim + charToTrim + charToTrim;
        trimmingResult = Utils.trimLeadingChars(testData, charToTrim);
        assertEquals("", trimmingResult);

        // trying other chars
        charToTrim = 'a';
        testData = "aaalala ma kota";
        trimmingResult = Utils.trimLeadingChars(testData, charToTrim);
        assertEquals("lala ma kota", trimmingResult);
    }

    @SuppressWarnings("unchecked")
    @Test
    void utilsCreationTest() {
        final int numberOfAllDeclaredConstructors = 1;
        Constructor<Utils>[] utilsConstructors = (Constructor<Utils>[]) Utils.class.getDeclaredConstructors();
        assertEquals(utilsConstructors.length, numberOfAllDeclaredConstructors);

        final int defaultConstructorParametersNumber = 0;
        Constructor<Utils> shouldBeDefaultOne = utilsConstructors[0];
        assertEquals(shouldBeDefaultOne.getParameterCount(), defaultConstructorParametersNumber);

        InvocationTargetException exception = assertThrows(InvocationTargetException.class, () -> {
            shouldBeDefaultOne.setAccessible(true);
            shouldBeDefaultOne.newInstance();
        });

        assertSame(exception.getCause().getClass(), UnsupportedOperationException.class);
        assertEquals("This class shouldn't be instantiated directly", exception.getCause().getMessage());
    }
}