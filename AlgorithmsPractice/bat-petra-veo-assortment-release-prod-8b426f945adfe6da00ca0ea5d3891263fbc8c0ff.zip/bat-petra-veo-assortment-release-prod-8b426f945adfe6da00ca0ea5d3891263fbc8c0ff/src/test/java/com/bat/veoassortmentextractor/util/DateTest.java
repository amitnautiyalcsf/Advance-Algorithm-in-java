package com.bat.veoassortmentextractor.util;

import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DateTest {

    @Test
    public void sortDates() {
        List<LocalDateTime> dates = Arrays.asList(
                LocalDateTime.of(2013, 10, 12,10, 10),
                LocalDateTime.of(2011, 10, 12,10, 10),
                LocalDateTime.of(2012, 10, 12,10, 10)
        );

        Collections.sort(dates);
        System.out.println(dates);

        Collections.sort(dates, Comparator.reverseOrder());
        System.out.println(dates);
    }
}
