package com.bat.veoassortmentextractor.services;

import com.bat.veoassortmentextractor.repositories.PlanRepository;
import com.bat.veoassortmentextractor.soap.AssortmentImportRequest;
import com.bat.veoassortmentextractor.soap.Customer;
import com.bat.veoassortmentextractor.soap.Customers;
import com.bat.veoassortmentextractor.soap.Products;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.math.BigInteger;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;


@SpringBootTest
class ExtractorServiceImplTest {

    @Autowired
    ExtractorService extractorService;

    @DisplayName("Should prepare valid xml document")
    @Test
    void shouldPrepareValidXmlDocument() {
        AssortmentImportRequest request = createMockData();
        assertNotNull(extractorService, "Extractor is null");
        String xmlPayload = extractorService.convertToXml(request);
        assertEquals(getValidXml(), xmlPayload);
    }

    private AssortmentImportRequest createMockData() {
        AssortmentImportRequest request = new AssortmentImportRequest();
        request.setMARKETIDENTIFIER("BR");
        Customers customers = new Customers();

        Customer customer = new Customer();
        customer.setSOLDTOERPNUMBER("123");

        Products products = new Products();
        products.setDROPCHILDREN(Boolean.TRUE);
        com.bat.veoassortmentextractor.soap.Product xmlProduct = new com.bat.veoassortmentextractor.soap.Product();
        xmlProduct.setMATERIALNUMBER("PROD123");
        xmlProduct.setUNITOFMEASURE("C");
        xmlProduct.setSELLIN(Boolean.FALSE);
        xmlProduct.setTACTICAL(Boolean.TRUE);
        xmlProduct.setSTRATEGIC(Boolean.FALSE);
        xmlProduct.setFEATURED(Boolean.FALSE);
        xmlProduct.setSEQUENCEID(new BigInteger("1"));
        xmlProduct.setHALFCARTON("f");
        products.getPRODUCT().add(xmlProduct);

        customers.setCUSTOMER(customer);
        customer.setPRODUCTS(products);

        request.setCUSTOMERS(customers);

        return request;
    }

    private String getValidXml(){
        return "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
                "<assortmentImportRequest xmlns=\"http://veo.bat.biz/v2/veoAssortmentSchema\">" +
                "<MARKET_IDENTIFIER>BR</MARKET_IDENTIFIER><CUSTOMERS><CUSTOMER><SOLD_TO_ERP_NUMBER>123</SOLD_TO_ERP_NUMBER>" +
                "<PRODUCTS DROP_CHILDREN=\"false\"><PRODUCT><MATERIAL_NUMBER>PROD123</MATERIAL_NUMBER>" +
                "<UNIT_OF_MEASURE>C</UNIT_OF_MEASURE><SELL_IN>false</SELL_IN><TACTICAL>true</TACTICAL>" +
                "<STRATEGIC>false</STRATEGIC><FEATURED>false</FEATURED><SEQUENCE_ID>1</SEQUENCE_ID>" +
                "<HALF_CARTON>f</HALF_CARTON></PRODUCT></PRODUCTS></CUSTOMER></CUSTOMERS></assortmentImportRequest>";
    }

}