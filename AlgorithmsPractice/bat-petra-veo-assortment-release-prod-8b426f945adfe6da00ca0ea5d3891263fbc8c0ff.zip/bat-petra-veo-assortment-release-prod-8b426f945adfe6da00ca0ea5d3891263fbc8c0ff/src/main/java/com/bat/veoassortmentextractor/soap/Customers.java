
package com.bat.veoassortmentextractor.soap;

import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Customers complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Customers">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="CUSTOMER" type="{http://veo.bat.biz/v2/veoAssortmentSchema}Customer"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Customers", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", propOrder = {
    "customer"
})
@Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
public class Customers {

    @XmlElement(name = "CUSTOMER", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", required = true)
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected Customer customer;

    /**
     * Gets the value of the customer property.
     * 
     * @return
     *     possible object is
     *     {@link Customer }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public Customer getCUSTOMER() {
        return customer;
    }

    /**
     * Sets the value of the customer property.
     * 
     * @param value
     *     allowed object is
     *     {@link Customer }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setCUSTOMER(Customer value) {
        this.customer = value;
    }

}
