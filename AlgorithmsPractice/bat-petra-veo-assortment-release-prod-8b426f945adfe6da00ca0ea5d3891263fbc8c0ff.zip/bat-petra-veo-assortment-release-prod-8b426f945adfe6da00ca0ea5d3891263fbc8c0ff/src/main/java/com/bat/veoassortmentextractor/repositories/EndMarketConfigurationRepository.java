package com.bat.veoassortmentextractor.repositories;

import com.bat.veoassortmentextractor.model.EndMarketConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EndMarketConfigurationRepository extends JpaRepository<EndMarketConfiguration, String> {

    List<EndMarketConfiguration> findAllByRecordType_Name(String name);
}
