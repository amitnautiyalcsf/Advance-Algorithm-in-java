package com.bat.veoassortmentextractor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeoAssortmentExtractorApplication {

    public static void main(String[] args) {
        SpringApplication.run(VeoAssortmentExtractorApplication.class, args);
    }

}
