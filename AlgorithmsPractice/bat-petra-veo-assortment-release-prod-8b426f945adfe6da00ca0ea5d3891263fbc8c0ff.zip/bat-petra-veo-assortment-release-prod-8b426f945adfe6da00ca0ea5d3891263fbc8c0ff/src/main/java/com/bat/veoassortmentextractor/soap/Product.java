
package com.bat.veoassortmentextractor.soap;

import java.math.BigInteger;
import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Product complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Product">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MATERIAL_NUMBER" type="{http://veo.bat.biz/v2/veoAssortmentSchema}NonEmptyString"/>
 *         &lt;element name="UNIT_OF_MEASURE" type="{http://veo.bat.biz/v2/veoAssortmentSchema}NonEmptyString" minOccurs="0"/>
 *         &lt;element name="SELL_IN" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="TACTICAL" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="STRATEGIC" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="FEATURED" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="SEQUENCE_ID" type="{http://www.w3.org/2001/XMLSchema}integer" minOccurs="0"/>
 *         &lt;element name="HALF_CARTON" type="{http://veo.bat.biz/v2/veoAssortmentSchema}EmptyHalfCartoon" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="DELTA_MODE" type="{http://veo.bat.biz/v2/veoAssortmentSchema}DeltaMode" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Product", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", propOrder = {
    "materialnumber",
    "unitofmeasure",
    "sellin",
    "tactical",
    "strategic",
    "featured",
    "sequenceid",
    "halfcarton"
})
@Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
public class Product {

    @XmlElement(name = "MATERIAL_NUMBER", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", required = true)
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected String materialnumber;
    @XmlElement(name = "UNIT_OF_MEASURE", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema")
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected String unitofmeasure;
    @XmlElement(name = "SELL_IN", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema")
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected boolean sellin;
    @XmlElement(name = "TACTICAL", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema")
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected boolean tactical;
    @XmlElement(name = "STRATEGIC", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema")
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected boolean strategic;
    @XmlElement(name = "FEATURED", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema")
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected boolean featured;
    @XmlElement(name = "SEQUENCE_ID", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema")
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected BigInteger sequenceid;
    @XmlElement(name = "HALF_CARTON", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema")
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected String halfcarton;
    @XmlAttribute(name = "DELTA_MODE")
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected DeltaMode deltamode;

    /**
     * Gets the value of the materialnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public String getMATERIALNUMBER() {
        return materialnumber;
    }

    /**
     * Sets the value of the materialnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setMATERIALNUMBER(String value) {
        this.materialnumber = value;
    }

    /**
     * Gets the value of the unitofmeasure property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public String getUNITOFMEASURE() {
        return unitofmeasure;
    }

    /**
     * Sets the value of the unitofmeasure property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setUNITOFMEASURE(String value) {
        this.unitofmeasure = value;
    }

    /**
     * Gets the value of the sellin property.
     * 
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public boolean isSELLIN() {
        return sellin;
    }

    /**
     * Sets the value of the sellin property.
     * 
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setSELLIN(boolean value) {
        this.sellin = value;
    }

    /**
     * Gets the value of the featured property.
     * 
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public boolean isTACTICAL() {
        return tactical;
    }

    /**
     * Sets the value of the featured property.
     * 
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setTACTICAL(boolean value) {
        this.tactical = value;
    }

    /**
     * Gets the value of the strategic property.
     * 
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public boolean isSTRATEGIC() {
        return strategic;
    }

    /**
     * Sets the value of the strategic property.
     * 
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setSTRATEGIC(boolean value) {
        this.strategic = value;
    }

    /**
     * Gets the value of the featured property.
     * 
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public boolean isFEATURED() {
        return featured;
    }

    /**
     * Sets the value of the featured property.
     * 
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setFEATURED(boolean value) {
        this.featured = value;
    }

    /**
     * Gets the value of the sequenceid property.
     * 
     * @return
     *     possible object is
     *     {@link BigInteger }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public BigInteger getSEQUENCEID() {
        return sequenceid;
    }

    /**
     * Sets the value of the sequenceid property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigInteger }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setSEQUENCEID(BigInteger value) {
        this.sequenceid = value;
    }

    /**
     * Gets the value of the halfcarton property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public String getHALFCARTON() {
        return halfcarton;
    }

    /**
     * Sets the value of the halfcarton property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setHALFCARTON(String value) {
        this.halfcarton = value;
    }

    /**
     * Gets the value of the deltamode property.
     * 
     * @return
     *     possible object is
     *     {@link DeltaMode }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public DeltaMode getDELTAMODE() {
        return deltamode;
    }

    /**
     * Sets the value of the deltamode property.
     * 
     * @param value
     *     allowed object is
     *     {@link DeltaMode }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setDELTAMODE(DeltaMode value) {
        this.deltamode = value;
    }

}
