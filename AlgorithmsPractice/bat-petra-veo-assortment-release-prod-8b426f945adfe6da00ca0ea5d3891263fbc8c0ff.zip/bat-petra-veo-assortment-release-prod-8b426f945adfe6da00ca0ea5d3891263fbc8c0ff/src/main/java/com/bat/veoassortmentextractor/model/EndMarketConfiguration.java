package com.bat.veoassortmentextractor.model;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;
import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(name = "end_market_configuration__c", schema = "salesforce")
@Getter
@Setter
@ToString
public class EndMarketConfiguration extends IvyEntity {

    @Column(name = "market_iso__c")
    private String marketISO;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "recordtypeid", referencedColumnName = "sfid")
    private RecordType recordType;

    @Column(name = "last_execution_date__c")
    private LocalDateTime lastExecutionDate;

    @Column(name = "sku_type__c")
    private String skuType;

    @Column(name = "service_address__c")
    private String serviceAddress;

    @Column(name = "process_execution_time__c")
    private LocalTime executionTime;

    // we use this field as indicator of already performed master plan load
    @Column(name = "container_name__c")
    private String masterLoadExecutionTime;

    @Column(name = "isdeleted")
    private boolean isDeleted;
}
