package com.bat.veoassortmentextractor.transform;

import com.bat.veoassortmentextractor.DTO.AssortmentDTO;
import com.bat.veoassortmentextractor.DTO.AssortmentProductDTO;
import com.bat.veoassortmentextractor.util.Utils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class VeoAssortmentDtoTransformer implements DataTransformer<AssortmentDTO, AssortmentDTO> {

    private static final Logger logger = LoggerFactory.getLogger(VeoAssortmentDtoTransformer.class);

    private final Map<String, String> marketIsoMapping = new HashMap<>();

    @Autowired
    public void configureIsoMarketsMappings(@Value("${veo.endmarket.iso-mapping}") String mapping) {
        logger.debug("iso market configuration string read from config [{}]", mapping);

        marketIsoMapping.putAll(parseMapping(mapping));
    }

    @Override
    public AssortmentDTO transformData(AssortmentDTO objectToTransform) {
        logger.debug("applying data transformation into assortment");
        logger.trace("object before transformations: [{}]", objectToTransform);

        AssortmentDTO result = new AssortmentDTO();
        result.setCustomerId(objectToTransform.getCustomerId());

        //BR13 - Darius said that it should be with 13, but SF has only BR
        String searchKey = objectToTransform.getMarketIso();
        String mappedIsoCode = marketIsoMapping.get(searchKey);
        if (null == mappedIsoCode) {
            logger.warn("iso mapper isn't configured for code [{}], value won't be transformed", searchKey);
            mappedIsoCode = objectToTransform.getMarketIso();
        }
        result.setMarketIso(mappedIsoCode);

        Set<AssortmentProductDTO> transformedProducts = objectToTransform.getProducts()
                .stream()
                .map(this::mapProduct)
                .collect(Collectors.toSet());

        result.setProducts(transformedProducts);

        logger.trace("object after transformations: [{}]", result);
        return result;
    }

    private AssortmentProductDTO mapProduct(AssortmentProductDTO toMap) {
        AssortmentProductDTO result = new AssortmentProductDTO();

        result.setHalfCarton(toMap.isHalfCarton());
        result.setFeatured(toMap.isFeatured());
        result.setStrategic(toMap.isStrategic());
        result.setMaterialNumber(Utils.trimLeadingZeros(toMap.getMaterialNumber()));
        result.setSequence(toMap.getSequence());
        result.setUom(toMap.getUom());

        return result;
    }

    private Map<String, String> parseMapping(String mappingString) {
        Map<String, String> result = new HashMap<>();

        final String tokenSeparator = " ";
        final String isoMarketValueSeparator = ":";

        Scanner parser = new Scanner(mappingString);
        parser.useDelimiter(tokenSeparator);

        logger.debug("parsing mapping string [{}]", mappingString);
        while (parser.hasNext()) {
            String token = parser.next().trim();
            logger.trace("Token to parse [{}]", token);
            if (!token.contains(isoMarketValueSeparator)) {
                logger.trace("discarding improper token");
            } else {
                final int requiredNumberOfElements = 2;
                final int keyIndex = 0;
                final int valueIndex = 1;
                String[] keyValue = token.split(isoMarketValueSeparator);
                if (keyValue.length != requiredNumberOfElements) {
                    logger.trace("iso mapping token has wrong format");
                } else {
                    String key = keyValue[keyIndex].trim();
                    String value = keyValue[valueIndex].trim();
                    if (key.length() > 0 && value.length() > 0) {
                        result.put(key, value);
                        logger.debug("new iso mapping obtained from config [{}]->[{}]", key, value);
                    } else {
                        logger.trace("key or value has zero length");
                    }
                }
            }
        }

        return result;
    }
}
