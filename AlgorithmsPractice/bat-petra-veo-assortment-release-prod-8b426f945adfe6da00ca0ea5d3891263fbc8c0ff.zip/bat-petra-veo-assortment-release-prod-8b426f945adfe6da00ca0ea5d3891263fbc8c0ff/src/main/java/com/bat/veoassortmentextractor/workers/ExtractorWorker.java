package com.bat.veoassortmentextractor.workers;

import com.bat.veoassortmentextractor.DTO.AssortmentDTO;
import com.bat.veoassortmentextractor.DTO.AssortmentProductDTO;
import com.bat.veoassortmentextractor.model.Account;
import com.bat.veoassortmentextractor.model.EndMarketConfiguration;
import com.bat.veoassortmentextractor.services.ExtractorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StopWatch;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.stream.Collectors;

@Component
@Slf4j
public class ExtractorWorker {

    private final ExtractorService extractorService;

    private boolean forceExecutionOfMasterLoad;
    private String selectedErpNumbersFromConfig;

    public ExtractorWorker(ExtractorService extractorService) {
        this.extractorService = extractorService;
    }

    public void doExtract(EndMarketConfiguration configuration) {
        log.debug("Perform scheduled task...");
        log.debug("Configuration details: {}", configuration);

        if (configuration.getLastExecutionDate() == null) {
            configuration.setLastExecutionDate(LocalDateTime.now(Clock.systemUTC()));
        }

        StopWatch stopWatch = new StopWatch("Extractor_" + configuration.getMarketISO());
        String statsMessage = "\n";

        if (performCustomizableLoad()) {
            stopWatch.start("Customizable load");
            List<String> erpNumbers = transformIntoErpNumbers(selectedErpNumbersFromConfig);
            statsMessage += "\tnumber of messages created during customizable load: " + performCustomizableLoad(configuration, erpNumbers) + "\n";
            stopWatch.stop();
        } else if (masterLoadAlreadyExecuted(configuration)) {
            stopWatch.start("Init load - accounts from new plans");
            statsMessage += "\tnumber of messages created during loading new accounts: " + performLoadForAccountsFromNewPlans(configuration) + "\n";
            stopWatch.stop();

            stopWatch.start("Delta one");
            statsMessage += "\tnumber of messages created during delta one load: " + performLoadForDeltaOneAccounts(configuration) + "\n";
            stopWatch.stop();

            stopWatch.start("Delta two");
            statsMessage += "\tnumber of messages created during delta two load: " + performLoadForDeltaTwoAccounts(configuration);
            stopWatch.stop();
        } else {
            stopWatch.start("Master load - all accounts");
            statsMessage += "\tnumber of messages created during master load: " + performMasterLoad(configuration);
            stopWatch.stop();
        }

        configuration.setLastExecutionDate(LocalDateTime.now(Clock.systemUTC()));
        extractorService.updateLastExecutionDate(configuration);
        log.debug("Report from Job: " + stopWatch.prettyPrint());
        log.debug("Number statistics after load: " + statsMessage);
    }

    @Autowired
    public void setForceExecutionOfMasterLoad(@Value("${veo.master.load.external-config}") String masterLoadExternalConfig) {
        log.debug("master load force value from config: [{}]", masterLoadExternalConfig);
        this.forceExecutionOfMasterLoad = Boolean.parseBoolean(masterLoadExternalConfig);
        log.debug("forceExecutionOfMasterLoad after parsing parameter value [{}]", forceExecutionOfMasterLoad);
    }

    @Autowired
    public void setSelectedErpNumbers(@Value("${veo.load.customizable.selected-erp-numbers}") String selectedErpNumbersFromConfig) {
        log.debug("selected erp numbers from config: [{}]", selectedErpNumbersFromConfig);
        this.selectedErpNumbersFromConfig = selectedErpNumbersFromConfig;
    }

    private int performLoadForDeltaOneAccounts(EndMarketConfiguration configuration) {
        log.debug("performLoadForDeltaOneAccounts() - accounts which product group details in plan was modified");
        List<Account> accounts = extractorService.getAccountsWhichProductGroupDetailsInPlanWasModified(configuration);
        performLoadForGivenAccounts(configuration, accounts);
        log.debug("performLoadForDeltaOneAccounts() done...");

        return accounts.size();
    }

    private int performLoadForDeltaTwoAccounts(EndMarketConfiguration configuration) {
        log.debug("performLoadForDeltaTwoAccounts() - accounts for which any product was changed");
        List<Account> accounts = extractorService.getAccountsForWhichAnyProductWasChanged(configuration);
        performLoadForGivenAccounts(configuration, accounts);
        log.debug("performLoadForDeltaTwoAccounts() done...");

        return accounts.size();
    }

    private int performCustomizableLoad(EndMarketConfiguration configuration, List<String> erpNumbers) {
        log.debug("perform customizable load");
        List<Account> accounts = extractorService.getAccountsByErpNumbers(configuration, erpNumbers);
        performLoadForGivenAccounts(configuration, accounts);
        log.debug("perform customizable load - done...");

        return accounts.size();
    }

    private int performMasterLoad(EndMarketConfiguration configuration) {
        log.debug("performing master load - all available accounts");
        List<Account> accounts = extractorService.getAllAvailableAccounts(configuration);
        performLoadForGivenAccounts(configuration, accounts);

        // needs to be sure full load was performed before saving execution time
        configuration.setMasterLoadExecutionTime(LocalDateTime.now(Clock.systemUTC()).toString());
        log.debug("master load done...");

        return accounts.size();
    }

    private int performLoadForAccountsFromNewPlans(EndMarketConfiguration configuration) {
        log.debug("performing load for accounts from new plans");
        List<Account> accounts = extractorService.getAccountsFromNewPlans(configuration);
        performLoadForGivenAccounts(configuration, accounts);
        log.debug("load for accounts from new plans done...");

        return accounts.size();
    }

    private void performLoadForGivenAccounts(EndMarketConfiguration configuration, List<Account> accounts) {
        log.debug("performLoadForGivenAccounts() with configuration: [{}] for [{}] accounts", configuration, accounts.size());

        Map<String, List<AssortmentProductDTO>> priceListsOverProducts = extractorService.getPriceListsWithAssignedProducts(configuration);

        for (Account account : accounts) {
            log.debug("processing for account [{}]", account);

            List<AssortmentProductDTO> accountsProducts = getDeepCopyOfProductsListForAccount(account, priceListsOverProducts);
            List<AssortmentProductDTO> productsFromPlan = extractorService.findProductsFromPlanForAccount(account);
            List<AssortmentProductDTO> mergedProductList = processAccountsProductsBasedOnFeaturesFromPlan(accountsProducts, productsFromPlan);

            extractorService.assignMissingSequenceNumbersToProducts(mergedProductList);

            AssortmentDTO sourceAssortment = new AssortmentDTO(account.getSapCustomerId(), configuration.getMarketISO(), new LinkedHashSet<>(mergedProductList));
            AssortmentDTO targetAssortment = extractorService.applyDataTransformations(sourceAssortment);
            extractorService.createAndSendXml(targetAssortment, configuration);
        }
    }

    private List<AssortmentProductDTO> processAccountsProductsBasedOnFeaturesFromPlan(List<AssortmentProductDTO> accountsProducts,
                                                                                      List<AssortmentProductDTO> productsFromPlan) {
        List<AssortmentProductDTO> result = new ArrayList<>(accountsProducts);

        productsFromPlan.forEach(assortmentProductDTO -> {
            int positionOfPlanProduct = result.indexOf(assortmentProductDTO);
            if (positionOfPlanProduct >= 0) {
                switch (assortmentProductDTO.getDesignation()) {
                    case APPLY:
                        AssortmentProductDTO objectToModify = result.get(positionOfPlanProduct);
                        objectToModify.setStrategic(assortmentProductDTO.isStrategic());
                        objectToModify.setFeatured(assortmentProductDTO.isFeatured());
                        objectToModify.setSequence(assortmentProductDTO.getSequence());
                        break;
                    case DROP:
                        result.remove(positionOfPlanProduct);
                        break;
                    default:
                        // do nothing
                        break;
                }
            }
        });

        return result;
    }

    private List<AssortmentProductDTO> getDeepCopyOfProductsListForAccount(Account account, Map<String, List<AssortmentProductDTO>> source) {
        return source.getOrDefault(account.getPriceListName(), Collections.emptyList())
                .stream()
                .map(AssortmentProductDTO::clone)
                .collect(Collectors.toList());
    }

    private boolean masterLoadAlreadyExecuted(EndMarketConfiguration configuration) {
        boolean result = false;
        try {
            result = Optional.ofNullable(configuration.getMasterLoadExecutionTime())
                    .map(LocalDateTime::parse)
                    .map(masterLoadLastExecutionTime -> LocalDateTime.now(Clock.systemUTC()).isAfter(masterLoadLastExecutionTime))
                    .orElse(false);
        } catch (DateTimeParseException exc) {
            log.warn("some strange value occurred into field used for storing execution date", exc);
        }
        return result && !forceExecutionOfMasterLoad;
    }

    private boolean performCustomizableLoad() {
        final String customizableLoadDisabled = "-";
        boolean result = false;

        result = Optional.ofNullable(selectedErpNumbersFromConfig)
                .map(s -> !s.equals(customizableLoadDisabled))
                .orElse(false);

        log.debug("performCustomizableLoad() result: [{}]", result);
        return result;
    }

    private List<String> transformIntoErpNumbers(String erpsConcatenation) {

        return Arrays.stream(erpsConcatenation.split(","))
                .map(String::trim)
                .filter(s -> s.length() > 0)
                .collect(Collectors.toList());
    }
}

