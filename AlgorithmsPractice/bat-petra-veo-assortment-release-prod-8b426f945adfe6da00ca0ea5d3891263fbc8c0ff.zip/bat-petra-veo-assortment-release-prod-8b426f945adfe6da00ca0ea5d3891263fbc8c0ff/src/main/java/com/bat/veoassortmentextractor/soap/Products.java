
package com.bat.veoassortmentextractor.soap;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Products complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Products">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="PRODUCT" type="{http://veo.bat.biz/v2/veoAssortmentSchema}Product" maxOccurs="unbounded"/>
 *       &lt;/sequence>
 *       &lt;attribute name="DROP_CHILDREN" type="{http://www.w3.org/2001/XMLSchema}boolean" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Products", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", propOrder = {
    "product"
})
@Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
public class Products {

    @XmlElement(name = "PRODUCT", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", required = true)
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected List<Product> product;
    @XmlAttribute(name = "DROP_CHILDREN")
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected Boolean dropchildren;

    /**
     * Gets the value of the product property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the product property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getPRODUCT().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link Product }
     * 
     * 
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public List<Product> getPRODUCT() {
        if (product == null) {
            product = new ArrayList<Product>();
        }
        return this.product;
    }

    /**
     * Gets the value of the dropchildren property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public Boolean isDROPCHILDREN() {
        return dropchildren;
    }

    /**
     * Sets the value of the dropchildren property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setDROPCHILDREN(Boolean value) {
        this.dropchildren = value;
    }

}
