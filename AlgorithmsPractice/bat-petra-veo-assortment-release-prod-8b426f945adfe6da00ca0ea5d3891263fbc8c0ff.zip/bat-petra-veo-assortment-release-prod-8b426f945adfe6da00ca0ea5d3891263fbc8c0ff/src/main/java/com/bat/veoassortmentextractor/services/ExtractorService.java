package com.bat.veoassortmentextractor.services;

import com.bat.veoassortmentextractor.DTO.AssortmentDTO;
import com.bat.veoassortmentextractor.DTO.AssortmentProductDTO;
import com.bat.veoassortmentextractor.model.Account;
import com.bat.veoassortmentextractor.model.EndMarketConfiguration;
import com.bat.veoassortmentextractor.soap.AssortmentImportRequest;

import java.util.List;
import java.util.Map;

public interface ExtractorService {

    void sendToQueue(String message, EndMarketConfiguration configuration);

    String convertToXml(AssortmentImportRequest importRequest);

    void updateLastExecutionDate(EndMarketConfiguration configuration);

    Map<String, List<AssortmentProductDTO>> getPriceListsWithAssignedProducts(EndMarketConfiguration endMarketConfiguration);

    List<Account> getAllAvailableAccounts(EndMarketConfiguration endMarketConfiguration);

    List<Account> getAccountsFromNewPlans(EndMarketConfiguration marketConfiguration);

    List<Account> getAccountsByErpNumbers(EndMarketConfiguration marketConfiguration, List<String> erpNumbers);

    List<AssortmentProductDTO> findProductsFromPlanForAccount(Account account);

    void assignMissingSequenceNumbersToProducts(List<AssortmentProductDTO> listToSend);

    AssortmentDTO applyDataTransformations(AssortmentDTO assortmentDTO);

    void createAndSendXml(AssortmentDTO assortmentDTO, EndMarketConfiguration configuration);

    List<Account> getAccountsWhichProductGroupDetailsInPlanWasModified(EndMarketConfiguration configuration);

    List<Account> getAccountsForWhichAnyProductWasChanged(EndMarketConfiguration configuration);
}
