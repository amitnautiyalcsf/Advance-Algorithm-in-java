package com.bat.veoassortmentextractor.transform;

public interface DataTransformer<T, R> {

    R transformData(T objectToTransform);
}
