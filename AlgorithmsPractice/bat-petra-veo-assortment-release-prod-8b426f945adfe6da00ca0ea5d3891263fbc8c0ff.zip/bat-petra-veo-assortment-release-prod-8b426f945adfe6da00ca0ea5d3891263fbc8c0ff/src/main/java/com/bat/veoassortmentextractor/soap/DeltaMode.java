
package com.bat.veoassortmentextractor.soap;

import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlEnum;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DeltaMode.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * <p>
 * <pre>
 * &lt;simpleType name="DeltaMode">
 *   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}string">
 *     &lt;enumeration value="CHANGE"/>
 *     &lt;enumeration value="DELETE"/>
 *   &lt;/restriction>
 * &lt;/simpleType>
 * </pre>
 * 
 */
@XmlType(name = "DeltaMode", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema")
@XmlEnum
@Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
public enum DeltaMode {

    CHANGE,
    DELETE;

    public String value() {
        return name();
    }

    public static DeltaMode fromValue(String v) {
        return valueOf(v);
    }

}
