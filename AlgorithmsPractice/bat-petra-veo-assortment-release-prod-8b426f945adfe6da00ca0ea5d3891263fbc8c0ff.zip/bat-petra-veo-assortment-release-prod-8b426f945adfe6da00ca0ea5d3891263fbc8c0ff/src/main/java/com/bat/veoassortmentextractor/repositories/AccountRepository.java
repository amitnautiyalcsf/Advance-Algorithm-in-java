package com.bat.veoassortmentextractor.repositories;

import com.bat.veoassortmentextractor.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AccountRepository extends JpaRepository<Account, String> {

    @Query(nativeQuery = true, value = "" +
            "select *                                                                                                   \n" +
            "from salesforce.account a                                                                                  \n" +
            "where                                                                                                      \n" +
            "  a.ivybat__enable_online_order__c = true                                                                  \n" +
            "  and a.ivybase__Status__c <> 'Permanently Deactivated'                                                    \n" +
            "  and a.ivybase__Status__c <> 'Temporarily Deactivated'                                                    \n" +
            "  and a.ivybat__market_iso__c = :marketIso                                                                 \n" +
            "  and a.isdeleted = false"
    )
    List<Account> findAllOnlineActiveCustomers(@Param("marketIso") String marketIso);

    @Query(nativeQuery = true, value = "" +
            "select *                                                                                                 \n" +
            "from salesforce.account a                                                                                \n" +
            "where                                                                                                    \n" +
            "  a.ivybat__enable_online_order__c = true                                                                \n" +
            "  and a.ivybase__Status__c <> 'Permanently Deactivated'                                                  \n" +
            "  and a.ivybase__Status__c <> 'Temporarily Deactivated'                                                  \n" +
            "  and a.ivybat__market_iso__c = :marketIso                                                               \n" +
            "  and a.isdeleted = false                                                                                \n" +
            "  and a.pricing_group__c in :priceList                                                                   \n"
    )
    List<Account> findAllOnlineActiveCustomersForPriceLists(@Param("marketIso") String marketIso, @Param("priceList") List<String> priceLists);

    @Query(nativeQuery = true, value = "" +
            "select *                                                                                                   \n" +
            "from salesforce.account a                                                                                  \n" +
            "where                                                                                                      \n" +
            "  a.ivybat__enable_online_order__c = true                                                                  \n" +
            "  and a.ivybase__Status__c <> 'Permanently Deactivated'                                                    \n" +
            "  and a.ivybase__Status__c <> 'Temporarily Deactivated'                                                    \n" +
            "  and a.ivybat__sap_customerid__c in :erpNumbers                                                           \n" +
            "  and a.ivybat__market_iso__c = :marketIso                                                                 \n" +
            "  and a.isdeleted = false                                                                                  \n"
    )
    List<Account> findOnlineActiveCustomersByErpNumbers(@Param("marketIso") String marketIso, @Param("erpNumbers") List<String> erpNumbers);
}
