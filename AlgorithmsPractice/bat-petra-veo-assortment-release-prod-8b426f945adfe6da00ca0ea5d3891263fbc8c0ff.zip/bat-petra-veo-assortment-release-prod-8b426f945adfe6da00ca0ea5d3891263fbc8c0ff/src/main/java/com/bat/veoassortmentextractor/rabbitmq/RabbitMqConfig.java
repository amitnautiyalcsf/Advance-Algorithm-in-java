package com.bat.veoassortmentextractor.rabbitmq;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.*;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Optional;

@Configuration
public class RabbitMqConfig {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMqConfig.class);

    public static final String EXCHANGE_KEY = "routingkey";
    public static final String ROUTING_KEY = "exchange";
    public static final String QUEUE_NAME = "veo-assortment";

    @Value("${spring.rabbitmq.host}")
    private String defaultRabbitHost;

    @Value("${spring.rabbitmq.port}")
    private int defaultRabbitPort;

    @Value("${spring.rabbitmq.username}")
    private String defaultRabbitUsername;

    @Value("${spring.rabbitmq.password}")
    private String defaultRabbitPassword;

    @Bean
    Queue queue() {
        return new Queue(QUEUE_NAME, true);
    }

    @Bean
    DirectExchange exchange() {
        return new DirectExchange(EXCHANGE_KEY);
    }

    @Bean
    Binding binding(Queue queue, DirectExchange exchange) {
        return BindingBuilder.bind(queue).to(exchange).with(ROUTING_KEY);
    }

    @Bean
    public MessageConverter jsonMessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean
    public ConnectionFactory connectionFactory() {
        final CachingConnectionFactory factory = new CachingConnectionFactory();

        Optional<String> amqpConnectionString = getEnvVarValue("CLOUDAMQP_URL");
        if (amqpConnectionString.isPresent()) {
            logger.debug("Trying to configure RabbitMQ by connection string");
            try {
                URI amqpUri = new URI(amqpConnectionString.get());
                final int usernameIndex = 0;
                final int passwordIndex = 1;
                factory.setUsername(amqpUri.getUserInfo().split(":")[usernameIndex]);
                factory.setPassword(amqpUri.getUserInfo().split(":")[passwordIndex]);
                factory.setHost(amqpUri.getHost());
                factory.setPort(amqpUri.getPort());
                factory.setVirtualHost(amqpUri.getPath().substring(1));
            } catch (URISyntaxException e) {
                logger.error("Error occurred during creating URI object from connection string", e);
                throw new RuntimeException("ConnectionFactory configuration error", e);
            }
        } else {
            logger.debug("Using default configuration of RabbitMQ");
            configureToDefaultValues(factory);
        }

        return factory;
    }

    @Bean
    public RabbitTemplate rabbitTemplate() {
        RabbitTemplate template = new RabbitTemplate(connectionFactory());
        template.setRoutingKey(ROUTING_KEY);
        template.setDefaultReceiveQueue(QUEUE_NAME);
        return template;
    }

    @Bean
    public AmqpAdmin amqpAdmin() {
        return new RabbitAdmin(connectionFactory());
    }

    private void configureToDefaultValues(CachingConnectionFactory connectionFactory) {
        connectionFactory.setUsername(defaultRabbitUsername);
        connectionFactory.setPassword(defaultRabbitPassword);
        connectionFactory.setHost(defaultRabbitHost);
        connectionFactory.setPort(defaultRabbitPort);
    }

    private Optional<String> getEnvVarValue(String envName) {
        String envValue = System.getenv(envName);

        logger.debug("Value of read environment variable [{}] is [{}]", envName, envValue);

        return Optional.ofNullable(envValue);
    }
}
