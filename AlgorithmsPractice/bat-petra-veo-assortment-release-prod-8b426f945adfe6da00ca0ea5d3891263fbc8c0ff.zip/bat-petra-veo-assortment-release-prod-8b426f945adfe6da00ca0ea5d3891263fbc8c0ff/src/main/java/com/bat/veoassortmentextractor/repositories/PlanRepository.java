package com.bat.veoassortmentextractor.repositories;

import com.bat.veoassortmentextractor.model.Plan;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.util.List;

@Repository
public interface PlanRepository extends JpaRepository<Plan, String> {

    @Query("SELECT DISTINCT plan " +
            "FROM Plan plan " +
            "INNER JOIN FETCH plan.productGroups groups " +
            "INNER JOIN FETCH groups.productGroupDetail details " +
            "WHERE " +
            "plan.marketIso = :market " +
            "AND plan.planStartDate = :currentDate " +
            "AND details.account IN ('0011x00000D2CXnAAN', '0011x00000D234UAAR')")
    List<Plan> findAllStartingPlans(@Param("market") String marketIso, @Param("currentDate") LocalDate currentDate);

    @Query("SELECT DISTINCT plan " +
            "FROM Plan plan " +
            "INNER JOIN FETCH plan.productGroups groups " +
            "INNER JOIN FETCH groups.productGroupDetail details " +
            "WHERE " +
            "plan.marketIso = :market " +
            "AND plan.planStartDate <= :currentDate " +
            "AND plan.planEndDate >= :currentDate " +
            "AND details.account IN ('0011x00000D2CXnAAN', '0011x00000D234UAAR')")
    List<Plan> findAllforMasterLoad(@Param("market") String marketIso, @Param("currentDate") LocalDate currentDate);

//    @Query("SELECT DISTINCT plan " +
//            "FROM Plan plan " +
//            "INNER JOIN FETCH plan.productGroups groups " +
//            "INNER JOIN FETCH groups.productGroupDetail details " +
//            "WHERE " +
//            "plan.marketIso = :market " +
//            "AND plan.planStartDate < :currentDate " +
//            "AND plan.planEndDate >= :currentDate " +
//            "AND details.lastModifiedDate > :date")
//    List<Plan> findAllModifiedGroupDetails(@Param("date") ChronoLocalDate lastExecDate, @Param("market") String marketIso, @Param("currentDate") LocalDate currentDate);
//
//    @Query("SELECT DISTINCT plan " +
//            "FROM Plan plan " +
//            "INNER JOIN FETCH plan.productGroups groups " +
//            "INNER JOIN FETCH groups.productGroupDetail details " +
//            "INNER JOIN FETCH details.product prod " +
//            "WHERE " +
//            "plan.marketIso = :market " +
//            "AND plan.planStartDate < :currentDate " +
//            "AND plan.planEndDate >= :currentDate " +
//            "AND prod.lastModifiedDate > :date")
//    List<Plan> findAllModifiedProducts(@Param("date") ChronoLocalDate lastExecDate, @Param("market") String marketIso, @Param("currentDate") LocalDate currentDate);
@Query("SELECT DISTINCT plan " +
        "FROM Plan plan " +
        "INNER JOIN FETCH plan.productGroups groups " +
        "INNER JOIN FETCH groups.productGroupDetail details " +
        "WHERE " +
        "plan.marketIso = :market " +
        "AND plan.planStartDate < :currentDate " +
        "AND plan.planEndDate >= :currentDate " +
        "AND details.lastModifiedDate > :date " +
        "AND details.account IN ('0011x00000D2CXnAAN', '0011x00000D234UAAR')")
List<Plan> findAllModifiedGroupDetails(@Param("date") ChronoLocalDate lastExecDate, @Param("market") String marketIso, @Param("currentDate") LocalDate currentDate);

    @Query("SELECT DISTINCT plan " +
            "FROM Plan plan " +
            "INNER JOIN FETCH plan.productGroups groups " +
            "INNER JOIN FETCH groups.productGroupDetail details " +
            "INNER JOIN FETCH details.product prod " +
            "WHERE " +
            "plan.marketIso = :market " +
            "AND plan.planStartDate < :currentDate " +
            "AND plan.planEndDate >= :currentDate " +
            "AND prod.lastModifiedDate > :date " +
            "AND details.account IN ('0011x00000D2CXnAAN', '0011x00000D234UAAR')")
    List<Plan> findAllModifiedProducts(@Param("date") ChronoLocalDate lastExecDate, @Param("market") String marketIso, @Param("currentDate") LocalDate currentDate);

}
