package com.bat.veoassortmentextractor.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.time.LocalDate;
import java.util.Set;

@Entity
@Table(name = "ivybat__plan__c", schema = "salesforce")
@Getter
@Setter
public class Plan extends IvyEntity {

    @Column(name = "ivybat__start_date__c")
    private LocalDate planStartDate;

    @Column(name = "ivybat__End_Date__c")
    private LocalDate planEndDate;

    @Column(name = "ivybat__Market_ISO__c")
    private String marketIso;

    @OneToMany(mappedBy = "plan")
    private Set<ProductGroup> productGroups;

    @Column(name = "isdeleted")
    private boolean isDeleted;
}
