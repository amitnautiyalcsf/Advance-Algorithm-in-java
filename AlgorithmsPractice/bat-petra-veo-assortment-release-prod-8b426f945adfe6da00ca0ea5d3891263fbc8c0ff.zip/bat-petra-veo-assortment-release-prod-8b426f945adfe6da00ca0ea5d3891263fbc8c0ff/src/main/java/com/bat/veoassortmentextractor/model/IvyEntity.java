package com.bat.veoassortmentextractor.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;
import java.time.LocalDateTime;

@MappedSuperclass
@Getter
@Setter
@ToString
public abstract class IvyEntity implements Serializable {

    @Id
    @Column(name = "ID")
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "sfid", length = 18)
    private String sfId;

    @Column(name = "systemmodstamp")
    private LocalDateTime systemModstamp;

    @Column(name = "createddate")
    private LocalDateTime createdDate;
}
