package com.bat.veoassortmentextractor.repositories;

import com.bat.veoassortmentextractor.model.Product;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Product, Integer> {

}
