package com.bat.veoassortmentextractor.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "ivybase__product_group_detail__c", schema = "salesforce")
@Getter
@Setter
public class ProductGroupDetail extends IvyEntity {

    // TODO this doesn't belong here:(
    private static final String OPPORTUNITY_STRING = "Opportunity";
    private static final String PRIORITY_STRING = "Priority";

    @Column(name = "ivybase__Category__c")
    private String category;

    @Column(name = "ivybase__Sequence__c")
    private String sequence;

    @Column(name = "ivybat__Market_ISO__c")
    private String marketIso;

    @Column(name = "ivybat__Product_Group_Record_Type__c")
    private String productGroupRecordType;

    @Column(name = "lastmodifieddate")
    private LocalDate lastModifiedDate;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ivybase__Product_Group__c", referencedColumnName = "sfid")
    private ProductGroup productGroup;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ivybat__Outlet__c", referencedColumnName = "sfid")
    private Account account;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ivybase__Product__c", referencedColumnName = "sfid")
    private Product product;

    @Column(name = "isdeleted")
    private boolean isDeleted;

    public boolean isFeatured() {
        return OPPORTUNITY_STRING.equals(category);
    }

    public boolean isStrategic() {
        return PRIORITY_STRING.equals(category);
    }
}
