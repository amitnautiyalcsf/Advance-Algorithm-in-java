package com.bat.veoassortmentextractor.repositories;

import com.bat.veoassortmentextractor.DTO.AssortmentProductDTO;
import com.bat.veoassortmentextractor.model.Account;
import com.bat.veoassortmentextractor.model.EndMarketConfiguration;

import java.util.List;
import java.util.Map;

public interface DataProvider {

    void updateLastExecutionDate(EndMarketConfiguration configuration);

    Map<String, List<AssortmentProductDTO>> getPriceListsWithAssignedProducts(EndMarketConfiguration endMarketConfiguration);

    List<String> getPriceListsWithModifiedProducts(EndMarketConfiguration endMarketConfiguration);

    List<AssortmentProductDTO> findProductsFromActivePlanForAccount(Account account);

    List<Account> findAllOnlineActiveCustomers(String marketIso);

    List<Account> findAccountsFromNewPlan(String marketISO);

    List<Account> findAccountsWhichProductGroupDetailsInPlanWasModified(EndMarketConfiguration configuration);

    List<Account> findAccountsAssociatedWithPlanForWhichAnyProductWasModified(EndMarketConfiguration configuration);

    List<Account> findAllCustomersWithGivenPriceLists(String marketIso, List<String> priceLists);

    List<Account> findOnlineActiveCustomersByErpNumbers(String marketIso, List<String> erpNumbers);

}
