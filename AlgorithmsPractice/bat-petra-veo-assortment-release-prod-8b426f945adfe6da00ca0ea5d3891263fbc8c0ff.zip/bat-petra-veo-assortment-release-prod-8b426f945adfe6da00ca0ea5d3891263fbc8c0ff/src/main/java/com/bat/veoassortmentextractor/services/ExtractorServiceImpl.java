package com.bat.veoassortmentextractor.services;

import com.bat.veoassortmentextractor.DTO.AssortmentDTO;
import com.bat.veoassortmentextractor.DTO.AssortmentProductDTO;
import com.bat.veoassortmentextractor.model.Account;
import com.bat.veoassortmentextractor.model.EndMarketConfiguration;
import com.bat.veoassortmentextractor.repositories.DataProvider;
import com.bat.veoassortmentextractor.soap.AssortmentImportRequest;
import com.bat.veoassortmentextractor.soap.Customer;
import com.bat.veoassortmentextractor.soap.Customers;
import com.bat.veoassortmentextractor.soap.Products;
import com.bat.veoassortmentextractor.transform.DataTransformer;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import java.io.StringWriter;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class ExtractorServiceImpl implements ExtractorService {

    private static final String EXCHANGE_KEY = "routingkey";
    private static final String ROUTING_KEY = "exchange";

    private AmqpTemplate rabbitTemplate;
    private DataTransformer<AssortmentDTO, AssortmentDTO> dataTransformer;
    private DataProvider dataProvider;

    @Autowired
    public void setRabbitTemplate(AmqpTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    @Autowired
    public void setDataProvider(DataProvider dataProvider) {
        this.dataProvider = dataProvider;
    }

    @Autowired
    public void setDataTransformer(DataTransformer<AssortmentDTO, AssortmentDTO> dataTransformer) {
        this.dataTransformer = dataTransformer;
    }

    @Override
    public void updateLastExecutionDate(EndMarketConfiguration configuration) {
        dataProvider.updateLastExecutionDate(configuration);
    }

    @Override
    public Map<String, List<AssortmentProductDTO>> getPriceListsWithAssignedProducts(EndMarketConfiguration endMarketConfiguration) {
        return dataProvider.getPriceListsWithAssignedProducts(endMarketConfiguration);
    }

    @Override
    public List<Account> getAllAvailableAccounts(EndMarketConfiguration endMarketConfiguration) {

        return dataProvider.findAllOnlineActiveCustomers(endMarketConfiguration.getMarketISO());
    }

    @Override
    public List<Account> getAccountsFromNewPlans(EndMarketConfiguration marketConfiguration) {
        return dataProvider.findAccountsFromNewPlan(marketConfiguration.getMarketISO());
    }

    @Override
    public List<Account> getAccountsByErpNumbers(EndMarketConfiguration marketConfiguration, List<String> erpNumbers) {
        return dataProvider.findOnlineActiveCustomersByErpNumbers(marketConfiguration.getMarketISO(), erpNumbers);
    }

    @Override
    public List<AssortmentProductDTO> findProductsFromPlanForAccount(Account account) {
        return dataProvider.findProductsFromActivePlanForAccount(account);
    }

    public void assignMissingSequenceNumbersToProducts(List<AssortmentProductDTO> listToSend) {
        log.debug("assignMissingSequenceNumbersToProducts()");
        log.debug("input list: []", listToSend);
        long maxSequenceNumberFromPlan = listToSend
                .stream()
                .filter(assortmentProductDTO -> !assortmentProductDTO.getSequence().isEmpty())
                .mapToLong(value -> Long.parseLong(value.getSequence()))
                .max()
                .orElse(0);

        for (AssortmentProductDTO assortmentProductDTO : listToSend) {
            if (assortmentProductDTO.getSequence().isEmpty()) {
                assortmentProductDTO.setSequence("" + ++maxSequenceNumberFromPlan);
            }
        }

        log.debug("list after calculating new sequence numbers: []", listToSend);
    }

    @Override
    public AssortmentDTO applyDataTransformations(AssortmentDTO assortmentDTO) {
        log.debug("applyDataTransformations()");

        return dataTransformer.transformData(assortmentDTO);
    }

    public void createAndSendXml(AssortmentDTO assortmentDTO, EndMarketConfiguration configuration) {
        AssortmentImportRequest request = new AssortmentImportRequest();
        request.setMARKETIDENTIFIER(assortmentDTO.getMarketIso());
        Customers customers = new Customers();

        Customer customer = new Customer();
        customer.setSOLDTOERPNUMBER(assortmentDTO.getCustomerId());

        Products products = new Products();
        products.setDROPCHILDREN(Boolean.TRUE);

        for (AssortmentProductDTO product : assortmentDTO.getProducts()) {
            com.bat.veoassortmentextractor.soap.Product xmlProduct = new com.bat.veoassortmentextractor.soap.Product();
            xmlProduct.setMATERIALNUMBER(product.getMaterialNumber());
            xmlProduct.setUNITOFMEASURE(product.getUom());
            xmlProduct.setSELLIN(Boolean.FALSE);
            xmlProduct.setTACTICAL(false);
            xmlProduct.setSTRATEGIC(product.isStrategic());
            xmlProduct.setFEATURED(product.isFeatured());
            xmlProduct.setSEQUENCEID(new BigInteger(product.getSequence()));
            xmlProduct.setHALFCARTON(String.valueOf(product.isHalfCarton()));
            products.getPRODUCT().add(xmlProduct);
        }

        customers.setCUSTOMER(customer);
        customer.setPRODUCTS(products);

        request.setCUSTOMERS(customers);

        sendToQueue(convertToXml(request), configuration);
    }

    @Override
    public List<Account> getAccountsWhichProductGroupDetailsInPlanWasModified(EndMarketConfiguration configuration) {
        return dataProvider.findAccountsWhichProductGroupDetailsInPlanWasModified(configuration);
    }

    @Override
    public List<Account> getAccountsForWhichAnyProductWasChanged(EndMarketConfiguration configuration) {

        List<String> namesOfModifiedPriceLists = dataProvider.getPriceListsWithModifiedProducts(configuration);
        // TODO: clean this dirty hack
        if (namesOfModifiedPriceLists.isEmpty()) {
            namesOfModifiedPriceLists.add("");
        }
        return getAccountsWithChangedPriceLists(configuration, namesOfModifiedPriceLists);
    }

    private List<Account> getAccountsWithChangedPriceLists(EndMarketConfiguration configuration, List<String> priceLists) {
        return dataProvider.findAllCustomersWithGivenPriceLists(configuration.getMarketISO(), priceLists);
    }

    public String convertToXml(AssortmentImportRequest importRequest) {
        String xmlContent = "";
        try {
            JAXBContext jaxbContext = JAXBContext.newInstance(AssortmentImportRequest.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            StringWriter sw = new StringWriter();
            jaxbMarshaller.marshal(importRequest, sw);
            xmlContent = sw.toString();
        } catch (JAXBException e) {
            log.warn("exception occurred during jaxb transformation", e);
        }
        return xmlContent;
    }

    // TODO:MP we do not need configuration here - just the address - Objects.requireNonNuLL
    public void sendToQueue(String message, EndMarketConfiguration configuration) {
        byte[] messageBytes = message.getBytes(StandardCharsets.UTF_8);
        rabbitTemplate.convertAndSend(EXCHANGE_KEY, ROUTING_KEY, messageBytes, m -> {
            m.getMessageProperties().getHeaders().put("targetEndpoint", configuration.getServiceAddress());
            return m;
        });
        log.trace("Send msg = " + message);
    }
}
