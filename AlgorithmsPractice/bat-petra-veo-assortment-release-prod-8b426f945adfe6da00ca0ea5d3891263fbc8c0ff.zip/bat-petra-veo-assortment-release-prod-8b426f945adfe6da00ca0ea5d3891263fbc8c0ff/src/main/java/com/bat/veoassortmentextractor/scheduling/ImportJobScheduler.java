package com.bat.veoassortmentextractor.scheduling;

import com.bat.veoassortmentextractor.model.EndMarketConfiguration;
import com.bat.veoassortmentextractor.repositories.EndMarketConfigurationRepository;
import com.bat.veoassortmentextractor.workers.ExtractorWorker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.List;

@Component
@EnableScheduling
public class ImportJobScheduler {

    private static final Logger logger = LoggerFactory.getLogger(ImportJobScheduler.class);
    private static final String configurationName = "Veo Integration";

    private final ImportExecutor importExecutor;
    private final EndMarketConfigurationRepository configurationRepository;
    private final ExtractorWorker extractorWorker;

    public ImportJobScheduler(ImportExecutor importExecutor, EndMarketConfigurationRepository configurationRepository,
                              ExtractorWorker extractorWorker) {
        this.importExecutor = importExecutor;
        this.configurationRepository = configurationRepository;
        this.extractorWorker = extractorWorker;
    }

    @Scheduled(cron = "${veo.schedule.cron.expression}")
    public void scheduleImports() {
        logger.debug("scheduleImports(), time of execution: [{}]", LocalDateTime.now());

        List<EndMarketConfiguration> configs = configurationRepository.findAllByRecordType_Name(configurationName);
        configs.forEach(endMarketConfiguration ->
                importExecutor.scheduleImportJob(prepareExtractionJob(endMarketConfiguration),
                        LocalDateTime.of(LocalDate.now(ZoneId.of("UTC")), endMarketConfiguration.getExecutionTime()))
        );
    }

    private Runnable prepareExtractionJob(EndMarketConfiguration endMarketConfiguration) {
        return () -> {
            try {
                extractorWorker.doExtract(endMarketConfiguration);
            } catch (Exception e) {
                logger.error("extractor job was interrupted", e);

            }
        };
    }
}
