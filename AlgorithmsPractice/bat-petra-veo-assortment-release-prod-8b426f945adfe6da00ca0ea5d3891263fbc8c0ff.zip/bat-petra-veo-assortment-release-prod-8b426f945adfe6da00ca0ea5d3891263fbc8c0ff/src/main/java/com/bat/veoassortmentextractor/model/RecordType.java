package com.bat.veoassortmentextractor.model;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "recordtype", schema = "salesforce")
@ToString(callSuper = true)
@Getter
@Setter
public class RecordType extends IvyEntity {

    @Column(name = "isactive")
    boolean isactive;
}
