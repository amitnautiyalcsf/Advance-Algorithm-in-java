package com.bat.veoassortmentextractor.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "ivybase__product__c", schema = "salesforce")
@Getter
@Setter
public class Product extends IvyEntity {

    @Column(name = "ivybase__Active__c")
    private String active;

    @Column(name = "ispriority__c")
    private boolean isPriority;

    @Column(name = "ivybat__Material_ERPNumber__c")
    private String materialErpNumber;

    @Column(name = "Half_Of_High_UOM__c")
    private boolean halfOfHighUOM;

    @Column(name = "ivybat__Sales_Unit_Of_Measure__c")
    private String salesUnitOfMeasure;

    @Column(name = "lastmodifieddate")
    private LocalDate lastModifiedDate;

    @Column(name = "foc__c")
    private boolean freeOfCharge;

    @Column(name = "ivybat__market_iso__c")
    private String marketIso;

    @ManyToOne
    @JoinColumn(name = "ivybase__Primary_Product__c", referencedColumnName = "sfid")
    private Product primaryProduct;

    @OneToMany(mappedBy = "primaryProduct")
    private Set<Product> productSet = new HashSet<>();

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "recordtypeid", referencedColumnName = "sfid")
    private RecordType recordType;

    @Column(name = "ivybat__code__c")
    private String productCode;

    @Column(name = "ivybase__short_description__c")
    private String productDescription;

    @Column(name = "ivybase__is_competitor__c")
    private boolean competitor;

    @Column(name = "isdeleted")
    private boolean isDeleted;
}
