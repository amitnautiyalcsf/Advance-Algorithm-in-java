
package com.bat.veoassortmentextractor.soap;

import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Customer complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Customer">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="SOLD_TO_ERP_NUMBER" type="{http://veo.bat.biz/v2/veoAssortmentSchema}NonEmptyString"/>
 *         &lt;element name="PRODUCTS" type="{http://veo.bat.biz/v2/veoAssortmentSchema}Products"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Customer", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", propOrder = {
    "soldtoerpnumber",
    "products"
})
@Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
public class Customer {

    @XmlElement(name = "SOLD_TO_ERP_NUMBER", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", required = true)
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected String soldtoerpnumber;
    @XmlElement(name = "PRODUCTS", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", required = true)
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected Products products;

    /**
     * Gets the value of the soldtoerpnumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public String getSOLDTOERPNUMBER() {
        return soldtoerpnumber;
    }

    /**
     * Sets the value of the soldtoerpnumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setSOLDTOERPNUMBER(String value) {
        this.soldtoerpnumber = value;
    }

    /**
     * Gets the value of the products property.
     * 
     * @return
     *     possible object is
     *     {@link Products }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public Products getPRODUCTS() {
        return products;
    }

    /**
     * Sets the value of the products property.
     * 
     * @param value
     *     allowed object is
     *     {@link Products }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setPRODUCTS(Products value) {
        this.products = value;
    }

}
