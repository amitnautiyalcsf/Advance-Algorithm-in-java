package com.bat.veoassortmentextractor.DTO;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.stream.Stream;

@Getter
@Setter
@ToString
@AllArgsConstructor
public class AssortmentProductDTO implements Cloneable {

    public static final String FOR_PROCESS = "process";
    public static final String FOR_APPLY = "apply";
    public static final String FOR_DROP = "drop";

    private String sequence;
    private String materialNumber;
    private String uom;
    private boolean halfCarton;
    private boolean featured;
    private boolean strategic;
    private String tskuSalesforceId;
    private String priceListName;
    private LocalDateTime tskuModDttm;
    private LocalDateTime mskuModDttm;
    private DtoDesignation designation = DtoDesignation.PROCESS;

    public AssortmentProductDTO() {
        sequence = "";
        materialNumber = "";
        uom = "";
        tskuSalesforceId = "";
    }

    @Override
    public AssortmentProductDTO clone() {
        AssortmentProductDTO result = new AssortmentProductDTO();
        try {
            result = (AssortmentProductDTO) super.clone();
        } catch (CloneNotSupportedException e) {
            e.printStackTrace();
        }

        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof AssortmentProductDTO)) {
            return false;
        }

        AssortmentProductDTO other = (AssortmentProductDTO) obj;

        return tskuSalesforceId.equals(other.tskuSalesforceId);
    }

    public enum DtoDesignation {

        PROCESS(FOR_PROCESS),
        APPLY(FOR_APPLY),
        DROP(FOR_DROP);

        private String action;

        DtoDesignation(String action) {
            this.action = action;
        }

        public static DtoDesignation fromActionString(String actionString) {
            return Stream.of(values())
                    .filter(dtoDesignation -> dtoDesignation.getAction().equalsIgnoreCase(actionString))
                    .findFirst()
                    .orElse(PROCESS);
        }

        public String getAction() {
            return action;
        }
    }
}
