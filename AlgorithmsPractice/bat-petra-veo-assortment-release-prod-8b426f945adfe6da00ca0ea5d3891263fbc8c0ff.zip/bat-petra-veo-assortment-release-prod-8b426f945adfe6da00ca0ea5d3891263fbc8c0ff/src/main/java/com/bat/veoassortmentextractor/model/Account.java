package com.bat.veoassortmentextractor.model;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "account", schema = "salesforce")
@Getter
@Setter
@ToString
public class Account extends IvyEntity {

    @Column(name = "ivybat__sap_customerid__c")
    private String sapCustomerId;

    @Column(name="ivybat__market_iso__c", length = 2)
    private String marketISO;

    @Column(name="ivybat__enable_online_order__c")
    private boolean onlineOrder;

    @Column(name="ivybase__Status__c")
    private String status;

    @Column(name="pricing_group__c")
    private String priceListName;

    @Column(name = "isdeleted")
    private boolean isDeleted;
}
