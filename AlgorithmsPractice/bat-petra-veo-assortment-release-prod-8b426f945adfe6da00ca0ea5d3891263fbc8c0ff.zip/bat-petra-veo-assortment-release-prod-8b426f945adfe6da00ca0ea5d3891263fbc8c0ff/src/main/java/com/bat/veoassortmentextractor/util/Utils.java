package com.bat.veoassortmentextractor.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class Utils {

    private static final Logger logger = LoggerFactory.getLogger(Utils.class);

    private Utils() {
        throw new UnsupportedOperationException("This class shouldn't be instantiated directly");
    }

    public static String trimLeadingZeros(String stringToTrim) {
        return trimLeadingChars(stringToTrim, '0');
    }

    public static String trimLeadingChars(String stringToTrim, final char charToTrim) {
        logger.trace("trimLeadingChars(), string to trim: [{}], char to remove from beginning: [{}]", stringToTrim, charToTrim);
        String result = "";

        if (null != stringToTrim) {
            int indexOfFirstProperChar = stringToTrim.length();
            for (int i = 0; i < stringToTrim.length(); i++) {
                if (stringToTrim.charAt(i) != charToTrim) {
                    indexOfFirstProperChar = i;
                    break;
                }
            }

            result = stringToTrim.substring(indexOfFirstProperChar);
        }

        logger.trace("result after trimming [{}]", result);
        return result;
    }
}
