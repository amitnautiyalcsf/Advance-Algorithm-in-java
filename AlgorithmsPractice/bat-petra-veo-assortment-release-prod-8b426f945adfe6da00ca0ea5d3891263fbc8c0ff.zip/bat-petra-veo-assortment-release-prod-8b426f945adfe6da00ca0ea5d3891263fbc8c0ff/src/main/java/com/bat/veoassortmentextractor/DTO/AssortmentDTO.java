package com.bat.veoassortmentextractor.DTO;

import lombok.*;

import java.util.LinkedHashSet;
import java.util.Set;

@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class AssortmentDTO {

    private String customerId;
    private String marketIso;
    // TODO:MP do we really need set here?
    private Set<AssortmentProductDTO> products = new LinkedHashSet<>();

}
