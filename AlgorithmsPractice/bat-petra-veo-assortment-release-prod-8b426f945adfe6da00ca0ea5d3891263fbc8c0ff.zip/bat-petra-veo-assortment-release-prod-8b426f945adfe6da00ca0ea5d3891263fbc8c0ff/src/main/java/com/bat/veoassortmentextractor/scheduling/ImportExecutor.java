package com.bat.veoassortmentextractor.scheduling;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

@Service
public class ImportExecutor {

    private static final Logger logger = LoggerFactory.getLogger(ImportExecutor.class);

    private final ScheduledThreadPoolExecutor workers;

    @Autowired
    public ImportExecutor(@Value("${veo.schedule.thread-number}") int runningNumberOfWorkers) {

        logger.debug("ImportExecutor object configured to run on [{}] threads workers", runningNumberOfWorkers);
        workers = new ScheduledThreadPoolExecutor(runningNumberOfWorkers);
    }

    public void scheduleImportJob(Runnable job, LocalDateTime dateOfExecution) {
        logger.debug("scheduling new job with given time of execution: [{}]", dateOfExecution);

        workers.schedule(job, calculateJobDelayInMillisBasedOnProvidedArg(dateOfExecution), TimeUnit.MILLISECONDS);
    }

    private static long calculateJobDelayInMillisBasedOnProvidedArg(LocalDateTime dateOfJobExecution) {
        long delayInMiliSecs = 0;
        LocalDateTime currentDateTime = LocalDateTime.now(ZoneId.of("UTC"));
        if (null != dateOfJobExecution && currentDateTime.isBefore(dateOfJobExecution)) {
            delayInMiliSecs = Duration.between(currentDateTime, dateOfJobExecution).toMillis();
        }

        logger.debug("calculated delay for task with desired time of execution [{}] is [{}][ms]", dateOfJobExecution, delayInMiliSecs);

        return delayInMiliSecs;
    }
}
