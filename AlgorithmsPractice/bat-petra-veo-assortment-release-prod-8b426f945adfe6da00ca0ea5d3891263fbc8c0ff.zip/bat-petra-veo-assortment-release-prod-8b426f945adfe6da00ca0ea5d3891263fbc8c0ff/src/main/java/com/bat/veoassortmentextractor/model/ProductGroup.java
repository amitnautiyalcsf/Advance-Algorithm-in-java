package com.bat.veoassortmentextractor.model;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.Set;

@Entity
@Table(name = "ivybase__product_group__c", schema = "salesforce")
@Getter
@Setter
public class ProductGroup extends IvyEntity {

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "ivybat__Plan__c", referencedColumnName = "sfid")
    private Plan plan;

    @Column(name = "lastmodifieddate")
    private LocalDate lastModifiedDate;

    @OneToMany(mappedBy = "productGroup", fetch = FetchType.LAZY)
    private Set<ProductGroupDetail> productGroupDetail;

    @Column(name = "isdeleted")
    private boolean isDeleted;
}
