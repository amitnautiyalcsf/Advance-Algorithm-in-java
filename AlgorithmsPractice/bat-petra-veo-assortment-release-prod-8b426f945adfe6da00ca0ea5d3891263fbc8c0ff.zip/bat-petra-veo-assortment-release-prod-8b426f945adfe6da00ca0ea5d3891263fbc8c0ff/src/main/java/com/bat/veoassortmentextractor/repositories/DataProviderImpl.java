package com.bat.veoassortmentextractor.repositories;

import com.bat.veoassortmentextractor.DTO.AssortmentProductDTO;
import com.bat.veoassortmentextractor.model.Account;
import com.bat.veoassortmentextractor.model.EndMarketConfiguration;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

import static com.bat.veoassortmentextractor.DTO.AssortmentProductDTO.DtoDesignation.fromActionString;

@Repository
@Slf4j
public class DataProviderImpl implements DataProvider {

    private final AccountRepository accountRepository;
    private final JdbcTemplate jdbcTemplate;
    private final EndMarketConfigurationRepository endMarketConfigurationRepository;

    final private BiFunction<ResultSet, Integer, Account> accountResultMapper = (rs, rowNum) -> {
        Account account = new Account();
        try {
            account.setSapCustomerId(rs.getString("ivybat__sap_customerid__c"));
            account.setPriceListName(rs.getString("pricing_group__c"));
            account.setMarketISO(rs.getString("ivybat__market_iso__c"));
            account.setSfId(rs.getString("account_sfid"));
        } catch (SQLException exc) {
            log.warn("exception occurred during extraction data from ResultSet", exc);
            throw new RuntimeException(exc);
        }
        return account;
    };

    public DataProviderImpl(AccountRepository accountRepository, JdbcTemplate jdbcTemplate,
                            EndMarketConfigurationRepository endMarketConfigurationRepository) {
        this.accountRepository = accountRepository;
        this.jdbcTemplate = jdbcTemplate;
        this.endMarketConfigurationRepository = endMarketConfigurationRepository;
    }

    @Override
    public void updateLastExecutionDate(EndMarketConfiguration configuration) {
        endMarketConfigurationRepository.save(configuration);
    }

    @Override
    public Map<String, List<AssortmentProductDTO>> getPriceListsWithAssignedProducts(EndMarketConfiguration endMarketConfiguration) {

        String query = "" +
                "select *                                                                                                                      \n" +
                "from (select ROW_NUMBER()                                                                                                     \n" +
                "                 OVER (PARTITION BY pl.name, p.ivybase__Primary_Product__c ORDER BY p.ispriority__c DESC, p.createddate DESC) \n" +
                "                                                                      as nr,                                                  \n" +
                "             pl.name                                                  as price_list_name,                                     \n" +
                "             prod.ivybat__code__c                                     as product_code,                                        \n" +
                "             rt.name                                                  as sku_type,                                            \n" +
                "             p.ivybase__short_description__c,                                                                                 \n" +
                "             p.ivybat__Material_ERPNumber__c,                                                                                 \n" +
                "             coalesce(p.ivybat__Sales_Unit_Of_Measure__c, p.uom_1__c) as ivybat__Sales_Unit_Of_Measure__c,                    \n" +
                "             p.Half_Of_High_UOM__c,                                                                                           \n" +
                "             p.lastmodifieddate                                       as msku_product_mod_dttm,                               \n" +
                "             tsku.sfid                                                as tsku_sfid,                                           \n" +
                "             ple.ivybase__product__c                                  as ple_prod_id,                                         \n" +
                "             tsku.ivybat__code__c                                     as tsku_product,                                        \n" +
                "             tsku.lastmodifieddate                                    as tsku_product_mod_dttm                                \n" +
                "      from salesforce.ivybase__price_list__c pl                                                                               \n" +
                "             join salesforce.ivybase__price_list_entrie__c ple                                                                \n" +
                "                  on pl.sfid = ple.ivybase__price_list__c                                                                     \n" +
                "                    and ple.valid_from__c <= CURRENT_DATE                                                                     \n" +
                "                    and ple.valid_to__c >= CURRENT_DATE                                                                       \n" +
                "                    and ple.ivybase__active__c = 'Yes'                                                                        \n" +
                "                    and pl.isdeleted = false                                                                                  \n" +
                "                    and ple.isdeleted = false                                                                                 \n" +
                "             join salesforce.ivybase__product__c prod on ple.ivybase__product__c = prod.sfid                                  \n" +
                "                    and prod.ivybat__status__c = 'Active'                                                                     \n" +
                "                    and prod.ivybase__active__c = 'Yes'                                                                       \n" +
                "                    and prod.isdeleted = false                                                                                \n" +
                "             join (select p.*                                                                                                 \n" +
                "                   from salesforce.ivybase__product__c p                                                                      \n" +
                "                          join salesforce.recordtype rt on p.recordtypeid = rt.sfid                                           \n" +
                "                   where p.foc__c = false                                                                                     \n" +
                "                     and p.ivybat__status__c = 'Active'                                                                       \n" +
                "                     and p.ivybase__active__c = 'Yes'                                                                         \n" +
                "                     and rt.name = 'Manufacturing SKU'                                                                        \n" +
                "                     and p.ivybase__is_competitor__c = false                                                                  \n" +
                "                     and p.isdeleted = false                                                                                  \n" +
                "                     and rt.isactive = true                                                                                   \n" +
                "                  ) p on prod.ivybase__primary_product__c = p.ivybase__primary_product__c                                     \n" +
                "             join salesforce.ivybase__product__c tsku on tsku.sfid = prod.ivybase__Primary_Product__c                         \n" +
                "                  and tsku.ivybase__non_saleable__c = false                                                                   \n" +
                "                  and tsku.isdeleted = false                                                                                  \n" +
                "                  and tsku.ivybat__status__c = 'Active'                                                                       \n" +
                "                  and tsku.ivybase__active__c = 'Yes'                                                                         \n" +
                "             join salesforce.recordtype rt on p.recordtypeid = rt.sfid                                                        \n" +
                "                 and rt.isactive = true                                                                                       \n" +
                "      where pl.market_iso__c = ?                                                                                              \n" +
                "        and pl.ivybase__active__c = 'Yes'                                                                                     \n" +
                "     ) A                                                                                                                      \n" +
                "where nr = 1                                                                                                                  \n";
        List<AssortmentProductDTO> jdbcResult = jdbcTemplate.query(query, new Object[]{endMarketConfiguration.getMarketISO()},
                (rs, rowNum) -> {
                    AssortmentProductDTO productDTO = new AssortmentProductDTO();
                    productDTO.setPriceListName(rs.getString("price_list_name"));
                    productDTO.setMaterialNumber(rs.getString("ivybat__Material_ERPNumber__c"));
                    productDTO.setUom(rs.getString("ivybat__Sales_Unit_Of_Measure__c"));
                    productDTO.setHalfCarton(rs.getBoolean("Half_Of_High_UOM__c"));
                    productDTO.setTskuSalesforceId(rs.getString("tsku_sfid"));
                    productDTO.setTskuModDttm(rs.getTimestamp("tsku_product_mod_dttm").toLocalDateTime());
                    productDTO.setMskuModDttm(rs.getTimestamp("msku_product_mod_dttm").toLocalDateTime());
                    return productDTO;
                }
        );

        return jdbcResult
                .stream()
                .collect(Collectors.groupingBy(AssortmentProductDTO::getPriceListName));
    }

    @Override
    public List<String> getPriceListsWithModifiedProducts(EndMarketConfiguration endMarketConfiguration) {

        String query = "" +
                "select distinct price_list_name                                                                                               \n" +
                "from (select ROW_NUMBER()                                                                                                     \n" +
                "                 OVER (PARTITION BY pl.name, p.ivybase__Primary_Product__c ORDER BY p.ispriority__c DESC, p.createddate DESC) \n" +
                "                                                                      as nr,                                                  \n" +
                "             pl.name                                                  as price_list_name                                      \n" +
                "      from salesforce.ivybase__price_list__c pl                                                                               \n" +
                "             join salesforce.ivybase__price_list_entrie__c ple                                                                \n" +
                "                  on pl.sfid = ple.ivybase__price_list__c                                                                     \n" +
                "                    and ple.valid_from__c <= CURRENT_DATE                                                                     \n" +
                "                    and ple.valid_to__c >= CURRENT_DATE                                                                       \n" +
                "             join salesforce.ivybase__product__c prod on ple.ivybase__product__c = prod.sfid                                  \n" +
                "             join (select p.*                                                                                                 \n" +
                "                   from salesforce.ivybase__product__c p                                                                      \n" +
                "                          join salesforce.recordtype rt on p.recordtypeid = rt.sfid                                           \n" +
                "                   where p.foc__c = false                                                                                     \n" +
                "                     and rt.name = 'Manufacturing SKU'                                                                        \n" +
                "                     and p.ivybase__is_competitor__c = false                                                                  \n" +
                "                  ) p on prod.ivybase__primary_product__c = p.ivybase__primary_product__c                                     \n" +
                "             join salesforce.ivybase__product__c tsku on tsku.sfid = prod.ivybase__Primary_Product__c                         \n" +
                "                  and tsku.ivybase__non_saleable__c = false                                                                   \n" +
                "             join salesforce.recordtype rt on p.recordtypeid = rt.sfid                                                        \n" +
                "                 and rt.isactive = true                                                                                       \n" +
                "      where pl.market_iso__c = ?                                                                                              \n" +
                "        and pl.ivybase__active__c = 'Yes'                                                                                     \n" +
                "        and (p.lastmodifieddate >= ?                                                                                          \n" +
                "        or tsku.lastmodifieddate >= ?)                                                                                        \n" +
                "     ) A                                                                                                                      \n" +
                "where nr = 1                                                                                                                  \n";
        return jdbcTemplate.query(query, new Object[]{endMarketConfiguration.getMarketISO(),
                        endMarketConfiguration.getLastExecutionDate(), endMarketConfiguration.getLastExecutionDate()},
                (rs, rowNum) -> rs.getString("price_list_name")
        );
    }

    @Override
    public List<Account> findAllOnlineActiveCustomers(String marketIso) {
        return accountRepository.findAllOnlineActiveCustomers(marketIso);
    }

    @Override
    public List<Account> findAllCustomersWithGivenPriceLists(String marketIso, List<String> priceLists) {
        List<Account> result = accountRepository.findAllOnlineActiveCustomersForPriceLists(marketIso, priceLists);

        log.debug("findAllCustomersWithGivenPriceLists() - query returned list with [{}] items", result.size());
        return result;
    }

    @Override
    public List<Account> findOnlineActiveCustomersByErpNumbers(String marketIso, List<String> erpNumbers) {
        List<Account> result = accountRepository.findOnlineActiveCustomersByErpNumbers(marketIso, erpNumbers);
        log.debug("findOnlineActiveCustomersByErpNumbers() - query returned list with [{}] items", result.size());

        return result;
    }

    @Override
    public List<Account> findAccountsFromNewPlan(String marketISO) {

        String query = "" +
                "select                                                                                                             \n" +
                "   distinct                                                                                                        \n" +
                "   a.sfid as account_sfid,                                                                                         \n" +
                "   a.pricing_group__c,                                                                                             \n" +
                "   a.ivybat__sap_customerid__c,                                                                                    \n" +
                "   a.ivybat__market_iso__c                                                                                         \n" +
                "from salesforce.ivybat__plan__c pl                                                                                 \n" +
                "   join salesforce.ivybase__product_group__c pg on pl.sfid = pg.ivybat__plan__c                                    \n" +
                "       and pl.isdeleted = false                                                                                    \n" +
                "       and pg.isdeleted = false                                                                                    \n" +
                "   join salesforce.ivybase__product_group_detail__c pgd on pgd.ivybase__product_group__c = pg.sfid                 \n" +
                "       and pgd.isdeleted = false                                                                                   \n" +
                "   join salesforce.account a on a.sfid = pgd.ivybat__outlet__c                                                     \n" +
                "       and a.ivybat__enable_online_order__c = true                                                                 \n" +
                "       and a.ivybase__Status__c <> 'Permanently Deactivated'                                                       \n" +
                "       and a.isdeleted = false                                                                                     \n" +
                "where                                                                                                              \n" +
                "   pl.ivybat__start_date__c = CURRENT_DATE                                                                         \n" +
                "    and pl.ivybat__market_iso__c = ?                                                                               \n" +
                "    and pgd.ivybat__product_group_record_type__c = 'Stock_Assortment'                                              \n";

        List<Account> result = jdbcTemplate.query(query, new Object[]{marketISO}, accountResultMapper::apply);

        log.debug("findAccountsFromNewPlan() - query returned list with [{}] items", result.size());
        return result;
    }

    @Override
    public List<Account> findAccountsWhichProductGroupDetailsInPlanWasModified(EndMarketConfiguration configuration) {
        String query = "" +
                "select                                                                                                             \n" +
                "   distinct                                                                                                        \n" +
                "   pl.sfid as plan_id,                                                                                             \n" +
                "   pg.sfid as product_group_id,                                                                                    \n" +
                "   pgd.ivybat__outlet__c,                                                                                          \n" +
                "   a.pricing_group__c,                                                                                             \n" +
                "   a.ivybat__market_iso__c,                                                                                        \n" +
                "   a.ivybat__sap_customerid__c,                                                                                    \n" +
                "   a.sfid as account_sfid                                                                                          \n" +
                "from salesforce.ivybat__plan__c pl                                                                                 \n" +
                "   join salesforce.ivybase__product_group__c pg on pl.sfid = pg.ivybat__plan__c                                    \n" +
                "       and pl.isdeleted = false                                                                                    \n" +
                "       and pg.isdeleted = false                                                                                    \n" +
                "   join salesforce.ivybase__product_group_detail__c pgd on pgd.ivybase__product_group__c = pg.sfid                 \n" +
                "      and pgd.isdeleted = false                                                                                    \n" +
                "   join salesforce.account a on a.sfid = pgd.ivybat__outlet__c                                                     \n" +
                "       and a.ivybat__enable_online_order__c = true                                                                 \n" +
                "       and a.ivybase__Status__c <> 'Permanently Deactivated'                                                       \n" +
                "       and a.isdeleted = false                                                                                     \n" +
                "where                                                                                                              \n" +
                "   pl.ivybat__end_date__c > CURRENT_DATE                                                                           \n" +
                "   and pl.ivybat__start_date__c <= CURRENT_DATE                                                                    \n" +
                "   and pl.ivybat__market_iso__c = ?                                                                                \n" +
                "   and pgd.ivybat__product_group_record_type__c = 'Stock_Assortment'                                               \n" +
                "   and pgd.lastmodifieddate > ?                                                                                    \n";
        List<Account> result = jdbcTemplate.query(query, new Object[]{configuration.getMarketISO(), configuration.getLastExecutionDate()},
                accountResultMapper::apply);

        log.debug("findAccountsWhichProductGroupDetailsInPlanWasModified() - query returned list with [{}] items", result.size());
        return result;
    }

    @Override
    public List<Account> findAccountsAssociatedWithPlanForWhichAnyProductWasModified(EndMarketConfiguration configuration) {
        String query = "" +
                "select                                                                                                 \n" +
                "   distinct                                                                                            \n" +
                "   pl.sfid as plan_id,                                                                                 \n" +
                "   pg.sfid as product_group_id,                                                                        \n" +
                "   pgd.ivybat__outlet__c,                                                                              \n" +
                "   a.pricing_group__c,                                                                                 \n" +
                "   a.ivybat__market_iso__c,                                                                            \n" +
                "   a.ivybat__sap_customerid__c,                                                                        \n" +
                "   a.sfid as account_sfid                                                                              \n" +
                "from salesforce.ivybat__plan__c pl                                                                     \n" +
                "   join salesforce.ivybase__product_group__c pg on pl.sfid = pg.ivybat__plan__c                        \n" +
                "       and pl.isdeleted = false                                                                        \n" +
                "       and pg.isdeleted = false                                                                        \n" +
                "   join salesforce.ivybase__product_group_detail__c pgd on pgd.ivybase__product_group__c = pg.sfid     \n" +
                "       and pgd.isdeleted = false                                                                       \n" +
                "   join salesforce.ivybase__product__c tsku on tsku.sfid = pgd.ivybase__product__c                     \n" +
                "       and tsku.isdeleted = false                                                                      \n" +
                "   join salesforce.account a on a.sfid = pgd.ivybat__outlet__c                                         \n" +
                "       and a.ivybat__enable_online_order__c = true                                                     \n" +
                "       and a.ivybase__Status__c <> 'Permanently Deactivated'                                           \n" +
                "       and a.isdeleted = false                                                                         \n" +
                "where                                                                                                  \n" +
                "   pl.ivybat__end_date__c > CURRENT_DATE                                                               \n" +
                "   and pl.ivybat__start_date__c <= CURRENT_DATE                                                        \n" +
                "   and pl.ivybat__market_iso__c = ?                                                                    \n" +
                "   and pgd.ivybat__product_group_record_type__c = 'Stock_Assortment'                                   \n" +
                "   and tsku.lastmodifieddate > ?                                                                       \n";

        List<Account> result = jdbcTemplate.query(query, new Object[]{configuration.getMarketISO(), configuration.getLastExecutionDate()},
                accountResultMapper::apply);

        log.debug("findAccountsAssociatedWithPlanForWhichAnyProductWasModified() - query returned list with [{}] items", result.size());
        return result;
    }

    @Override
    public List<AssortmentProductDTO> findProductsFromActivePlanForAccount(Account account) {
        String query = "" +
                "select                                                                                                     \n" +
                "   pgd.ivybat__outlet__c,                                                                                  \n" +
                "   pgd.ivybase__category__c,                                                                               \n" +
                "   cast(pgd.ivybase__sequence__c as integer) as ivybase__sequence__c,                                      \n" +
                "   pgd.ivybase__product__c,                                                                                \n" +
                "   pgd.ivybat__market_iso__c,                                                                              \n" +
                "   (case when pgd.ivybase__category__c = 'Priority' then true else false end) as isStrategic,              \n" +
                "   false as isTactical,                                                                                    \n" +
                "   (case when pgd.ivybase__category__c = 'Opportunity' then true else false end) as isFeatured,            \n" +
                "   (case when pgd.ivybase__category__c in ('Priority','Opportunity') then 'apply'                          \n" +
                "         when pgd.ivybase__category__c in ('Soft De-List', 'Hard De-List', 'Dryout', 'Recall') then 'drop' \n" +
                "         else 'process' end) as designation                                                                \n" +
                "from salesforce.ivybat__plan__c pl                                                                         \n" +
                "   join salesforce.ivybase__product_group__c pg on pl.sfid = pg.ivybat__plan__c                            \n" +
                "       and pl.isdeleted = false                                                                            \n" +
                "       and pg.isdeleted = false                                                                            \n" +
                "   join salesforce.ivybase__product_group_detail__c pgd on pgd.ivybase__product_group__c = pg.sfid         \n" +
                "       and pgd.isdeleted = false                                                                           \n" +
                "where                                                                                                      \n" +
                "   pl.ivybat__end_date__c >= CURRENT_DATE                                                                  \n" +
                "   and pl.ivybat__start_date__c <= CURRENT_DATE                                                            \n" +
                "   and pl.ivybat__market_iso__c = ?                                                                        \n" +
                "   and pgd.ivybat__outlet__c = ?                                                                           \n" +
                "   and pgd.ivybat__product_group_record_type__c = 'Stock_Assortment'                                       \n";
        List<AssortmentProductDTO> result = jdbcTemplate.query(query, new Object[]{account.getMarketISO(), account.getSfId()},
                (rs, rowNum) -> {
                    AssortmentProductDTO productDTO = new AssortmentProductDTO();
                    productDTO.setSequence(rs.getString("ivybase__sequence__c"));
                    productDTO.setFeatured(rs.getBoolean("isFeatured"));
                    productDTO.setStrategic(rs.getBoolean("isStrategic"));
                    productDTO.setTskuSalesforceId(rs.getString("ivybase__product__c"));
                    productDTO.setDesignation(fromActionString(rs.getString("designation")));
                    return productDTO;
                }
        );

        log.debug("findProductsFromActivePlanForAccount() - query returned list with [{}] items", result.size());
        return result;
    }
}
