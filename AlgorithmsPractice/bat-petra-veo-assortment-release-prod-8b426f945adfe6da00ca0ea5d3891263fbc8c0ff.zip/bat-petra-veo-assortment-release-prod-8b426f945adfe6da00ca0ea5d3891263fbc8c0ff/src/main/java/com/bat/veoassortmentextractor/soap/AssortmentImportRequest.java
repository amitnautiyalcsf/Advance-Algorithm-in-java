
package com.bat.veoassortmentextractor.soap;

import javax.annotation.Generated;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="MARKET_IDENTIFIER" type="{http://veo.bat.biz/v2/veoAssortmentSchema}NonEmptyString"/>
 *         &lt;element name="CUSTOMERS" type="{http://veo.bat.biz/v2/veoAssortmentSchema}Customers"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "marketidentifier",
    "customers"
})
@XmlRootElement(name = "assortmentImportRequest", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema")
@Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
public class AssortmentImportRequest {

    @XmlElement(name = "MARKET_IDENTIFIER", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", required = true)
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected String marketidentifier;
    @XmlElement(name = "CUSTOMERS", namespace = "http://veo.bat.biz/v2/veoAssortmentSchema", required = true)
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    protected Customers customers;

    /**
     * Gets the value of the marketidentifier property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public String getMARKETIDENTIFIER() {
        return marketidentifier;
    }

    /**
     * Sets the value of the marketidentifier property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setMARKETIDENTIFIER(String value) {
        this.marketidentifier = value;
    }

    /**
     * Gets the value of the customers property.
     * 
     * @return
     *     possible object is
     *     {@link Customers }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public Customers getCUSTOMERS() {
        return customers;
    }

    /**
     * Sets the value of the customers property.
     * 
     * @param value
     *     allowed object is
     *     {@link Customers }
     *     
     */
    @Generated(value = "com.sun.tools.internal.xjc.Driver", date = "2019-04-29T01:05:03+02:00", comments = "JAXB RI v2.2.8-b130911.1802")
    public void setCUSTOMERS(Customers value) {
        this.customers = value;
    }

}
