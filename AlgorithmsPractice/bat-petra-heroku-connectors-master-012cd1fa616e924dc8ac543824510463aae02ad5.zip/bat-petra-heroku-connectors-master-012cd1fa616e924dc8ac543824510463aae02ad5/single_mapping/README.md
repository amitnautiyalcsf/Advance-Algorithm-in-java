##Procedure of deployment to Heroku via Heroku CLI
1. Install Heroku CLI
2. Open your cmd.
2. Login with ```heroku login```
4. To deploy on all non-prod environments run the following:
```
   heroku connect:import bat_petra_heroku_connector_mapping.json -a batapp-petra-hc-blue-dev
   heroku connect:import bat_petra_heroku_connector_mapping.json -a batapp-petra-hc-yellow-dev
   
   heroku connect:import bat_petra_heroku_connector_mapping.json -a batapp-petra-hc-yellow-qa
   heroku connect:import bat_petra_heroku_connector_mapping.json -a batapp-petra-hc-blue-qa
   
   heroku connect:import bat_petra_heroku_connector_mapping.json -a batapp-petra-hc-yellow-uat
   heroku connect:import bat_petra_heroku_connector_mapping.json -a batapp-petra-hc-green-uat
   heroku connect:import bat_petra_heroku_connector_mapping.json -a batapp-petra-hc-blue-uat
   
   heroku connect:import bat_petra_heroku_connector_mapping.json -a batapp-ne-connector-brz-uat
   heroku connect:import bat_petra_heroku_connector_mapping.json -a batapp-ne-connector-brz-fat
```

##Attaching Database to Heroku App
####Creating new user
1. Navigate to Postgres ```credentials``` tab.
2. Create new Credential.
3. Type in username and initial priviliges (Read-only or Read-write)
4. Save
####Attaching database to app
1. Choose your new user from dropdown.
2. Navigate to Attchment box, find app on the list and click attach.
3. Using Heroku CLI run command ```heroku pg:promote [credentialName] --app [appName]```

NOTE: [credentialName] can be found above box with apps. For example:



```CIS_TARGETING``` on bat-cis-targeting-blue-uat 

the credentialName would be in this case ```CIS_TARGETTING```

