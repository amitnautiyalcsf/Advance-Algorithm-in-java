package com.bat.veoassortmentprocessor.soap;

public class VeoResponse {

    private String response;

    public VeoResponse() {
    }

    public VeoResponse(String response) {
        this.response = response;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }
}
