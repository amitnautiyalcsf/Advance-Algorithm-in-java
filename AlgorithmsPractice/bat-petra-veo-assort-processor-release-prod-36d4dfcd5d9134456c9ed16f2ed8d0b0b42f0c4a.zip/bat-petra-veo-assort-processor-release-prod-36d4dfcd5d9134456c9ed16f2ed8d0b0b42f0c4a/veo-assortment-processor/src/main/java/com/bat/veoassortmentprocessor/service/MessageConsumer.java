package com.bat.veoassortmentprocessor.service;

import org.springframework.amqp.core.Message;

public interface MessageConsumer {

    void processMessage(Message payload);
}
