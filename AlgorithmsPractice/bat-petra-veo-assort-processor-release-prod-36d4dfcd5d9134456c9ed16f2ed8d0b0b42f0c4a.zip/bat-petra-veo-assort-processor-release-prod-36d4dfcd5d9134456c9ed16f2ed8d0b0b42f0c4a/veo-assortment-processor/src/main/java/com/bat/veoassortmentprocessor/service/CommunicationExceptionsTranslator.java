package com.bat.veoassortmentprocessor.service;

import com.bat.veoassortmentprocessor.model.CommunicationResult;

public interface CommunicationExceptionsTranslator {

    CommunicationResult translateException(Exception exc);
}
