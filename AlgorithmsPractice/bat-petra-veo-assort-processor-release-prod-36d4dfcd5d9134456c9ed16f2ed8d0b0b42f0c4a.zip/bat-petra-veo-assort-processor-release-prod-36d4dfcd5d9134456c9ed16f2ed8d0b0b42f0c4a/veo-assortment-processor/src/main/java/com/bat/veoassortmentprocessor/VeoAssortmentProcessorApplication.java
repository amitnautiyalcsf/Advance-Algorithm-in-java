package com.bat.veoassortmentprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VeoAssortmentProcessorApplication {

    public static void main(String[] args) {
        SpringApplication.run(VeoAssortmentProcessorApplication.class, args);
    }
}
