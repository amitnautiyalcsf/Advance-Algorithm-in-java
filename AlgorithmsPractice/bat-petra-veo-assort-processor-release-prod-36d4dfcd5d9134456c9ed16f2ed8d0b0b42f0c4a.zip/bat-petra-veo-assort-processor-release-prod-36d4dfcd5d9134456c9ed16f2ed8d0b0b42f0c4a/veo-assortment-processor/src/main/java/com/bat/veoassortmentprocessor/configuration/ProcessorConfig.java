package com.bat.veoassortmentprocessor.configuration;

import com.bat.veoassortmentprocessor.service.CommunicationExceptionsTranslator;
import com.bat.veoassortmentprocessor.service.impl.WebServiceMessageSender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.ws.soap.security.wss4j2.Wss4jSecurityInterceptor;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.Optional;

@Configuration
public class ProcessorConfig {

    private static final Logger logger = LoggerFactory.getLogger(ProcessorConfig.class);

    private String rabbitMqHost;
    private int rabbitMqPort;
    private String rabbitMqRoutingKey;
    private String rabbitMqUsername;
    private String rabbitMqPassword;
    private String messageAddressKeyName;

    public String getMessageAddressKeyName() {
        return messageAddressKeyName;
    }

    @Autowired
    void setMessageAddressKeyName(@Value("${message.header.address-key-name}") String messageAddressKeyName) {
        this.messageAddressKeyName = messageAddressKeyName;
    }

    public String getRabbitMqHost() {
        return rabbitMqHost;
    }

    @Autowired
    void setRabbitMqHost(@Value("${spring.rabbitmq.host}") String rabbitMqHost) {
        logger.debug("rabbitmq.host from config: [{}]", rabbitMqHost);
        this.rabbitMqHost = rabbitMqHost;
    }

    public int getRabbitMqPort() {
        return rabbitMqPort;
    }

    @Autowired
    void setRabbitMqPort(@Value("${spring.rabbitmq.port}") int rabbitMqPort) {
        logger.debug("rabbitmq.port from config: [{}]", rabbitMqPort);
        this.rabbitMqPort = rabbitMqPort;
    }

    public String getRabbitMqRoutingKey() {
        return rabbitMqRoutingKey;
    }

    @Autowired
    void setRabbitMqRoutingKey(@Value("${spring.rabbitmq.template.routing-key}") String rabbitMqRoutingKey) {
        logger.debug("rabbitmq.routing-key from config: [{}]", rabbitMqRoutingKey);
        this.rabbitMqRoutingKey = rabbitMqRoutingKey;
    }

    public String getRabbitMqUsername() {
        return rabbitMqUsername;
    }

    @Autowired
    void setRabbitMqUsername(@Value("${spring.rabbitmq.username}") String rabbitMqUsername) {
        logger.debug("rabbitmq.username from config: [{}]", rabbitMqUsername);
        this.rabbitMqUsername = rabbitMqUsername;
    }

    public String getRabbitMqPassword() {
        return rabbitMqPassword;
    }

    @Autowired
    void setRabbitMqPassword(@Value("${spring.rabbitmq.password}") String rabbitMqPassword) {
        logger.debug("rabbitmq.password from config: [{}]", rabbitMqPassword);
        this.rabbitMqPassword = rabbitMqPassword;
    }

    @Bean
    Queue veoQueue(@Value("#{processorConfig.rabbitMqRoutingKey}") String queueName) {
        return new Queue(queueName);
    }

    @Bean
    public ConnectionFactory connectionFactory() {
        final CachingConnectionFactory factory = new CachingConnectionFactory();

        Optional<String> amqpConnectionString = getEnvVarValue("CLOUDAMQP_URL");
        if (amqpConnectionString.isPresent()) {
            logger.debug("Trying to configure RabbitMQ by connection string");
            try {
                URI amqpUri = new URI(amqpConnectionString.get());
                final int usernameIndex = 0;
                final int passwordIndex = 1;
                factory.setUsername(amqpUri.getUserInfo().split(":")[usernameIndex]);
                factory.setPassword(amqpUri.getUserInfo().split(":")[passwordIndex]);
                factory.setHost(amqpUri.getHost());
                factory.setPort(amqpUri.getPort());
                factory.setVirtualHost(amqpUri.getPath().substring(1));
            } catch (URISyntaxException e) {
                logger.error("Error occurred during creating URI object from connection string", e);
                throw new RuntimeException("ConnectionFactory configuration error", e);
            }
        } else {
            logger.debug("Using default configuration of RabbitMQ");
            configureToDefaultValues(factory);
        }

        return factory;
    }


    @Bean
    public Jaxb2Marshaller marshaller() {
        Jaxb2Marshaller marshaller = new Jaxb2Marshaller();
        // this package must match the package in the <generatePackage> specified in
        // pom.xml
        marshaller.setContextPath("com.bat.veoassortmentprocessor.soap.wsdl");
        return marshaller;
    }

    @Bean
    public WebServiceMessageSender veoClient(Jaxb2Marshaller marshaller, CommunicationExceptionsTranslator exceptionsTranslator) {
        WebServiceMessageSender client = new WebServiceMessageSender(exceptionsTranslator);
        client.setDefaultUri("http://localhost:9000");
        client.setMarshaller(marshaller);
        client.setUnmarshaller(marshaller);
        return client;
    }

    @Bean
    public Wss4jSecurityInterceptor securityInterceptor(){
        Wss4jSecurityInterceptor wss4jSecurityInterceptor = new Wss4jSecurityInterceptor();
        wss4jSecurityInterceptor.setSecurementActions("Timestamp UsernameToken");
        wss4jSecurityInterceptor.setSecurementUsername("admin");
        wss4jSecurityInterceptor.setSecurementPassword("secret");
        return wss4jSecurityInterceptor;
    }

    private void configureToDefaultValues(CachingConnectionFactory connectionFactory) {
        connectionFactory.setUsername(rabbitMqUsername);
        connectionFactory.setPassword(rabbitMqPassword);
        connectionFactory.setHost(rabbitMqHost);
        connectionFactory.setPort(rabbitMqPort);
    }

    private Optional<String> getEnvVarValue(String envName) {
        String envValue = System.getenv(envName);

        logger.debug("Value of read environment variable [{}] is [{}]", envName, envValue);

        return Optional.ofNullable(envValue);
    }
}
