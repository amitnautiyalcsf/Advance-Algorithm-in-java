package com.bat.veoassortmentprocessor.service;

import com.bat.veoassortmentprocessor.model.CommunicationResult;

public interface MessageDestinyForwarder {

    CommunicationResult forwardMessageToDestiny(String payload, String destiny, int trialNumber);
}
