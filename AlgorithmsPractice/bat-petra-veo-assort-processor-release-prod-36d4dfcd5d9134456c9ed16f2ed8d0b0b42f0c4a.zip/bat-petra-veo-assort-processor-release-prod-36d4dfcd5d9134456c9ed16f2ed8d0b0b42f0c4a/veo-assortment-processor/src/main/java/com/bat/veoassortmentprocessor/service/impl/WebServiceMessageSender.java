package com.bat.veoassortmentprocessor.service.impl;

import com.bat.veoassortmentprocessor.model.CommunicationResult;
import com.bat.veoassortmentprocessor.model.CommunicationResult.ResultCode;
import com.bat.veoassortmentprocessor.service.CommunicationExceptionsTranslator;
import com.bat.veoassortmentprocessor.service.MessageDestinyForwarder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ws.client.core.support.WebServiceGatewaySupport;
import org.springframework.xml.transform.StringResult;
import org.springframework.xml.transform.StringSource;

import javax.xml.transform.Result;

public class WebServiceMessageSender extends WebServiceGatewaySupport implements MessageDestinyForwarder {

    private static final Logger logger = LoggerFactory.getLogger(WebServiceMessageSender.class);

    private CommunicationExceptionsTranslator exceptionTranslator;

    public WebServiceMessageSender(CommunicationExceptionsTranslator exceptionTranslator) {
        this.exceptionTranslator = exceptionTranslator;
    }

    @Override
    public CommunicationResult forwardMessageToDestiny(String payload, String destiny, int trialNumber) {
        logger.debug("sending payload [{}] to destiny [{}] - [{}] trial", payload, destiny, trialNumber);

        CommunicationResult forwardingResult;
        try {
            Result result = new StringResult();
            getWebServiceTemplate().sendSourceAndReceiveToResult(destiny, new StringSource(payload), result);

            logger.debug("received answer: [{}]", result);
            forwardingResult = new CommunicationResult(ResultCode.OK, result.toString());
        } catch (RuntimeException exc) {
            logger.warn("Exception occurred during message exchanging", exc);
            forwardingResult = exceptionTranslator.translateException(exc);
        }

        return forwardingResult;
    }
}
