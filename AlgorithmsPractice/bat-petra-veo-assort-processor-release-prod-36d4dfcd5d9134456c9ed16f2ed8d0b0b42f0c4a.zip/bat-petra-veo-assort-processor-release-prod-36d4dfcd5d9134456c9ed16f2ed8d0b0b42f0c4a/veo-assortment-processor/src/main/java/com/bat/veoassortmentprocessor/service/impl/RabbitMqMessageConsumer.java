package com.bat.veoassortmentprocessor.service.impl;

import com.bat.veoassortmentprocessor.configuration.ProcessorConfig;
import com.bat.veoassortmentprocessor.model.CommunicationResult;
import com.bat.veoassortmentprocessor.service.MessageConsumer;
import com.bat.veoassortmentprocessor.service.MessageDestinyForwarder;
import com.bat.veoassortmentprocessor.service.MessageQueueAppender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

@Service
public class RabbitMqMessageConsumer implements MessageConsumer {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMqMessageConsumer.class);
    private static final String EMPTY_DESTINY_ADDRESS = "";
    private static final String COMMUNICATION_TRIAL_NUMBER_KEY = "communication-trial-number";
    private static final int WAITING_PERIOD_IN_SEC = 2;

    private final String destinationKeyName;
    private final MessageDestinyForwarder messageDestinyForwarder;
    private final MessageQueueAppender queueAppender;
    private final ProcessorConfig config;

    public RabbitMqMessageConsumer(MessageDestinyForwarder messageDestinyForwarder, MessageQueueAppender queueAppender,
                                   ProcessorConfig config) {
        this.messageDestinyForwarder = messageDestinyForwarder;
        this.queueAppender = queueAppender;
        this.config = config;
        this.destinationKeyName = config.getMessageAddressKeyName();
    }

    @Override
    @RabbitListener(queues = "#{veoQueue}")
    public void processMessage(Message payload) {
        logger.debug("message payload received from queue: [{}]", payload);

        String messageDestination = getMessageDestination(payload).orElse(EMPTY_DESTINY_ADDRESS);
        if (EMPTY_DESTINY_ADDRESS.equalsIgnoreCase(messageDestination)) {
            logger.warn("Warning!!! Discarding message with empty destination parameter!!!");
            return;
        }

        String payloadToSend = new String(payload.getBody(), StandardCharsets.UTF_8);
        int messageSendingTrialNumber = extractTrialNumber(payload);
        CommunicationResult result = messageDestinyForwarder.forwardMessageToDestiny(payloadToSend, messageDestination, messageSendingTrialNumber);
        handleResult(result, payload.getBody(), messageDestination, messageSendingTrialNumber);
    }

    private void handleResult(CommunicationResult communicationResult, byte[] payload, String destination, int currentTrialNumber) {
        logger.debug("handleResult(), result code: [{}], destination: [{}], current trial number: [{}]",
                communicationResult.getResultCode(), destination, currentTrialNumber);

        switch (communicationResult.getResultCode()) {
            case OK:
                logger.debug("message successfully transmitted to destiny");
                break;
            case WRONG_PAYLOAD_FORMAT:
                logger.debug("payload was in wrong format - message will be discarded");
                break;
            case TIMEOUT_DURING_EXCHANGING_MESSAGE:
                rescheduleMessageWithLoggingCause(payload, destination, currentTrialNumber, "timeout during exchanging message with destiny");
                break;
            case TIMEOUT_WHEN_CONNECTING:
                rescheduleMessageWithLoggingCause(payload, destination, currentTrialNumber, "timeout when trying to connect to destiny");
                break;
            case NON_EXISTENT_DESTINY:
                logger.debug("destination not exists - message will be discarded");
                break;
            case FAULT_IN_RESPONSE_FROM_DESTINY:
                logger.debug("response from server has fault - message will be discarded");
                break;
            case DESTINY_MOVED:
                logger.debug("used address is stale, destiny has moved to other location - message will be discarded");
                break;
            case NON_EXISTENT_SERVICE:
                logger.debug("destiny doesn't offer called service - message will be discarded");
                break;
            case DESTINY_INTERNAL_ERROR:
                rescheduleMessageWithLoggingCause(payload, destination, currentTrialNumber, "message caused internal error on destiny");
                break;
            default:
                logger.debug("unsupported result - message will be discarded");
                break;
        }
    }

    private void rescheduleMessageWithLoggingCause(byte[] payload, String messageDestination, int currentTrialNumber, String rescheduleReason) {
        performWaiting(WAITING_PERIOD_IN_SEC);
        logger.debug("rescheduling message due to [{}]", rescheduleReason);
        rescheduleMessage(payload, messageDestination, currentTrialNumber);
    }

    private void rescheduleMessage(byte[] payload, String messageDestination, int currentTrialNumber) {
        Map<String, String> headerParams = new HashMap<>();
        headerParams.put(destinationKeyName, messageDestination);
        headerParams.put(COMMUNICATION_TRIAL_NUMBER_KEY, String.valueOf(++currentTrialNumber));
        queueAppender.appendMessageToQueue(payload, headerParams);
    }

    // TODO:MP move to separate class later
    private Optional<String> getMessageDestination(Message message) {
        String destinyHolder = (String) message.getMessageProperties().getHeaders().get(destinationKeyName);
        return Optional.ofNullable(destinyHolder);
    }

    private int extractTrialNumber(Message message) {
        String stringMessageTrial = (String) message.getMessageProperties().getHeaders().getOrDefault(COMMUNICATION_TRIAL_NUMBER_KEY, "1");
        logger.debug("message transmission trial extracted from payload [{}]", stringMessageTrial);
        return Integer.parseInt(stringMessageTrial);
    }

    private void performWaiting(int numberOfSeconds) {
        logger.debug("trying to sleep for [{}] seconds", numberOfSeconds);
        LocalDateTime waitingStartTime = LocalDateTime.now();
        try {
            Thread.sleep(secToMillisec(numberOfSeconds));
        } catch (InterruptedException e) {
            logger.warn("thread was supposed to sleep...");
        }
        logger.debug("thread was sleeping for [{}] ms", Duration.between(waitingStartTime, LocalDateTime.now()).toMillis());
    }

    private int secToMillisec(int numberOfSeconds) {
        return numberOfSeconds * 1_000;
    }
}
