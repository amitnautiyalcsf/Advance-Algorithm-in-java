package com.bat.veoassortmentprocessor.model;

public class CommunicationResult {

    private ResultCode resultCode;
    private String detailMessage;

    public CommunicationResult(ResultCode resultCode, String detailMessage) {
        this.resultCode = resultCode;
        this.detailMessage = detailMessage;
    }

    @Override
    public String toString() {
        return "CommunicationResult{" +
                "resultCode=" + resultCode +
                ", detailMessage='" + detailMessage + '\'' +
                '}';
    }

    public ResultCode getResultCode() {
        return resultCode;
    }

    public String getDetailMessage() {
        return detailMessage;
    }

    public enum ResultCode {
        OK,
        TIMEOUT_WHEN_CONNECTING,
        TIMEOUT_DURING_EXCHANGING_MESSAGE,
        FAULT_IN_RESPONSE_FROM_DESTINY,
        NON_EXISTENT_DESTINY,
        WRONG_PAYLOAD_FORMAT,
        DESTINY_MOVED,
        NON_EXISTENT_SERVICE,
        DESTINY_INTERNAL_ERROR,
        UNKNOWN_RESULT
    }
}
