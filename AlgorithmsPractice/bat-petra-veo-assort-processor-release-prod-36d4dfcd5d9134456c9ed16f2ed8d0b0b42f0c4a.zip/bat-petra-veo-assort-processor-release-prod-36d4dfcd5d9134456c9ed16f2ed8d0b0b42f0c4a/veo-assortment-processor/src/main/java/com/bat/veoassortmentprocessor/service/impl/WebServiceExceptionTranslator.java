package com.bat.veoassortmentprocessor.service.impl;

import com.bat.veoassortmentprocessor.model.CommunicationResult;
import com.bat.veoassortmentprocessor.service.CommunicationExceptionsTranslator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.ws.client.WebServiceIOException;
import org.springframework.ws.client.WebServiceTransformerException;
import org.springframework.ws.client.WebServiceTransportException;
import org.springframework.ws.soap.client.SoapFaultClientException;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;
import java.util.Optional;

import static com.bat.veoassortmentprocessor.model.CommunicationResult.ResultCode.DESTINY_INTERNAL_ERROR;
import static com.bat.veoassortmentprocessor.model.CommunicationResult.ResultCode.DESTINY_MOVED;
import static com.bat.veoassortmentprocessor.model.CommunicationResult.ResultCode.FAULT_IN_RESPONSE_FROM_DESTINY;
import static com.bat.veoassortmentprocessor.model.CommunicationResult.ResultCode.NON_EXISTENT_DESTINY;
import static com.bat.veoassortmentprocessor.model.CommunicationResult.ResultCode.NON_EXISTENT_SERVICE;
import static com.bat.veoassortmentprocessor.model.CommunicationResult.ResultCode.TIMEOUT_DURING_EXCHANGING_MESSAGE;
import static com.bat.veoassortmentprocessor.model.CommunicationResult.ResultCode.TIMEOUT_WHEN_CONNECTING;
import static com.bat.veoassortmentprocessor.model.CommunicationResult.ResultCode.UNKNOWN_RESULT;
import static com.bat.veoassortmentprocessor.model.CommunicationResult.ResultCode.WRONG_PAYLOAD_FORMAT;

@Service
public class WebServiceExceptionTranslator implements CommunicationExceptionsTranslator {

    private static final Logger logger = LoggerFactory.getLogger(WebServiceExceptionTranslator.class);

    @Override
    public CommunicationResult translateException(Exception exc) {
        CommunicationResult result;
        if (exc instanceof WebServiceTransformerException) {
            result = new CommunicationResult(WRONG_PAYLOAD_FORMAT, exc.getMessage());
        } else if (exc instanceof WebServiceTransportException) {
            result = translateTransportException((WebServiceTransportException) exc);
        } else if (exc instanceof WebServiceIOException) {
            result = translateIOException((WebServiceIOException) exc);
        } else if (exc instanceof SoapFaultClientException) {
            result = new CommunicationResult(FAULT_IN_RESPONSE_FROM_DESTINY, exc.getMessage());
        } else {
            result = new CommunicationResult(UNKNOWN_RESULT, exc.getMessage());
        }

        logger.debug("translateException() - from [{}] to [{}]", exc.getClass(), result);
        return result;
    }

    // this method translates WebServiceTransportException caused by HTTP responses of classes 3xx, 4xx and 5xx
    // to domain equivalents for each HTTP codes status class
    private CommunicationResult translateTransportException(WebServiceTransportException exc) {
        String exceptionMessage = Optional.ofNullable(exc.getMessage())
                .orElse("");
        CommunicationResult result;

        if (exceptionMessage.contains(" [3")) {
            result = new CommunicationResult(DESTINY_MOVED, exceptionMessage);
        } else if (exceptionMessage.contains(" [4")) {
            result = new CommunicationResult(NON_EXISTENT_SERVICE, exceptionMessage);
        } else if (exceptionMessage.contains(" [5")) {
            result = new CommunicationResult(DESTINY_INTERNAL_ERROR, exceptionMessage);
        } else {
            result = new CommunicationResult(UNKNOWN_RESULT, exceptionMessage);
        }

        return result;
    }

    private CommunicationResult translateIOException(WebServiceIOException exc) {
        String exceptionMessage = Optional.ofNullable(exc.getMessage())
                .orElse("");
        CommunicationResult result;

        if (exc.getCause() instanceof UnknownHostException) {
            result = new CommunicationResult(NON_EXISTENT_DESTINY, exceptionMessage);
        } else if (exc.getCause() instanceof ConnectException) {
            result = new CommunicationResult(TIMEOUT_WHEN_CONNECTING, exceptionMessage);
        } else if (exc.getCause() instanceof SocketTimeoutException) {
            result = new CommunicationResult(TIMEOUT_DURING_EXCHANGING_MESSAGE, exceptionMessage);
        } else {
            result = new CommunicationResult(UNKNOWN_RESULT, exceptionMessage);
        }

        return result;
    }
}
