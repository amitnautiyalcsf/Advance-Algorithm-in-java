package com.bat.veoassortmentprocessor.service;

import java.util.Map;

public interface MessageQueueAppender {

    void appendMessageToQueue(byte[] message, Map<String, String> headerAttributes);
}
