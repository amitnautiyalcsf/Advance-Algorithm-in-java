package com.bat.veoassortmentprocessor.service.impl;

import com.bat.veoassortmentprocessor.service.MessageQueueAppender;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

import java.util.Map;

@Service
public class RabbitMqMessageAppender implements MessageQueueAppender {

    private static final Logger logger = LoggerFactory.getLogger(RabbitMqMessageAppender.class);

    private RabbitTemplate template;
    private Queue queue;

    public RabbitMqMessageAppender(RabbitTemplate template, Queue queue) {
        this.template = template;
        this.queue = queue;
    }

    @Override
    public void appendMessageToQueue(byte[] message, Map<String, String> headerAttributes) {
        logger.debug("appending message with header attributes [{}] to queue", headerAttributes);

        template.convertAndSend(queue.getName(), message, msq -> {
            msq.getMessageProperties().getHeaders().putAll(headerAttributes);
            return msq;
        });
    }
}
