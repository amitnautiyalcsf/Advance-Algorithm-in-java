package com.bat.veoassortmentprocessor.soap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.ws.client.WebServiceClientException;
import org.springframework.ws.client.support.interceptor.ClientInterceptorAdapter;
import org.springframework.ws.context.MessageContext;

@Component
public class LoggingClientInterceptor extends ClientInterceptorAdapter {

    private static final Logger logger = LoggerFactory.getLogger(LoggingClientInterceptor.class);

    @Override
    public boolean handleRequest(MessageContext messageContext) throws WebServiceClientException {
        logger.debug("" + messageContext.getRequest());
        return true;
    }

    @Override
    public boolean handleResponse(MessageContext messageContext) throws WebServiceClientException {
        logger.debug("" + messageContext.getResponse());
        return false;
    }

    @Override
    public boolean handleFault(MessageContext messageContext) throws WebServiceClientException {
        logger.debug("" + messageContext.getResponse());
        return true;
    }
}
