package com.bat.veoassortmentprocessor.soap;

public class VeoRequest {

    private String header;
    private String payload;

    public String getHeader() {
        return header;
    }

    public void setHeader(String header) {
        this.header = header;
    }

    public String getPayload() {
        return payload;
    }

    public void setPayload(String payload) {
        this.payload = payload;
    }
}
