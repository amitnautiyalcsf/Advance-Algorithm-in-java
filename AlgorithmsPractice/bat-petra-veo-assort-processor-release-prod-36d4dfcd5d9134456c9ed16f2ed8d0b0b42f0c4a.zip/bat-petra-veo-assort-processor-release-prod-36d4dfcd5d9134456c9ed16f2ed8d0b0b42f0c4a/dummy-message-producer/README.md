### Dummy message producer

#### How to build?
From project folder issue the command
./mvnw clean package

#### How to run application?
Just issue the command:
java -jar dummy-message-producer-0.0.1-SNAPSHOT.jar --parameter1="value1" --parameter2="value2"

#### Supported parameters
rabbitmq.host - default value: localhost
rabbitmq.port - default value: 5672
rabbitmq.routing-key - default value: veo-queue
rabbitmq.username - default valued: guest
rabbitmq.password - default value: guest
msg.dest.address - default value: localhost: 9000
msg.address-key-name - default value: targetEndpoint 
