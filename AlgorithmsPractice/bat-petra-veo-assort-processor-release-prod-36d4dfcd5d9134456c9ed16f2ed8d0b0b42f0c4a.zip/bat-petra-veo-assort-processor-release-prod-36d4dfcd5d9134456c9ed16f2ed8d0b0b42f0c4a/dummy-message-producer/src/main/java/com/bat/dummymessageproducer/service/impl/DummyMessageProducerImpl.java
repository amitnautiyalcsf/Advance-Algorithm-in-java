package com.bat.dummymessageproducer.service.impl;

import com.bat.dummymessageproducer.configuration.ProducerConfiguration;
import com.bat.dummymessageproducer.service.DummyMessageProducer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;

@Service
public class DummyMessageProducerImpl implements DummyMessageProducer {

    private static final Logger logger = LoggerFactory.getLogger(DummyMessageProducerImpl.class);

    private RabbitTemplate template;
    private Queue queue;
    private String keyForStoringMessageAddress;
    private String messageDeliveryAddress;

    @Autowired
    public DummyMessageProducerImpl(RabbitTemplate template, Queue queue, ProducerConfiguration producerConfiguration) {
        this.template = template;
        this.queue = queue;
        keyForStoringMessageAddress = producerConfiguration.getMessageAddressKeyName();
        messageDeliveryAddress = producerConfiguration.getMessageDestinationAddress();
    }

    @Override
    public Queue getCurrentQueue() {
        return queue;
    }

    @Scheduled(fixedDelay = 1000, initialDelay = 500)
    @Override
    public void sendMessageToQueue() {
        logger.debug("sending message...");

        final String dummyMessage = LocalDateTime.now().toString();

        template.convertAndSend(queue.getName(), dummyMessage.getBytes(StandardCharsets.UTF_8), message -> {
            message.getMessageProperties().getHeaders().put(keyForStoringMessageAddress, messageDeliveryAddress);
            return message;
        });
        logger.debug("new message [{}] sent", dummyMessage);
    }
}
