package com.bat.dummymessageproducer.service;

import org.springframework.amqp.core.Queue;

public interface DummyMessageProducer {

    Queue getCurrentQueue();
    void sendMessageToQueue();
}
