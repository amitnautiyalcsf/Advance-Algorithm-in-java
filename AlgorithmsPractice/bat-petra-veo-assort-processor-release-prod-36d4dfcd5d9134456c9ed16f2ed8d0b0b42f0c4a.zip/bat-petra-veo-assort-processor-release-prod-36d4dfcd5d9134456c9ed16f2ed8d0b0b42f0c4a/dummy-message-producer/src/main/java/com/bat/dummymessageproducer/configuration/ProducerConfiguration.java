package com.bat.dummymessageproducer.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;

@Configuration
@EnableScheduling
public class ProducerConfiguration {

    private static final Logger logger = LoggerFactory.getLogger(ProducerConfiguration.class);

    private String rabbitHost;
    private int rabbitPort;
    private String rabbitRoutingKey;
    private String rabbitUsername;
    private String rabbitPassword;
    private String messageDestinationAddress;
    private String messageAddressKeyName;

    public String getMessageAddressKeyName() {
        return messageAddressKeyName;
    }

    @Autowired
    void setMessageAddressKeyName(@Value("${message.header.address-key-name}") String messageAddressKeyName) {
        logger.debug("msg.address-key-name from config: [{}]", messageAddressKeyName);
        this.messageAddressKeyName = messageAddressKeyName;
    }

    public String getMessageDestinationAddress() {
        return messageDestinationAddress;
    }

    @Autowired
    void setMessageDestinationAddress(@Value("${message.destination.address}") String messageDestinationAddress) {
        logger.debug("msg.dest.address from config: [{}]", messageDestinationAddress);
        this.messageDestinationAddress = messageDestinationAddress;
    }

    public String getRabbitUsername() {
        return rabbitUsername;
    }

    @Autowired
    void setRabbitUsername(@Value("${spring.rabbitmq.username}") String rabbitUsername) {
        logger.debug("rabbitmq.username from config: [{}]", rabbitUsername);
        this.rabbitUsername = rabbitUsername;
    }

    public String getRabbitPassword() {
        return rabbitPassword;
    }

    @Autowired
    void setRabbitPassword(@Value("${spring.rabbitmq.password}") String rabbitPassword) {
        logger.debug("rabbitmq.password from config: [{}]", rabbitPassword);
        this.rabbitPassword = rabbitPassword;
    }

    public String getRabbitRoutingKey() {
        return rabbitRoutingKey;
    }

    @Autowired
    void setRabbitRoutingKey(@Value("${spring.rabbitmq.template.routing-key}") String rabbitRoutingKey) {
        logger.debug("rabbitmq.routing-key from config: [{}]", rabbitRoutingKey);
        this.rabbitRoutingKey = rabbitRoutingKey;
    }

    public int getRabbitPort() {
        return rabbitPort;
    }

    @Autowired
    void setRabbitPort(@Value("${spring.rabbitmq.port}") int rabbitPort) {
        logger.debug("rabbitmq.port from config: [{}]", rabbitPort);
        this.rabbitPort = rabbitPort;
    }

    public String getRabbitHost() {
        return rabbitHost;
    }

    @Autowired
    void setRabbitHost(@Value("${spring.rabbitmq.host}") String rabbitHost) {
        logger.debug("rabbitmq.host from config: [{}]", rabbitHost);
        this.rabbitHost = rabbitHost;
    }

    @Bean
    Queue veoQueue(@Value("#{producerConfiguration.rabbitRoutingKey}") String queueName) {
        return new Queue(queueName);
    }

}
