package com.bat.petra.targeting.cis.survey.repository;

import com.bat.petra.targeting.cis.survey.model.SurveyMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SurveyMappingRepository extends JpaRepository<SurveyMapping, Integer> {

}
