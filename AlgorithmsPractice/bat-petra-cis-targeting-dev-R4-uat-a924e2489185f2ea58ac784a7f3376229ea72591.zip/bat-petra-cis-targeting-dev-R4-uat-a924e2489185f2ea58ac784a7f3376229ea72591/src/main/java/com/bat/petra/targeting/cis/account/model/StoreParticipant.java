package com.bat.petra.targeting.cis.account.model;

import com.bat.petra.targeting.cis.entity.PersistableEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "ivybase__Store_Participant__c", schema = "salesforce")
@Data
@EqualsAndHashCode
public class StoreParticipant extends PersistableEntity implements Serializable {

    @ToString.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ivybase__Account__c", referencedColumnName = "sfid")
    private Account account;

    @Column(name = "ivybase__Role__c")
    private String role;
}
