package com.bat.petra.targeting.cis.digital.service;

import com.bat.petra.targeting.cis.account.model.Account;
import com.bat.petra.targeting.cis.account.repository.AccountRepository;
import com.bat.petra.targeting.cis.constants.Constants;
import com.bat.petra.targeting.cis.digital.model.DigitalContentMapping;
import com.bat.petra.targeting.cis.digital.repository.DigitalContentMappingRepository;
import com.bat.petra.targeting.cis.enums.TargetingProcessAccountStatus;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcessAccount;
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessAccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
public class DigitalService {

    private static final Logger LOGGER = LoggerFactory.getLogger(DigitalService.class);

    private static final String IS_ACTIVE = "Yes";

    @Autowired
    TargetingProcessAccountRepository targetingProcessAccountRepository;

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    DigitalContentMappingRepository digitalContentMappingRepository;

    @Transactional(Transactional.TxType.REQUIRED)
    public void saveDigitals(TargetingProcess targetingProcess, List<TargetingProcessAccount> targetingProcessAccounts) {
        LOGGER.info(targetingProcess.getName() + " - Found TP accounts to target: " + targetingProcessAccounts.size());

        List<Account> bulkMappingToSave = new LinkedList<>();
        List<TargetingProcessAccount> bulkAccountToSave = new LinkedList<>();

        AtomicInteger alreadyTargeted = new AtomicInteger();

        targetingProcessAccounts.forEach(a -> {

            Account account = accountRepository.findBySfId(a.getAccountId());

            if (isNotTargetedDigitalInRelation(account, targetingProcess.getDigitalContentId())) {

                DigitalContentMapping digitalContentMapping = createDigitalMappping(
                        targetingProcess.getDigitalContentId(),
                        account);

                account.getDigitalContentMappings().add(digitalContentMapping);
                bulkMappingToSave.add(account);

                a.setStatus(TargetingProcessAccountStatus.GENERATED_DIGITAL.getDesc());
                bulkAccountToSave.add(a);
            } else {
                alreadyTargeted.getAndIncrement();
            }

            if (alreadyTargeted.get() > 0) {
                LOGGER.info(targetingProcess.getName() + " - " +
                        "Accounts already targeted by: " + targetingProcess.getDigitalContentId() + ": " + alreadyTargeted);
            }

            if (bulkMappingToSave.size() > Constants.BULK_SIZE) {
                saveListAndClear(bulkMappingToSave, bulkAccountToSave, targetingProcess);
            }
        });

        if (!CollectionUtils.isEmpty(bulkMappingToSave)) {
            saveListAndClear(bulkMappingToSave, bulkAccountToSave, targetingProcess);
        }
    }

    private Boolean isNotTargetedDigitalInRelation(Account account, String digitalId) {

        List<DigitalContentMapping> list = new ArrayList<>();
        if (!CollectionUtils.isEmpty(account.getDigitalContentMappings())) {
            list = account.getDigitalContentMappings().stream()
                    .filter(m -> digitalId.equals(m.getDigitalContent()))
                    .collect(Collectors.toList());
        }

        return CollectionUtils.isEmpty(list);
    }

    private DigitalContentMapping createDigitalMappping(String digitalId, Account account) {

        DigitalContentMapping digitalContentMapping = new DigitalContentMapping();
        digitalContentMapping.setName(UUID.randomUUID().toString());
        digitalContentMapping.setDigitalContent(digitalId);
        digitalContentMapping.setExternalId(UUID.randomUUID().toString());
        digitalContentMapping.setAccount(account);
        digitalContentMapping.setActive(IS_ACTIVE);
        return digitalContentMapping;
    }

    private void saveListAndClear(List<Account> bulkMappingToSave,
                                  List<TargetingProcessAccount> bulkAccountToSave, TargetingProcess targetingProcess) {
        accountRepository.saveAll(bulkMappingToSave);
        LOGGER.info(targetingProcess.getName() + " - DigitalContentMapping saved to DB: " + bulkMappingToSave.size());

        targetingProcessAccountRepository.saveAll(bulkAccountToSave);
        LOGGER.info(targetingProcess.getName() + " - TargetingProcessAccount with status updated saved to DB: " + bulkAccountToSave.size());

        bulkAccountToSave.clear();
        bulkMappingToSave.clear();
    }

}
