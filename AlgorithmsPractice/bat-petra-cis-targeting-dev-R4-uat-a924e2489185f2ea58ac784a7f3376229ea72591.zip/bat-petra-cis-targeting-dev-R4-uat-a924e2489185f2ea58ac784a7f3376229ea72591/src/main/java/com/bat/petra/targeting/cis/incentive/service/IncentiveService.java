package com.bat.petra.targeting.cis.incentive.service;

import com.bat.petra.targeting.cis.account.model.Account;
import com.bat.petra.targeting.cis.account.repository.AccountRepository;
import com.bat.petra.targeting.cis.incentive.json.IncentiveJson;
import com.bat.petra.targeting.cis.incentive.model.IncentiveMapping;
import com.bat.petra.targeting.cis.incentive.repository.IncentiveMappingRepository;
import com.bat.petra.targeting.cis.survey.model.SurveyMapping;
import com.bat.petra.targeting.cis.survey.repository.SurveyMappingRepository;
import com.bat.petra.targeting.cis.survey.service.SurveyService;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcessAccount;
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessAccountRepository;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

import static com.bat.petra.targeting.cis.constants.Constants.*;

@Service
public class IncentiveService {

    private static final Logger LOGGER = LoggerFactory.getLogger(IncentiveService.class);

    @Autowired
    private IncentiveValidationService incentiveValidationService;

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private SurveyService surveyService;

    @Autowired
    private IncentiveMappingRepository incentiveMappingRepository;

    @Autowired
    private TargetingProcessAccountRepository targetingProcessAccountRepository;

    @Autowired
    private SurveyMappingRepository surveyMappingRepository;

    private ExecutorService executorService = Executors.newCachedThreadPool();

    //    @Transactional
    public void saveAllIncentive(TargetingProcess targetingProcess, List<TargetingProcessAccount> targetingProcessAccounts) {

        IncentiveJson incentiveJson = new Gson().fromJson( targetingProcess.getTargetingKPIs(),
                new TypeToken<IncentiveJson>(){}.getType());

        LOGGER.info(incentiveJson.toString());

        int size = targetingProcessAccounts.size();

        LOGGER.info(targetingProcess.getName() + " - Found TP accounts to target: " + size);

        setupExecutor(size, targetingProcess, targetingProcessAccounts, incentiveJson);
    }

    void saveListAndClear(List<IncentiveMapping> bulkMappingToSave,
                                  List<TargetingProcessAccount> bulkAccountToSave,
                                  IncentiveJson incentiveJson, TargetingProcess targetingProcess) {
        List<IncentiveMapping> incentiveMappingList = incentiveMappingRepository.saveAll(bulkMappingToSave);
        LOGGER.info(targetingProcess.getName() + " - IncentiveMapping saved to DB: " + incentiveMappingList.size());

        List<SurveyMapping> bulkSurveyToSave = new LinkedList<>();

        incentiveMappingList.parallelStream().forEach(i -> {
            if (incentiveJson.getSurveyQuestionaire() != null
                    && surveyService.isNotTargetedSurveyInRelation(i.getAccount(), incentiveJson.getSurveyQuestionaire())) {

                SurveyMapping surveyMapping = surveyService.setupSurveyFromIncentive(i.getAccount(),
                        incentiveJson.getSurveyQuestionaire(), i);
                bulkSurveyToSave.add(surveyMapping);
            }
        });

        if (!bulkSurveyToSave.isEmpty()) {
            surveyMappingRepository.saveAll(bulkSurveyToSave);
            LOGGER.info(targetingProcess.getName() + " - SurveyMapping saved to DB: " + bulkSurveyToSave.size());
        }
        targetingProcessAccountRepository.saveAll(bulkAccountToSave);
        LOGGER.debug(targetingProcess.getName() + " - TargetingProcessAccount with status updated saved to DB: " + bulkAccountToSave.size());
        bulkAccountToSave.clear();
        bulkMappingToSave.clear();
        bulkSurveyToSave.clear();
    }

    Boolean isNotTargetedIncentiveInRelation(Account account, String incentiveId) {

        List<IncentiveMapping> list = new ArrayList<>();
        if (!CollectionUtils.isEmpty(account.getIncentiveMappings())) {
            list = account.getIncentiveMappings().stream()
                    .filter(m -> incentiveId.equals(m.getIncentive()))
                    .collect(Collectors.toList());
        }

        return CollectionUtils.isEmpty(list);
    }

    IncentiveMapping createIncentiveMapping(IncentiveJson incentiveJson, TargetingProcess targetingProcess) {

        IncentiveMapping incentiveMapping = new IncentiveMapping();
        setupMainFields(incentiveMapping, incentiveJson, targetingProcess);

        return incentiveMapping;
    }

    IncentiveMapping setupAccountFields(IncentiveMapping incentiveMapping, Account account, IncentiveJson incentiveJson) {
        setIfAccountIsVendor(incentiveMapping, account, incentiveJson);
        incentiveMapping.setAccount(account);
        incentiveMapping.setExternalId(UUID.randomUUID().toString());
        incentiveMapping.setId(null);
        return incentiveMapping;
    }

    private void setupMainFields(IncentiveMapping mapping, IncentiveJson incentiveJson,
                                 TargetingProcess targetingProcess) {

        coreFields(mapping, incentiveJson, targetingProcess.getIncentiveId());
        schemaRewardType(mapping, incentiveJson);
    }

    private void coreFields(IncentiveMapping mapping, IncentiveJson incentiveJson, String incentiveId) {

        mapping.setIncentive(incentiveId);
        mapping.setIncentiveTargetSchema(incentiveJson.getIncentiveSchemeId());
        mapping.setTargetKPI(incentiveJson.getTargetKPI());
        mapping.setRemainingTarget(incentiveJson.getRemainingTarget());
        mapping.setIncentiveEndDate(incentiveJson.getIncentiveEndDate());
        mapping.setEnrolmentDate(new Date());
    }

    private void schemaRewardType(IncentiveMapping mapping, IncentiveJson incentiveJson) {

        if (VALUE_DISCOUNT.equalsIgnoreCase(incentiveJson.getIncentiveSchemeRewardType())) {
            mapping.setTargetReward(incentiveJson.getTargetDiscountValue());
            mapping.setMaxBudget(incentiveJson.getMaxDiscount());
            setCustomerIncentive(mapping, incentiveJson);
        } else if (PERCENT_DISCOUNT.equalsIgnoreCase(incentiveJson.getIncentiveSchemeRewardType())) {
            mapping.setTargetDiscount(incentiveJson.getTargetDiscountPercent());
            mapping.setMaxBudget(incentiveJson.getMaxDiscount());
            setCustomerIncentive(mapping, incentiveJson);

        } else if (TRADE_PAYMENT.equalsIgnoreCase(incentiveJson.getIncentiveSchemeRewardType())) {
            mapping.setTargetReward(incentiveJson.getTargetDiscountTradePayment());
            mapping.setMaxBudget(incentiveJson.getMaxTradePayment());
        } else {
            mapping.setTargetLoyalty(incentiveJson.getTargetDiscountLoyaltyPoints());
            mapping.setMaxLoyaltyPoints(incentiveJson.getMaxDiscountLoyaltyPoints());
            setCustomerIncentive(mapping, incentiveJson);
        }
    }


    private void setIfAccountIsVendor(IncentiveMapping incentiveMapping, Account account, IncentiveJson incentiveJson) {

        if (TRADE_PAYMENT.equalsIgnoreCase(incentiveJson.getIncentiveSchemeRewardType())
                && incentiveJson.getIncentiveAutoEnroll()
                && APPROVED.equalsIgnoreCase(incentiveJson.getIncentiveSchemeStatus())
                && incentiveValidationService.isVendor(account)
        ) {
            incentiveMapping.setStatusSchemaForCustomerIncentive(ENROLLED);
            incentiveMapping.setStatusSchemaForReward(AWAITING_PO);
        } else {
            incentiveMapping.setStatusSchemaForCustomerIncentive(ELIGIBLE);
        }
    }

    private void setCustomerIncentive(IncentiveMapping mapping, IncentiveJson incentiveJson) {

        if (incentiveValidationService.isCustomerIncentiveEnrolled(incentiveJson)) {
            mapping.setStatusSchemaForCustomerIncentive(ENROLLED);
        } else if (incentiveValidationService.isCustomerIncentiveEligible(incentiveJson)) {
            mapping.setStatusSchemaForCustomerIncentive(ELIGIBLE);
        }
    }

    private void setupExecutor(int size, TargetingProcess targetingProcess, List<TargetingProcessAccount> targetingProcessAccounts,
                               IncentiveJson incentiveJson) {

        CountDownLatch latch;

        if (size < BULK_SIZE * 2) {

            latch = new CountDownLatch(1);

            executorService.execute(
                    new SubListProcess(
                            targetingProcessAccounts,
                            accountRepository,
                            this,
                            targetingProcess,
                            latch,
                            incentiveJson
                    )
            );
        } else {

            latch = new CountDownLatch(4);

            int[] sublistStartEnd = {0, size / 4, size / 2, (size - size / 4), size};

            for (int i = 0; i < 4; i++) {
                executorService.execute(
                        new SubListProcess(
                                targetingProcessAccounts.subList(sublistStartEnd[i], sublistStartEnd[i + 1]),
                                accountRepository,
                                this,
                                targetingProcess,
                                latch,
                                incentiveJson

                        )
                );
            }

        }

        try {
            latch.await(4, TimeUnit.HOURS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

}
