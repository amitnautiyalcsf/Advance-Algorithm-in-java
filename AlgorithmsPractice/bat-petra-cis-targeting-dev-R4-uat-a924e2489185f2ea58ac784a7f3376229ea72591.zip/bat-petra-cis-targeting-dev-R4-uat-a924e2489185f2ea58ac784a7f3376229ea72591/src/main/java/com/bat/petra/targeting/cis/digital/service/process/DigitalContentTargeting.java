package com.bat.petra.targeting.cis.digital.service.process;

import com.bat.petra.targeting.cis.digital.service.DigitalService;
import com.bat.petra.targeting.cis.enums.TargetingProcessStatus;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess;
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessRepository;
import com.bat.petra.targeting.cis.targetingProcess.service.TargetingProcessService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@AllArgsConstructor
public class DigitalContentTargeting implements Runnable {
    private static final Logger LOGGER = LoggerFactory.getLogger(DigitalContentTargeting.class);

    private TargetingProcess targetingProcess;
    private TargetingProcessRepository targetingProcessRepository;
    private DigitalService digitalService;
    private TargetingProcessService targetingProcessService;
    private long sleepTime;

    @Override
    public void run() {

        digitalService.saveDigitals(targetingProcess, targetingProcess.getAccounts());

        targetingProcessService.targetMissedAccounts(sleepTime, targetingProcess);

        targetingProcess.setStatus(TargetingProcessStatus.FINISHED.getDesc());
        LOGGER.info(targetingProcess.getName() + " set status to: " + TargetingProcessStatus.FINISHED.getDesc());

        targetingProcessRepository.save(targetingProcess);
    }

}
