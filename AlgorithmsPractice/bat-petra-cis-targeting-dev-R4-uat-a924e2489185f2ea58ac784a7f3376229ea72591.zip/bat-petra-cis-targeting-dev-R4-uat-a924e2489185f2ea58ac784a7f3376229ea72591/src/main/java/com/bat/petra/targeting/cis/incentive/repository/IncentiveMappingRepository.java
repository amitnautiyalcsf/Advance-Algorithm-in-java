package com.bat.petra.targeting.cis.incentive.repository;

import com.bat.petra.targeting.cis.incentive.model.IncentiveMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IncentiveMappingRepository extends JpaRepository<IncentiveMapping, Integer> {
}
