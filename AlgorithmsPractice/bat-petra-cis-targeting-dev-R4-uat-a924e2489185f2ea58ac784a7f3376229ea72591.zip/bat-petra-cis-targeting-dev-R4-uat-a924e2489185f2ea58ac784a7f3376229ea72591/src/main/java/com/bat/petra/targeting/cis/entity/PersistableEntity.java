package com.bat.petra.targeting.cis.entity;

import org.springframework.data.domain.Persistable;

import javax.persistence.*;

/**
 * The type Persistable entity.
 *
 * @author arkadiusz.wronski, created on 2019-01-11.
 */
@MappedSuperclass
public abstract class PersistableEntity implements Persistable<Integer> {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "ID")
  private Integer id;

  public Integer getId() {
    return id;
  }

  public void setId(Integer id) {
    this.id = id;
  }

  @Override
  @Transient
  public boolean isNew() {
    return getId() == null;
  }
}
