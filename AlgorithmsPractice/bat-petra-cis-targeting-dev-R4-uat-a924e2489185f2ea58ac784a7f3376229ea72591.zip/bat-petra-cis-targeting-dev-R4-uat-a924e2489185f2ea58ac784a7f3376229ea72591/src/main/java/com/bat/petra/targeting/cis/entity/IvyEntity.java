package com.bat.petra.targeting.cis.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;

/**
 * @author arkadiusz.wronski, created on 2019-02-13.
 */
@MappedSuperclass
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public abstract class IvyEntity extends PersistableEntity implements Serializable {

  @Column
  private String name;

  @Column(name = "sfid",length = 18)
  private String sfId;
}
