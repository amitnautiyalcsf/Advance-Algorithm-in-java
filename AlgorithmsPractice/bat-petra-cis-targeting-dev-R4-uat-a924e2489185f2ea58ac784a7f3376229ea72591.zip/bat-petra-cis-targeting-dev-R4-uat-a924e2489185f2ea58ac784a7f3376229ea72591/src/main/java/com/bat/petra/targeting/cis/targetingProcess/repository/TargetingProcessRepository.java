package com.bat.petra.targeting.cis.targetingProcess.repository;

import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TargetingProcessRepository extends JpaRepository<TargetingProcess, Integer> {

    List<TargetingProcess> findAllByTypeAndStatus(String type, String status);

    TargetingProcess findFirstByStatusAndType(String status, String type);

    TargetingProcess findByName(String name);
}
