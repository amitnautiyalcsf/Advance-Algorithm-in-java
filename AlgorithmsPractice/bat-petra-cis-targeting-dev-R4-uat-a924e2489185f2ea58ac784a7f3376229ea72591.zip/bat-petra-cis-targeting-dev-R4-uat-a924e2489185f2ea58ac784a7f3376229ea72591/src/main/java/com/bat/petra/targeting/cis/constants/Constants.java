package com.bat.petra.targeting.cis.constants;

public class Constants {

    //JSON KPI NAMES
    public static final String VALUE_DISCOUNT = "Value Discount on Invoice";
    public static final String PERCENT_DISCOUNT = "% Discount on Invoice";
    public static final String TRADE_PAYMENT = "Trade Payment";
    public static final String APPROVED = "Approved";
    public static final String ENROLLED = "Enrolled";
    public static final String ELIGIBLE = "Eligible";
    public static final String SUPPLIER = "Supplier";
    public static final String AWAITING_PO = "Awaiting PO";

    //TARGETING COMPLETION STATUS
    public static final String CONTRACT_GENERATED_STATUS = "Contract Generated";
    public static final String CONTRACT_NEW_STATUS = "New";

    //BULK SIZE - saveAll list size
    public static final Integer BULK_SIZE = 2500;

    private Constants() {}
}
