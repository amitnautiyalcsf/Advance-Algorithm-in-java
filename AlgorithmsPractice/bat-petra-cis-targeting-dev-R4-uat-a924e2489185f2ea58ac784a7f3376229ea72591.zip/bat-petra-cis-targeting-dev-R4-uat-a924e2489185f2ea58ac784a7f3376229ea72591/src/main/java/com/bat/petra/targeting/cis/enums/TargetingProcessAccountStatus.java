package com.bat.petra.targeting.cis.enums;

import static com.bat.petra.targeting.cis.constants.Constants.*;

public enum TargetingProcessAccountStatus {

    NEW(CONTRACT_NEW_STATUS),
    GENERATED_SURVEY(CONTRACT_GENERATED_STATUS),
    GENERATED_DIGITAL(CONTRACT_GENERATED_STATUS),
    GENERATED_INCENTIVE(CONTRACT_GENERATED_STATUS);

    private final String desc;

    TargetingProcessAccountStatus(String desc) {     // Constructor
        this.desc = desc;
    }

    public String getDesc() {              // Getter
        return desc;
    }

    @Override
    public String toString() {
        return this.getDesc();
    }
}
