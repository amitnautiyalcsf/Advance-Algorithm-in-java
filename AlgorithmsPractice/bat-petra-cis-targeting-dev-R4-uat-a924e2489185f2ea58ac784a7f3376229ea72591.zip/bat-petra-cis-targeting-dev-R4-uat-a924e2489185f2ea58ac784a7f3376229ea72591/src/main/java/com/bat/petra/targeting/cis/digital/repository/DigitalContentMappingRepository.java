package com.bat.petra.targeting.cis.digital.repository;

import com.bat.petra.targeting.cis.digital.model.DigitalContentMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DigitalContentMappingRepository extends JpaRepository<DigitalContentMapping, Integer> {
}
