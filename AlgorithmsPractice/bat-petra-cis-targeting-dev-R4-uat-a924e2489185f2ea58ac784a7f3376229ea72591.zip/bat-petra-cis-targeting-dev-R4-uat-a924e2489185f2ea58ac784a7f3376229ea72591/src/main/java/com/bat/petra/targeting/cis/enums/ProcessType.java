package com.bat.petra.targeting.cis.enums;

public enum ProcessType {

    CONTRACT("CM"),
    SURVEY("Survey"),
    DIGITAL("Digital Content"),
    INCENTIVE("CIS");

    private final String desc;

    ProcessType(String desc) {     // Constructor
        this.desc = desc;
    }

    public String getDesc() {              // Getter
        return desc;
    }

    @Override
    public String toString() {
        return this.getDesc();
    }
}

