package com.bat.petra.targeting.cis.incentive.model;

import com.bat.petra.targeting.cis.account.model.Account;
import com.bat.petra.targeting.cis.entity.IvyEntity;
import com.bat.petra.targeting.cis.survey.model.SurveyMapping;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

@Entity
@Table(name = "ivybat__Incentive_Mapping__c", schema = "salesforce")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@NoArgsConstructor
public class IncentiveMapping extends IvyEntity implements Serializable {

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ivybat__Account__c", referencedColumnName = "sfid")
    private Account account;

    @Column(name = "ivybat__Incentive__c")
    private String incentive;

    @Column(name = "ivybat__Migration_External_Id__c")
    private String externalId;

    @Column(name = "ivybat__Max_Budget__c")
    private Double maxBudget;

    @Column(name = "Remaining_Target__c")
    private Double remainingTarget;

    @Column(name = "Target_Discount__c")
    private Double targetDiscount;

    @Column(name = "ivybat__Enrolment_Date__c")
    private Date enrolmentDate;

    @Column(name = "ivybat__Incentive_End_Date__c")
    private Date incentiveEndDate;

    @Column(name = "ivybat__Target_Reward__c")
    private Double targetReward;

    @Column(name = "ivybat__Target_Loyalty__c")
    private Double targetLoyalty;

    @Column(name = "ivybat__Target_KPI__c")
    private Double targetKPI;

    @Column(name = "ivybat__Status_scheme_for_Reward__c")
    private String statusSchemaForReward;

    @Column(name = "ivybat__Status_scheme_for_Customer_Incentive__c")
    private String statusSchemaForCustomerIncentive;

    @Column(name = "ivybat__Incentive_Target__c")
    private String incentiveTargetSchema;

    @Column(name = "ivybat__Max_Loyalty_Points__c")
    private Double maxLoyaltyPoints;

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @OneToMany(mappedBy = "incentiveMapping", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SurveyMapping> surveyMappings = new LinkedList<>();
}
