package com.bat.petra.targeting.cis.digital.service.process;

import com.bat.petra.targeting.cis.account.repository.AccountRepository;
import com.bat.petra.targeting.cis.digital.repository.DigitalContentMappingRepository;
import com.bat.petra.targeting.cis.digital.service.DigitalService;
import com.bat.petra.targeting.cis.enums.ProcessType;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess;
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessAccountRepository;
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessRepository;
import com.bat.petra.targeting.cis.targetingProcess.service.TargetingProcessService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Component
public class DigitalContentTargetingScheduler {

    private static final Logger LOGGER = LoggerFactory.getLogger(DigitalContentTargetingScheduler.class);
    private ExecutorService executorService = Executors.newCachedThreadPool();

    @Autowired
    TargetingProcessRepository targetingProcessRepository;

    @Autowired
    TargetingProcessAccountRepository targetingProcessAccountRepository;

    @Autowired
    DigitalContentMappingRepository digitalContentMappingRepository;

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    TargetingProcessService targetingProcessService;

    @Autowired
    DigitalService digitalService;

    @Scheduled(cron = "${worker.scheduling.job.cron}")
    private void executeNewProcesses(){

        TargetingProcess targetingProcess;
        while ((targetingProcess = targetingProcessService.findNextAndUpdateStatus(ProcessType.DIGITAL.getDesc())) != null) {

            LOGGER.info("------- DIGITAL TARGETING: " + targetingProcess);

            executorService.execute(
                    new DigitalContentTargeting(
                            targetingProcess,
                            targetingProcessRepository,
                            digitalService,
                            targetingProcessService,
                            TimeUnit.MINUTES.toMillis(2)
                    )
            );
        }
    }
}
