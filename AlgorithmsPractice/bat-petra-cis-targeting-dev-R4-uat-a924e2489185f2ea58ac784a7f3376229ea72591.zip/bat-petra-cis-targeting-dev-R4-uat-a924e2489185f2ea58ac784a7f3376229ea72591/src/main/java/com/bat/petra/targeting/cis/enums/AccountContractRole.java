package com.bat.petra.targeting.cis.enums;

public enum AccountContractRole {

    CONTRACTED("Contracted Account"),
    PARENT("Participating Parent"),
    OUTLET("Participating Outlet");

    private final String desc;

    AccountContractRole(String desc) {     // Constructor
        this.desc = desc;
    }

    String getSeconds() {              // Getter
        return desc;
    }
}
