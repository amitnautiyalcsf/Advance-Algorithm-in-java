package com.bat.petra.targeting.cis.targetingProcess.model;

import com.bat.petra.targeting.cis.entity.PersistableEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "Targeting_Process_Account__c", schema = "salesforce")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TargetingProcessAccount extends PersistableEntity {

    @ManyToOne
    @JoinColumn(name = "targeting_process_id__c", referencedColumnName = "name")
    private TargetingProcess targetingProcess;

    @Column(name = "Account_Id__c")
    private String accountId;

    @Column(name = "status__c")
    private String status;
}
