package com.bat.petra.targeting.cis.survey.model;

import com.bat.petra.targeting.cis.account.model.Account;
import com.bat.petra.targeting.cis.entity.IvyEntity;
import com.bat.petra.targeting.cis.incentive.model.IncentiveMapping;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "ivybase__Survey_Mapping__c", schema = "salesforce")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class SurveyMapping extends IvyEntity implements Serializable {

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ivybase__Store__c", referencedColumnName = "sfid")
    private Account account;

    @Column(name = "ivybase__Survey__c")
    private String survey;

    @Column(name = "ivybat__Migration_External_Id__c")
    private String externalId;

    @EqualsAndHashCode.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ivybat__incentive_mapping__r__ivybat__Migration_External_Id__c", referencedColumnName = "ivybat__Migration_External_Id__c")
    private IncentiveMapping incentiveMapping;
}
