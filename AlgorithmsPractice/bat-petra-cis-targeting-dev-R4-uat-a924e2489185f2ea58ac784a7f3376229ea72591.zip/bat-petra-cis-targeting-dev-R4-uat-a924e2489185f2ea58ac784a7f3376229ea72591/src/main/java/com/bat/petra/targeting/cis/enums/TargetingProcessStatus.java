package com.bat.petra.targeting.cis.enums;

public enum TargetingProcessStatus {

    NEW("New"),
    SEARCH_FINISHED("Search Finished"),
    STARTED("Started"),
    FINISHED("Finished"),
    FINISHED_WITH_ERRORS("Finished with errors");

    private final String desc;

    TargetingProcessStatus(String desc) {     // Constructor
        this.desc = desc;
    }

    public String getDesc() {              // Getter
        return desc;
    }
}
