package com.bat.petra.targeting.cis.survey.service.process;

import com.bat.petra.targeting.cis.enums.TargetingProcessStatus;
import com.bat.petra.targeting.cis.survey.service.SurveyService;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess;
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessRepository;
import com.bat.petra.targeting.cis.targetingProcess.service.TargetingProcessService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@AllArgsConstructor
public class SurveyTargeting implements Runnable {
    private static final Logger LOGGER = LoggerFactory.getLogger(SurveyTargeting.class);

    private TargetingProcess targetingProcess;
    private TargetingProcessRepository targetingProcessRepository;
    private SurveyService surveyService;
    private TargetingProcessService targetingProcessService;
    private long sleepTime;

    @Override
    public void run() {

        surveyService.saveSurveys(targetingProcess, targetingProcess.getAccounts());

        targetingProcessService.targetMissedAccounts(sleepTime, targetingProcess);

        targetingProcess.setStatus(TargetingProcessStatus.FINISHED.getDesc());
        LOGGER.info(targetingProcess.getName() + " set status to: " + TargetingProcessStatus.FINISHED.getDesc());
        targetingProcessRepository.save(targetingProcess);
    }

}
