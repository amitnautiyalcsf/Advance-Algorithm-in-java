package com.bat.petra.targeting.cis.targetingProcess.model;

import com.bat.petra.targeting.cis.entity.PersistableEntity;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

@Entity
@Table(name = "Targeting_Process__c", schema = "salesforce")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TargetingProcess extends PersistableEntity implements Serializable {

    @Column(name = "status__c")
    private String status;

    @Column(name = "targeting_kpis__c", length = 32254)
    private String targetingKPIs;

    @Column(name = "name")
    private String name;

    @Column(name = "Process_Source__c")
    private String type;

    @Column(name = "Digital_Content__c")
    private String digitalContentId;

    @Column(name = "Survey__c")
    private String surveyId;

    @Column(name = "Incentive__c")
    private String incentiveId;

    @OneToMany(mappedBy = "targetingProcess", fetch = FetchType.LAZY)
    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    private List<TargetingProcessAccount> accounts = new LinkedList<>();
}
