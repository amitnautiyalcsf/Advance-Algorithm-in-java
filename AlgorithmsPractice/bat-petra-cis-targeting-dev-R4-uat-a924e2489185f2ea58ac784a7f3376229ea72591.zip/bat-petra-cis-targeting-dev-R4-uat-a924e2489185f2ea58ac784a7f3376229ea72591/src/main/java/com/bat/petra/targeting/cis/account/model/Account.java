package com.bat.petra.targeting.cis.account.model;

import com.bat.petra.targeting.cis.digital.model.DigitalContentMapping;
import com.bat.petra.targeting.cis.entity.IvyEntity;
import com.bat.petra.targeting.cis.incentive.model.IncentiveMapping;
import com.bat.petra.targeting.cis.survey.model.SurveyMapping;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

@Entity
@Table(name = "Account", schema = "salesforce")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class Account extends IvyEntity implements Serializable {

    @Column(name = "ivybat__Is_SAP_Vendor__c")
    private Boolean isSapVendor;

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @OneToMany(targetEntity = StoreParticipant.class, mappedBy = "account", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<StoreParticipant> storeParticipant = new LinkedList<>();

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @OneToMany(targetEntity = SurveyMapping.class, mappedBy = "account", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<SurveyMapping> surveyMappings = new LinkedList<>();

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @OneToMany(targetEntity = IncentiveMapping.class, mappedBy = "account", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<IncentiveMapping> incentiveMappings = new LinkedList<>();

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @OneToMany(targetEntity = DigitalContentMapping.class, mappedBy = "account", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
    private List<DigitalContentMapping> digitalContentMappings = new LinkedList<>();

}
