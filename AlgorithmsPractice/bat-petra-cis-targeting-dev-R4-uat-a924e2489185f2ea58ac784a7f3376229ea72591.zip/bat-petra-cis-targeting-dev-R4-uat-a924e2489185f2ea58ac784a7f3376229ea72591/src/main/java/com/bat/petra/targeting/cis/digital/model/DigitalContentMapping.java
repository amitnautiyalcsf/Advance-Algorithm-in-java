package com.bat.petra.targeting.cis.digital.model;

import com.bat.petra.targeting.cis.account.model.Account;
import com.bat.petra.targeting.cis.entity.IvyEntity;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "ivybase__Digital_Content_Mapping__c", schema = "salesforce")
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
public class DigitalContentMapping  extends IvyEntity implements Serializable {

    @ToString.Exclude
    @EqualsAndHashCode.Exclude
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "ivybase__Retailer__c", referencedColumnName = "sfid")
    private Account account;

    @Column(name = "ivybase__Digital_Content__c")
    private String digitalContent;

    @Column(name = "ivybat__Migration_External_Id__c")
    private String externalId;

    @Column(name = "ivybase__Active__c")
    private String active;
}
