package com.bat.petra.targeting.cis.incentive.service;

import com.bat.petra.targeting.cis.account.model.Account;
import com.bat.petra.targeting.cis.incentive.json.IncentiveJson;
import org.springframework.stereotype.Service;

import java.util.Date;

import static com.bat.petra.targeting.cis.constants.Constants.APPROVED;
import static com.bat.petra.targeting.cis.constants.Constants.SUPPLIER;

@Service
public class IncentiveValidationService {

    public Boolean isVendor(Account account) {
        return (account.getIsSapVendor() && account.getStoreParticipant().stream().anyMatch(p -> SUPPLIER.equalsIgnoreCase(p.getRole())));
    }

    public Boolean isCustomerIncentiveEnrolled(IncentiveJson incentiveJson) {
        Date today = new Date();
        return (incentiveJson.getIncentiveAutoEnroll()
                && APPROVED.equalsIgnoreCase(incentiveJson.getIncentiveSchemeStatus())
                && today.after(incentiveJson.getIncentiveEnrolmentStartDate())
                && today.before(incentiveJson.getIncentiveEnrolmentEndDate()));
    }

    public Boolean isCustomerIncentiveEligible(IncentiveJson incentiveJson) {
        Date today = new Date();
        return (incentiveJson.getIncentiveAutoEnroll()
                    && today.before(incentiveJson.getIncentiveEnrolmentStartDate()))
                || (!incentiveJson.getIncentiveAutoEnroll()
                    && !APPROVED.equalsIgnoreCase(incentiveJson.getIncentiveSchemeStatus()));
    }
}
