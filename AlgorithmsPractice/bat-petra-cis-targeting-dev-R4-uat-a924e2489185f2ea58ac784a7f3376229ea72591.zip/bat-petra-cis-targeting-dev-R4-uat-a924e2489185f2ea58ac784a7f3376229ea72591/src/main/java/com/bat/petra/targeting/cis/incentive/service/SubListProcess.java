package com.bat.petra.targeting.cis.incentive.service;

import com.bat.petra.targeting.cis.account.model.Account;
import com.bat.petra.targeting.cis.account.repository.AccountRepository;
import com.bat.petra.targeting.cis.constants.Constants;
import com.bat.petra.targeting.cis.enums.TargetingProcessAccountStatus;
import com.bat.petra.targeting.cis.incentive.json.IncentiveJson;
import com.bat.petra.targeting.cis.incentive.model.IncentiveMapping;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcessAccount;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.atomic.AtomicInteger;

@AllArgsConstructor
public class SubListProcess implements Runnable {

    private static final Logger LOGGER = LoggerFactory.getLogger(SubListProcess.class);

    List<TargetingProcessAccount> targetingProcessAccounts;

    AccountRepository accountRepository;

    IncentiveService incentiveService;

    TargetingProcess targetingProcess;

    CountDownLatch latch;

    IncentiveJson incentiveJson;

    @Override
    public void run() {

        try {
            List<IncentiveMapping> bulkMappingToSave = new LinkedList<>();
            List<TargetingProcessAccount> bulkAccountToSave = new LinkedList<>();

            LOGGER.debug("Accounts to process " + targetingProcessAccounts.size());

            AtomicInteger alreadyTargeted = new AtomicInteger();

            targetingProcessAccounts.forEach(a -> {

                Account account = accountRepository.findBySfId(a.getAccountId());

                if (bulkMappingToSave.size() % 500 == 0) {
                    LOGGER.debug("processed account: " + bulkMappingToSave.size());
                }

                if (incentiveService.isNotTargetedIncentiveInRelation(account, targetingProcess.getIncentiveId())) {

                    IncentiveMapping incentiveMappingNotFull = incentiveService.createIncentiveMapping(incentiveJson, targetingProcess);
                    IncentiveMapping incentiveMapping = incentiveService.setupAccountFields(incentiveMappingNotFull, account, incentiveJson);

                    bulkMappingToSave.add(incentiveMapping);
                    a.setStatus(TargetingProcessAccountStatus.GENERATED_INCENTIVE.getDesc());
                    bulkAccountToSave.add(a);

                } else {
                    alreadyTargeted.getAndIncrement();
                }

                if (bulkMappingToSave.size() > Constants.BULK_SIZE) {
                    LOGGER.debug("SAVING INCENTIVE MAPPING: " + bulkMappingToSave.size());
                    incentiveService.saveListAndClear(bulkMappingToSave, bulkAccountToSave, incentiveJson, targetingProcess);
                }

            });

            if (alreadyTargeted.get() > 0) {
                LOGGER.info(targetingProcess.getName() + " - " +
                        "Accounts already targeted by: " + targetingProcess.getIncentiveId() + ": " + alreadyTargeted);
            }

            if (!CollectionUtils.isEmpty(bulkMappingToSave)) {
                LOGGER.debug(targetingProcess.getName() + " - SAVING REST INCENTIVE MAPPING");
                incentiveService.saveListAndClear(bulkMappingToSave, bulkAccountToSave, incentiveJson, targetingProcess);
            }

        } finally {
            latch.countDown();
        }

    }
}
