package com.bat.petra.targeting.cis.incentive.json;

import lombok.Data;

import java.io.Serializable;
import java.util.Date;

@Data
public class IncentiveJson implements Serializable {

    private String incentiveSchemeId;
    private Date incentiveEndDate;
    private Double targetKPI;
    private Double remainingTarget;
    private Date incentiveEnrolmentStartDate;
    private Date incentiveEnrolmentEndDate;
    private String incentiveSchemeRewardType;
    private String incentiveSchemeStatus;
    private Double targetDiscountValue;
    private Double targetDiscountTradePayment;
    private Double maxDiscount;
    private Double maxTradePayment;
    private Double targetDiscountPercent;
    private Double targetDiscountLoyaltyPoints;
    private Double maxDiscountLoyaltyPoints;
    private Boolean incentiveAutoEnroll;
    private String surveyQuestionaire;
}
