package com.bat.petra.targeting.cis.survey.service;

import com.bat.petra.targeting.cis.account.model.Account;
import com.bat.petra.targeting.cis.account.repository.AccountRepository;
import com.bat.petra.targeting.cis.constants.Constants;
import com.bat.petra.targeting.cis.enums.TargetingProcessAccountStatus;
import com.bat.petra.targeting.cis.incentive.model.IncentiveMapping;
import com.bat.petra.targeting.cis.survey.model.SurveyMapping;
import com.bat.petra.targeting.cis.survey.repository.SurveyMappingRepository;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcessAccount;
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessAccountRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
public class SurveyService {
    private static final Logger LOGGER = LoggerFactory.getLogger(SurveyService.class);

    @Autowired
    TargetingProcessAccountRepository targetingProcessAccountRepository;

    @Autowired
    AccountRepository accountRepository;

    @Autowired
    SurveyMappingRepository surveyMappingRepository;

    @Transactional(Transactional.TxType.REQUIRED)
    public void saveSurveys(TargetingProcess targetingProcess, List<TargetingProcessAccount> targetingProcessAccounts) {
        LOGGER.info(targetingProcess.getName() + " - Found TP accounts to target: " + targetingProcessAccounts.size());

        List<Account> bulkMappingToSave = new LinkedList<>();
        List<TargetingProcessAccount> bulkAccountToSave = new LinkedList<>();

        AtomicInteger alreadyTargeted = new AtomicInteger();

        targetingProcessAccounts.forEach(a -> {

            Account account = accountRepository.findBySfId(a.getAccountId());

            if (isNotTargetedSurveyInRelation(account, targetingProcess.getSurveyId())) {

                SurveyMapping surveyMapping = createSurveyMapping(targetingProcess.getSurveyId(), account);

                account.getSurveyMappings().add(surveyMapping);
                bulkMappingToSave.add(account);
                a.setStatus(TargetingProcessAccountStatus.GENERATED_SURVEY.getDesc());
                bulkAccountToSave.add(a);
            } else {
                alreadyTargeted.getAndIncrement();
            }

            if (bulkMappingToSave.size() > Constants.BULK_SIZE) {
                saveListAndClear(bulkMappingToSave, bulkAccountToSave, targetingProcess);
            }
        });

        if (alreadyTargeted.get() > 0) {
            LOGGER.info(targetingProcess.getName() + " - " +
                    "Accounts already targeted by: " + targetingProcess.getSurveyId() + ": " + alreadyTargeted);
        }

        if (!CollectionUtils.isEmpty(bulkMappingToSave)) {
            saveListAndClear(bulkMappingToSave, bulkAccountToSave, targetingProcess);
        }
    }

    public Boolean isNotTargetedSurveyInRelation(Account account, String surveyId) {

        List<SurveyMapping> list = new ArrayList<>();
        if (!CollectionUtils.isEmpty(account.getSurveyMappings())) {
            list = account.getSurveyMappings().stream()
                    .filter(m -> surveyId.equals(m.getSurvey()))
                    .collect(Collectors.toList());
        }

        return CollectionUtils.isEmpty(list);
    }

    public SurveyMapping setupSurveyFromIncentive(Account account, String surveyId, IncentiveMapping incentiveMapping) {
        SurveyMapping surveyMapping = new SurveyMapping();
        surveyMapping.setExternalId(UUID.randomUUID().toString());
        surveyMapping.setAccount(account);
        surveyMapping.setSurvey(surveyId);
        surveyMapping.setIncentiveMapping(incentiveMapping);
        return surveyMapping;
    }

    private SurveyMapping createSurveyMapping(String surveyId, Account account) {

        SurveyMapping surveyMapping = new SurveyMapping();
        surveyMapping.setName(UUID.randomUUID().toString());
        surveyMapping.setSurvey(surveyId);
        surveyMapping.setExternalId(UUID.randomUUID().toString());
        surveyMapping.setAccount(account);
        return surveyMapping;
    }

    private void saveListAndClear(List<Account> bulkMappingToSave,
                                  List<TargetingProcessAccount> bulkAccountToSave, TargetingProcess targetingProcess) {
        accountRepository.saveAll(bulkMappingToSave);
        LOGGER.info(targetingProcess.getName() + " - SurveyMapping saved to DB: " + bulkMappingToSave.size());
        targetingProcessAccountRepository.saveAll(bulkAccountToSave);
        LOGGER.info(targetingProcess.getName() + " - TargetingProcessAccount with status updated saved to DB: " + bulkAccountToSave.size());
        bulkAccountToSave.clear();
        bulkMappingToSave.clear();
    }

}
