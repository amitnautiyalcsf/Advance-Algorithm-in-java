package com.bat.petra.targeting.cis.targetingProcess.service;

import com.bat.petra.targeting.cis.digital.service.DigitalService;
import com.bat.petra.targeting.cis.enums.ProcessType;
import com.bat.petra.targeting.cis.enums.TargetingProcessAccountStatus;
import com.bat.petra.targeting.cis.enums.TargetingProcessStatus;
import com.bat.petra.targeting.cis.incentive.service.IncentiveService;
import com.bat.petra.targeting.cis.survey.service.SurveyService;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcessAccount;
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessAccountRepository;
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessRepository;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.transaction.Transactional;
import java.util.List;

@Component
@AllArgsConstructor
public class TargetingProcessService {
    private static final Logger LOGGER = LoggerFactory.getLogger(TargetingProcessService.class);

    private final TargetingProcessRepository targetingProcessRepository;
    private final TargetingProcessAccountRepository targetingProcessAccountRepository;
    private final SurveyService surveyService;
    private final IncentiveService incentiveService;
    private final DigitalService digitalService;

    @Transactional(Transactional.TxType.REQUIRES_NEW)
    public TargetingProcess findNextAndUpdateStatus(String processType) {
        TargetingProcess targetingProcess = targetingProcessRepository.findFirstByStatusAndType(
                TargetingProcessStatus.SEARCH_FINISHED.getDesc(), processType);

        if (targetingProcess == null) {
            return null;
        }

        if (!CollectionUtils.isEmpty(targetingProcess.getAccounts())) {
            targetingProcess.setStatus(TargetingProcessStatus.STARTED.getDesc());
            targetingProcessRepository.save(targetingProcess);
            LOGGER.info(targetingProcess.getName() + " set status to: " + TargetingProcessStatus.STARTED.getDesc());

            return targetingProcess;
        } else {
            return null;
        }

    }

    public void targetMissedAccounts(long sleepTime, TargetingProcess targetingProcess) {
        boolean hasNewAccounts = true;
        int numberOfTries = 0;

        while (hasNewAccounts) {
            List<TargetingProcessAccount> missedAccounts = waitAndReturnMissedAccounts(sleepTime, targetingProcess);

            if (CollectionUtils.isEmpty(missedAccounts)) {
                hasNewAccounts = false;
            } else {
                LOGGER.info(targetingProcess.getName() + " - Missed Accounts Found: " + missedAccounts.size());

                if (targetingProcess.getType().equals(ProcessType.SURVEY.getDesc())) {
                    surveyService.saveSurveys(targetingProcess, missedAccounts);
                } else if (targetingProcess.getType().equals(ProcessType.INCENTIVE.getDesc())) {
                    incentiveService.saveAllIncentive(targetingProcess, missedAccounts);
                } else if (targetingProcess.getType().equals(ProcessType.DIGITAL.getDesc())) {
                    digitalService.saveDigitals(targetingProcess, missedAccounts);
                }

            }
            numberOfTries++;

            if (numberOfTries > 10) {
                hasNewAccounts = false;
            }
        }
    }

    private List<TargetingProcessAccount> waitAndReturnMissedAccounts(long sleepTime, TargetingProcess targetingProcess) {
        try {
            Thread.sleep(sleepTime);
        } catch (InterruptedException e) {
            LOGGER.info("Sleep interrupted: " + e);
        }

        return targetingProcessAccountRepository.findAllByTargetingProcessAndStatus(targetingProcess,
                TargetingProcessAccountStatus.NEW.getDesc());
    }
}
