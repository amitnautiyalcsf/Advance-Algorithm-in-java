package com.bat.petra.targeting.cis.targetingProcess.repository;

import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess;
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcessAccount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TargetingProcessAccountRepository extends JpaRepository<TargetingProcessAccount, Integer> {

    List<TargetingProcessAccount> findAllByTargetingProcessId(Integer id);
    List<TargetingProcessAccount> findAllByTargetingProcessAndStatus(TargetingProcess targetingProcess, String status);
    TargetingProcessAccount findByAccountId(String accounId);
}
