package com.bat.petra.targeting.cis.digital

import com.bat.petra.targeting.cis.account.model.Account
import com.bat.petra.targeting.cis.account.repository.AccountRepository
import com.bat.petra.targeting.cis.digital.repository.DigitalContentMappingRepository
import com.bat.petra.targeting.cis.digital.service.DigitalService
import com.bat.petra.targeting.cis.digital.service.process.DigitalContentTargeting
import com.bat.petra.targeting.cis.enums.ProcessType
import com.bat.petra.targeting.cis.enums.TargetingProcessAccountStatus
import com.bat.petra.targeting.cis.enums.TargetingProcessStatus
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcessAccount
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessAccountRepository
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessRepository
import com.bat.petra.targeting.cis.targetingProcess.service.TargetingProcessService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import spock.lang.Specification

import java.util.concurrent.Executors
import java.util.concurrent.Future

@SpringBootTest
class DigitalContentTargetingSpec extends Specification {

    @Autowired
    DigitalContentMappingRepository digitalContentMappingRepository

    @Autowired
    TargetingProcessRepository targetingProcessRepository

    @Autowired
    TargetingProcessAccountRepository targetingProcessAccountRepository

    @Autowired
    AccountRepository accountRepository

    @Autowired
    DigitalService digitalService

    @Autowired
    TargetingProcessService targetingProcessService

    def cleanup() {
        targetingProcessAccountRepository.deleteAll()
        targetingProcessRepository.deleteAll()
        digitalContentMappingRepository.deleteAll()
    }


    def "should target digital content"() {

        given:
        def targetingProcess  = new TargetingProcess(
                TargetingProcessStatus.SEARCH_FINISHED.desc,
                "90",
                "name",
                ProcessType.DIGITAL.desc,
                "1",
                "",
                "",
                new ArrayList<TargetingProcessAccount>()
        )
        def targetingProcessAccount = new TargetingProcessAccount(
                targetingProcess, "1", TargetingProcessAccountStatus.NEW.desc
        )
        targetingProcess.accounts.add(targetingProcessAccount)
        targetingProcessRepository.save(targetingProcess)
        targetingProcessAccountRepository.save(targetingProcessAccount)
        def account = new Account()
        account.setSfId("1")
        accountRepository.save(account)

        def executorService = Executors.newFixedThreadPool(1)

        when:
        Future<?> task = executorService.submit(new DigitalContentTargeting(
                targetingProcess,
                targetingProcessRepository,
                digitalService,
                targetingProcessService,
                1
        ))

        while(!task.done) {
        }

        then:
        targetingProcessRepository.findById(1).get().status ==  TargetingProcessStatus.FINISHED.desc
        targetingProcessAccountRepository.findById(1).get().status == TargetingProcessAccountStatus.GENERATED_DIGITAL.desc
        digitalContentMappingRepository.findAll().size() > 0
    }
}
