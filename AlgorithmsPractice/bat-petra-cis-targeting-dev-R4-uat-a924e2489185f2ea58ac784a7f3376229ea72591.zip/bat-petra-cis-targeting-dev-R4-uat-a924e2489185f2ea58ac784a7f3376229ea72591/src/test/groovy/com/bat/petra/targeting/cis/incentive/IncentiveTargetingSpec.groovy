package com.bat.petra.targeting.cis.incentive

import com.bat.petra.targeting.cis.CisApplication
import com.bat.petra.targeting.cis.account.model.Account
import com.bat.petra.targeting.cis.account.repository.AccountRepository
import com.bat.petra.targeting.cis.enums.ProcessType
import com.bat.petra.targeting.cis.enums.TargetingProcessAccountStatus
import com.bat.petra.targeting.cis.enums.TargetingProcessStatus
import com.bat.petra.targeting.cis.incentive.repository.IncentiveMappingRepository
import com.bat.petra.targeting.cis.incentive.service.IncentiveService
import com.bat.petra.targeting.cis.incentive.service.process.IncentiveTargeting
import com.bat.petra.targeting.cis.survey.repository.SurveyMappingRepository
import com.bat.petra.targeting.cis.survey.service.SurveyService
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcess
import com.bat.petra.targeting.cis.targetingProcess.model.TargetingProcessAccount
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessAccountRepository
import com.bat.petra.targeting.cis.targetingProcess.repository.TargetingProcessRepository
import com.bat.petra.targeting.cis.targetingProcess.service.TargetingProcessService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import spock.lang.Ignore
import spock.lang.Specification

import java.util.concurrent.Executors
import java.util.concurrent.Future

@SpringBootTest(classes = CisApplication.class)
class IncentiveTargetingSpec extends Specification {

    @Autowired
    TargetingProcessRepository targetingProcessRepository

    @Autowired
    TargetingProcessAccountRepository targetingProcessAccountRepository

    @Autowired
    AccountRepository accountRepository

    @Autowired
    SurveyMappingRepository surveyMappingRepository

    @Autowired
    IncentiveMappingRepository incentiveMappingRepository

    @Autowired
    SurveyService surveyService

    @Autowired
    IncentiveService incentiveService

    @Autowired
    TargetingProcessService targetingProcessService

    def cleanup() {

        targetingProcessAccountRepository.deleteAll()
        targetingProcessRepository.deleteAll()
        surveyMappingRepository.deleteAll()
        incentiveMappingRepository.deleteAll()
        accountRepository.deleteAll()
    }

    @Ignore
    def "should target incentive"() {

        given:
        def targetingProcess  = new TargetingProcess(
                TargetingProcessStatus.SEARCH_FINISHED.desc,
                '{\"targetKPI\":7,\"targetDiscountValue\":null,\"targetDiscountTradePayment\":null,\"targetDiscountPercent\":\"8\",\"targetDiscountLoyaltyPoints\":null,\"surveyQuestionaire\":null,\"remainingTarget\":null,\"maxTradePayment\":null,\"maxDiscountLoyaltyPoints\":null,\"maxDiscount\":\"1000\",\"incentiveSchemeStatus\":\"Draft\",\"incentiveSchemeRewardType\":\"% Discount on Invoice\",\"incentiveSchemeId\":\"a2g1q0000006WaOAAU\",\"incentiveEnrolmentStartDate\":\"2019-02-21\",\"incentiveEnrolmentEndDate\":\"2019-02-28\",\"incentiveEndDate\":\"2019-03-31\",\"incentiveAutoEnroll\":false}',
                "name",
                ProcessType.INCENTIVE.desc,
                "",
                "",
                "1",
                new ArrayList<TargetingProcessAccount>()
        )
        def targetingProcessAccount = new TargetingProcessAccount(
                targetingProcess, "1", TargetingProcessAccountStatus.NEW.desc
        )
        targetingProcess.accounts.add(targetingProcessAccount)
        targetingProcessRepository.save(targetingProcess)
        targetingProcessAccountRepository.save(targetingProcessAccount)

        def account = new Account()
        account.setSfId("1")
        accountRepository.save(account)

        def executorService = Executors.newFixedThreadPool(1)

        when:
        Future<?> task = executorService.submit(new IncentiveTargeting(
                targetingProcess,
                targetingProcessRepository,
                incentiveService,
                targetingProcessService,
                1
        ))

        while(!task.done) {
        }

        then:
        targetingProcessRepository.findById(1).get().status ==  TargetingProcessStatus.FINISHED.desc
        incentiveMappingRepository.findAll().size() > 0
    }
}
