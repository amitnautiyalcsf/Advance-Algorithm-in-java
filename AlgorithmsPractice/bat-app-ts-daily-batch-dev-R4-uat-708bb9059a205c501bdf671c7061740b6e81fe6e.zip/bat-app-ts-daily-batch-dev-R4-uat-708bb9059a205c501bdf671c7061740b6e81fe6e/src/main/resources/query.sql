SELECT a.ivybat__mobile__c                                           AS "FONE1",
       a.ivybat__telephone_1__c                                      AS "FONE2",
       a.ivybat__telephone_2__c                                      AS "FONE3",
       a.ivybat__telephone_3__c                                      AS "FONE4",
       a.ivybat__customer_code__c                                    AS "POS",
       a.name                                                        AS "LName",
       c.name                                                        AS "Contact",
       a.ivybat__commercialname__c                                   AS "SNAME",
       t.ivybat__Territory__c                                        AS "TLSLT",
       ''                                                            AS "BADDEBT",
       h.name                                                        AS "GEOREPT",
       h.name                                                        AS "AREA",
       CONCAT('https://petra3--batuat2.my.salesforce.com/', a.sfid) AS "CustomerSFURL", --place to specify SF domain
       a.sfid                                                        AS "CustomerSFID",
       a.ivybat__sAP_customerid__c                                   AS "CustomerSAPID",
       r2.ivybase__email__c                                           AS "ResourceOneviewID"
FROM salesforce.ivybase__visit__c AS v
       INNER JOIN
     salesforce.account AS a ON v.ivybase__store__c = a.sfid
       INNER JOIN
     salesforce.contact AS c ON a.ivybat__primary_contact__c = c.sfid
       INNER JOIN
     salesforce.ivybase__territory_store_mapping__c AS t ON a.sfid = t.ivybase__store__c
       INNER JOIN
     salesforce.ivybase__location_hierarchy__c AS h ON a.sales_territory__c = h.sfid
       INNER JOIN
     salesforce.ivybase__resource__c AS r ON v.ivybase__resource__c = r.sfid
       INNER JOIN
     salesforce.ivybase__resource_type__c AS rt ON r.ivybase__resource_type__c = rt.sfid
       INNER JOIN
     salesforce.ivybase__resource__c AS r2 ON r2.sfid = h.ivybase__primary_resource__c
WHERE t.ivybat__territory_type__c = 'Telesales'
  AND rt.ivybat__type__c = 'Telesales Analyst'
  AND h.ivybat__market_iso__c = ?
  AND v.ivybase__original_date__c = CURRENT_DATE + 1
