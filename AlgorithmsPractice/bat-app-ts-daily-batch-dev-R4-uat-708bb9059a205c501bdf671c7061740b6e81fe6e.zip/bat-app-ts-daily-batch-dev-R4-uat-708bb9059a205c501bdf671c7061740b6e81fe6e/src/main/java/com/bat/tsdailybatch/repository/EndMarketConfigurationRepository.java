package com.bat.tsdailybatch.repository;

import com.bat.tsdailybatch.model.EndMarketConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EndMarketConfigurationRepository extends JpaRepository<EndMarketConfiguration, String> {

    List<EndMarketConfiguration> findAllByRecordTypeIdAndActive(String recordTypeId, boolean active);
}
