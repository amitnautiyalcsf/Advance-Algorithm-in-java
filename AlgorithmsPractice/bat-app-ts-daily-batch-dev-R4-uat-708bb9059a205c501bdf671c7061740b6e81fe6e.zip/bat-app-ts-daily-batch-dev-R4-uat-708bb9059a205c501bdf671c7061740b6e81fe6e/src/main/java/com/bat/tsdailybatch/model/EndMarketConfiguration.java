package com.bat.tsdailybatch.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "end_market_configuration__c", schema = "salesforce")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class EndMarketConfiguration {

    @Id
    @Column(name = "sfid")
    private String id;

    @Column(name = "market_iso__c")
    private String marketIso;

    @Column(name = "connection_string__c")
    private String connectionString;

    @Column(name = "container_name__c")
    private String containerName;

    @Column(name = "recordtypeid")
    private String recordTypeId;

    @Column(name = "active__c")
    private boolean active;
}
