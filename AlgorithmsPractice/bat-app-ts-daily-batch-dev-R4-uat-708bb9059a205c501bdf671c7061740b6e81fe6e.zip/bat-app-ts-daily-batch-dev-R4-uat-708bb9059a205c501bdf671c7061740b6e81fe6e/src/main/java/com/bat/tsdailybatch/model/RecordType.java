package com.bat.tsdailybatch.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "recordtype", schema = "salesforce")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RecordType {

    @Id
    @Column(name = "sfid")
    private String id;

    @Column(name = "name")
    private String name;
}
