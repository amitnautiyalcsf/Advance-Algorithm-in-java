package com.bat.tsdailybatch.repository;

import com.bat.tsdailybatch.model.RecordType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RecordTypeRepository extends JpaRepository<RecordType, String> {

    RecordType findByName(String name);
}
