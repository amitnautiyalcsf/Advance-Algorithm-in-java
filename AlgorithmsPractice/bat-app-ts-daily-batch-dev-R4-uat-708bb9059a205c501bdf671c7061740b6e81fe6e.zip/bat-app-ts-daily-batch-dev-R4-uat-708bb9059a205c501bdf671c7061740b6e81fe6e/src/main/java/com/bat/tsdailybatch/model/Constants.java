package com.bat.tsdailybatch.model;

public class Constants {

    public static final String CONF_RECORD_TYPE = "TeleSales Azure Blob Store Configuration";
}
