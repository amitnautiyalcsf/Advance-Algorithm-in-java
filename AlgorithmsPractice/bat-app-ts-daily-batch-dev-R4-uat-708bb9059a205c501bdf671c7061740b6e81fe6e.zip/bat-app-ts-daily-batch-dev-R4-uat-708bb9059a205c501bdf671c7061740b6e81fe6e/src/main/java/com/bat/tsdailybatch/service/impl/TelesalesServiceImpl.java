package com.bat.tsdailybatch.service.impl;

import com.bat.tsdailybatch.model.EndMarketConfiguration;
import com.bat.tsdailybatch.service.TelesalesService;
import com.opencsv.CSVWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Service
public class TelesalesServiceImpl implements TelesalesService {

    private static final Logger LOGGER = LoggerFactory.getLogger(TelesalesServiceImpl.class);

    @Autowired
    private DataSource dataSource;

    @Override
    public Optional<ResultSet> executeQuery(String sql, EndMarketConfiguration marketConfiguration) {

        LOGGER.info("===QUERY EXECUTION===");

        try (Connection connection = dataSource.getConnection()) {

            Optional<PreparedStatement> preparedStatement = this.prepareStatement(marketConfiguration, sql, connection);

            if(preparedStatement.isPresent()) {

                return Optional.of(preparedStatement.get().executeQuery());

            } else {

                return Optional.empty();
            }


        } catch (SQLException ex) {

            LOGGER.info(ex.getMessage());
            LOGGER.info(ex.getSQLState());
            ex.printStackTrace();
        }

        return Optional.empty();
    }

    @Override
    public Optional<ByteArrayOutputStream> mapResultSetToCSVFile(ResultSet set) {

        LOGGER.info("===MAPPING DATA TO CSV===");

        try (ByteArrayOutputStream os = new ByteArrayOutputStream()) {
            try (OutputStreamWriter writer = new OutputStreamWriter(os)) {
                try (CSVWriter csvWriter = new CSVWriter(writer, ';', CSVWriter.NO_QUOTE_CHARACTER)) {

                    csvWriter.writeAll(set, true, true, false);
                    return Optional.of(os);
                }
            }
        } catch (IOException | SQLException ex) {

            LOGGER.info(ex.getMessage());
            ex.printStackTrace();
        }

        return Optional.empty();
    }

    @Override
    public Optional<PreparedStatement> prepareStatement(
            EndMarketConfiguration marketConfiguration, String sql, Connection connection
    ) {

        LOGGER.info("===PREPARING QUERY===");

        try {

            PreparedStatement preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, marketConfiguration.getMarketIso());

            LOGGER.info("===PREPARING QUERY FINISHED===");

            return Optional.of(preparedStatement);

        } catch (SQLException ex) {

            LOGGER.info(ex.getMessage());
            LOGGER.info(ex.getSQLState());
            ex.printStackTrace();
        }

        return Optional.empty();
    }
}
