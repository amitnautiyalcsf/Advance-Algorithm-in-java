package com.bat.tsdailybatch.service.impl;

import com.bat.tsdailybatch.model.EndMarketConfiguration;
import com.bat.tsdailybatch.service.AzureService;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import java.net.URISyntaxException;
import java.security.InvalidKeyException;

@Service
public class AzureServiceImpl implements AzureService {

    private static final Logger LOGGER = LogManager.getLogger(AzureServiceImpl.class);

    @Override
    public Boolean uploadFileToAzure(ByteArrayOutputStream file, String filename, EndMarketConfiguration marketConfiguration) {

        LOGGER.info("===UPLOADING FILE TO AZURE===");

        try {

            CloudStorageAccount storageAccount = CloudStorageAccount.parse(marketConfiguration.getConnectionString());
            CloudBlobClient blobClient = storageAccount.createCloudBlobClient();
            CloudBlobContainer container = blobClient.getContainerReference(marketConfiguration.getContainerName());
            CloudBlockBlob blob = container.getBlockBlobReference(filename);
            blob.uploadFromByteArray(file.toByteArray(), 0, file.size());
            LOGGER.info("===UPLOADING ENDED===");
            return Boolean.TRUE;

        } catch (URISyntaxException | InvalidKeyException | StorageException | IOException ex) {

            LOGGER.info(ex.getMessage());
            ex.printStackTrace();
        }
        return Boolean.FALSE;
    }
}
