package com.bat.tsdailybatch.service;

import com.bat.tsdailybatch.model.EndMarketConfiguration;

import java.io.ByteArrayOutputStream;

public interface AzureService {

    Boolean uploadFileToAzure(ByteArrayOutputStream file, String filename, EndMarketConfiguration marketConfiguration);
}
