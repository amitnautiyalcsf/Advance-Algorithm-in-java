package com.bat.tsdailybatch.service;

import com.bat.tsdailybatch.model.Constants;
import com.bat.tsdailybatch.model.EndMarketConfiguration;
import com.bat.tsdailybatch.model.RecordType;
import com.bat.tsdailybatch.repository.EndMarketConfigurationRepository;
import com.bat.tsdailybatch.repository.RecordTypeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Component
public class TelesalesDailyBatch {

    private static final Logger LOGGER = LoggerFactory.getLogger(TelesalesDailyBatch.class);

    @Value("${sql.query}")
    private String query;

    @Autowired
    private AzureService azureService;

    @Autowired
    private TelesalesService telesalesService;

    @Autowired
    private EndMarketConfigurationRepository endMarketConfigurationRepository;

    @Autowired
    private RecordTypeRepository recordTypeRepository;

    @Scheduled(cron = "${cron.value}")
    public void processData() {

        LOGGER.info("===STARTING PROCESS===");

        RecordType telesalesRecordType = recordTypeRepository.findByName(Constants.CONF_RECORD_TYPE);
        List<EndMarketConfiguration> markets = endMarketConfigurationRepository.findAllByRecordTypeIdAndActive(telesalesRecordType.getId(), true);

        LOGGER.info("===MARKET CONFIGURATIONS FOUND: " + markets.size() +"===");

        markets.forEach(m -> {

            Optional<ResultSet> data = telesalesService.executeQuery(query, m);

            data.ifPresent(d -> {
                Optional<ByteArrayOutputStream> file = telesalesService.mapResultSetToCSVFile(d);
                file.ifPresent(f -> azureService.uploadFileToAzure(f, generateName(m), m));
            });

        });

        LOGGER.info("===PROCESS END===");
    }

    public String generateName(EndMarketConfiguration endMarketConfiguration) {

        LocalDate now = LocalDate.now();
        return endMarketConfiguration.getMarketIso() + "_" + now.getDayOfMonth() + "_" + now.getMonth() + "_" + now.getYear() + ".csv";
    }
}
