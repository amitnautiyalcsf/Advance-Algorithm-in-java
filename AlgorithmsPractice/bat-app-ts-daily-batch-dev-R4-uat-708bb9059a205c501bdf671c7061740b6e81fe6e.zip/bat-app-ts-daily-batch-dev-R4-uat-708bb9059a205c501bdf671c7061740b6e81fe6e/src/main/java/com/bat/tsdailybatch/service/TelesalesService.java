package com.bat.tsdailybatch.service;

import com.bat.tsdailybatch.model.EndMarketConfiguration;

import java.io.ByteArrayOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Optional;

public interface TelesalesService {

    Optional<ResultSet> executeQuery(String sql, EndMarketConfiguration marketConfiguration);
    Optional<ByteArrayOutputStream> mapResultSetToCSVFile(ResultSet set);
    Optional<PreparedStatement> prepareStatement(EndMarketConfiguration marketConfiguration, String sql, Connection connection);
}
