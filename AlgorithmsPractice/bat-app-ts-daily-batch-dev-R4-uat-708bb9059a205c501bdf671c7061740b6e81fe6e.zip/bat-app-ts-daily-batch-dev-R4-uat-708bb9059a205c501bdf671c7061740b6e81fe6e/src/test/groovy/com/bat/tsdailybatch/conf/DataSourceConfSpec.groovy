package com.bat.tsdailybatch.conf

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import spock.lang.Specification

import javax.sql.DataSource

@SpringBootTest
class DataSourceConfSpec extends Specification {

    @Autowired
    DataSource dataSource

    def "DataSource should be initialized"() {

        when:
        System.out.println()

        then:
        dataSource.getProperties().get("username") == "sa"
        dataSource.getProperties().get("url") == "jdbc:h2:mem:db;DB_CLOSE_DELAY=-1;INIT=CREATE SCHEMA IF NOT EXISTS SALESFORCE;"
    }
}
