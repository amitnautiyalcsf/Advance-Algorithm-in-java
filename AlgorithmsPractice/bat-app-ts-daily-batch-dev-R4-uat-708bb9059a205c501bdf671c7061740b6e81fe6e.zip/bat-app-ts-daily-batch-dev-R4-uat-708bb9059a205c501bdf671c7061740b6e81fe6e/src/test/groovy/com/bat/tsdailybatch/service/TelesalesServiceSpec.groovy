package com.bat.tsdailybatch.service

import com.bat.tsdailybatch.model.EndMarketConfiguration
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import spock.lang.Specification

import javax.sql.DataSource
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

@SpringBootTest
class TelesalesServiceSpec extends Specification {

    @Autowired
    TelesalesService service

    @Autowired
    DataSource dataSource

    def setup() {

        def conn = dataSource.getConnection()
        def statement1 = conn.prepareStatement("CREATE TABLE tmp_table (NAME VARCHAR(255) NOT NULL, AGE INTEGER NOT NULL, SOME_DATE TIMESTAMP)")
        statement1.execute()
        def statement2 = conn.prepareStatement("INSERT INTO tmp_table VALUES('BR',1,'2019-09-17 18:47:52.069')")
        statement2.execute()
        def statement3 = conn.prepareStatement("INSERT INTO tmp_table VALUES('PL',2,'2019-09-17 18:47:52.069')")
        statement3.execute()
        conn.close()
    }

    def cleanup() {

        def conn = dataSource.getConnection()
        def statament =  conn.prepareStatement("DROP TABLE tmp_table")
        statament.execute()
    }

    def "should execute query and return ResultSet, when given sql"() {

        given:
        def sql = "SELECT * FROM tmp_table WHERE name = ?"
        def emConf = new EndMarketConfiguration("1", "BR", "BlobEndpoint=https://batstorppnepetrabrzedi.blob.core.windows.net/;QueueEndpoint=https://batstorppnepetrabrzedi.queue.core.windows.net/;FileEndpoint=https://batstorppnepetrabrzedi.file.core.windows.net/;TableEndpoint=https://batstorppnepetrabrzedi.table.core.windows.net/;SharedAccessSignature=sv=2018-03-28&ss=bfqt&srt=sco&sp=rwdlacup&se=2020-01-01T18:39:35Z&st=2019-02-12T10:39:35Z&spr=https,http&sig=5irED0V78%2B6YNbRC6C%2By0rEi%2Bgge3L2kbimeqiB3ix8%3D", "batcontainer", "recordTypeId", true)

        when:
        def result = service.executeQuery(sql, emConf)

        then:
        result.isPresent()
    }

    def "should prepare query"() {

        given:
        def sql = "SELECT * FROM tmp_table WHERE name = ?"
        def emConf = new EndMarketConfiguration("1", "BR", "BlobEndpoint=https://batstorppnepetrabrzedi.blob.core.windows.net/;QueueEndpoint=https://batstorppnepetrabrzedi.queue.core.windows.net/;FileEndpoint=https://batstorppnepetrabrzedi.file.core.windows.net/;TableEndpoint=https://batstorppnepetrabrzedi.table.core.windows.net/;SharedAccessSignature=sv=2018-03-28&ss=bfqt&srt=sco&sp=rwdlacup&se=2020-01-01T18:39:35Z&st=2019-02-12T10:39:35Z&spr=https,http&sig=5irED0V78%2B6YNbRC6C%2By0rEi%2Bgge3L2kbimeqiB3ix8%3D", "batcontainer", "recordTypeId", true)
        def connection = dataSource.getConnection()

        when:
        def result = service.prepareStatement(emConf, sql, connection)
        def queryParams = result.get().toString().split("SELECT")[1]

        then:
        queryParams.endsWith("{1: 'BR'}")
        queryParams.startsWith(" * FROM tmp_table WHERE name = ?")
    }
}
