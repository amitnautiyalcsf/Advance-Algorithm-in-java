package com.bat.tsdailybatch

import com.bat.tsdailybatch.service.TelesalesDailyBatch
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import spock.lang.Specification

@SpringBootTest
class TsdailybatchApplicationSpec extends Specification {

    @Autowired
    TelesalesDailyBatch batch

    def "context loads"() {

        expect:
        batch
    }
}
