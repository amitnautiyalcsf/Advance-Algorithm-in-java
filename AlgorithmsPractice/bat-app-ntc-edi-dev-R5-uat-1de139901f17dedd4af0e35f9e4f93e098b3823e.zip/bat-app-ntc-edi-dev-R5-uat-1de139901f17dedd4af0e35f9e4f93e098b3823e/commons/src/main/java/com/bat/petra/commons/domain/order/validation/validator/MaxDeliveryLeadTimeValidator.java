package com.bat.petra.commons.domain.order.validation.validator;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.order.service.OrderFacade;
import com.bat.petra.commons.utils.DateUtils;
import com.bat.petra.commons.utils.OrderItemUtils;
import com.bat.petra.commons.domain.order.validation.OrderValidator;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import lombok.extern.log4j.Log4j2;

import java.util.Optional;

import static com.bat.petra.commons.domain.order.validation.OrderValidationResult.withError;

/**
 * @author arkadiusz.wronski, created on 2019-06-14.
 */
@Log4j2
public class MaxDeliveryLeadTimeValidator implements OrderValidator {

  private OrderFacade orderFacade;

  public MaxDeliveryLeadTimeValidator(OrderFacade orderFacade){
    this.orderFacade = orderFacade;

  }
  @Override
  public OrderValidationResult validateOrder(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    try {
      String locationHierarchy = context.getValidationParams().get(OrderItemValidationObject.LOCATION_HIERARCHY.name()).toString();

      Optional<Integer> maxDeliveryLeadTime = orderFacade.getOrderMaxDeliveryDate(locationHierarchy);
      if (maxDeliveryLeadTime.isPresent() && OrderItemUtils.ifDeliveryDateLaterThanMaxDeliveryTime(
          DateUtils.parseLocalDate(orderItem.getDeliveryDate()), orderItem.getOrderUploadDate(), maxDeliveryLeadTime.get())) {
        return withError("Delivery Date should not be later than " + maxDeliveryLeadTime.get() + " days");
      }
    }catch (NullPointerException ex){
      log.warn("Has not found validation param "+OrderItemValidationObject.LOCATION_HIERARCHY.name());
    }catch (Exception e){log.warn("MaxDeliveryLeadTimeValidator exception: "+e.getLocalizedMessage());}

    return validResult();
  }
}
