package com.bat.petra.commons.domain.orderitem.validation.validator;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationResult;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidator;
import org.apache.commons.lang3.StringUtils;

import java.util.function.Predicate;
import java.util.stream.Stream;

/**
 * @author arkadiusz.wronski, created on 2019-06-17.
 */
public class MandatoryFieldsValidator implements OrderItemValidator {
  private static Predicate<OrderItem> HAS_EMPTY_MANDATORY_FIELDS = item ->
      Stream.of(item.getSapCustomerId(),item.getProductInternalId())
          .anyMatch(StringUtils::isEmpty);
  @Override
  public OrderItemValidationResult validateOrderItem(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    if(isMissingRequiredFields(orderItem)){
      return OrderItemValidationResult.withError("All Mandatory fields must be populated");
    }
    return validResult();
  }

  private boolean isMissingRequiredFields(OrderItem orderItem){
    return HAS_EMPTY_MANDATORY_FIELDS.test(orderItem);
  }
}
