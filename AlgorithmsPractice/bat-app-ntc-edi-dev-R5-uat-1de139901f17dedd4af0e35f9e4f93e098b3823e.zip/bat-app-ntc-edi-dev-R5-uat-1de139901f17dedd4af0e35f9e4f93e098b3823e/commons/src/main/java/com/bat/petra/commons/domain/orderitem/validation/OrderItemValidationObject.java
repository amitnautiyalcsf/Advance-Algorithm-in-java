package com.bat.petra.commons.domain.orderitem.validation;

/**
 * @author arkadiusz.wronski, created on 2019-06-14.
 */
public enum OrderItemValidationObject {
  MAIN_ACCOUNT,
  SHIP_TO_ACCOUNT,
  SAP_CUSTOMER_ID,
  SHIP_TO_SAP_CUSTOMER_ID,
  ACCOUNT_SF_ID,
  JOB_ID,
  BASE_DELIVERY_LEAD_TIME,
  PREFERRED_DELIVERY_DAY,
  LOCATION_HIERARCHY,
  PRODUCT,
  ORDER_ITEM_LIST,
  HEROKU_EXTERNAL_ID,
  ORDER_STATUS,
  ORDER_PROCESSING_DATE
}
