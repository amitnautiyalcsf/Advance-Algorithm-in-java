package com.bat.petra.commons.domain.orderline;

import com.bat.petra.commons.domain.model.OrderLineItem;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderLineItemRepo extends JpaRepository<OrderLineItem,Long> {
}
