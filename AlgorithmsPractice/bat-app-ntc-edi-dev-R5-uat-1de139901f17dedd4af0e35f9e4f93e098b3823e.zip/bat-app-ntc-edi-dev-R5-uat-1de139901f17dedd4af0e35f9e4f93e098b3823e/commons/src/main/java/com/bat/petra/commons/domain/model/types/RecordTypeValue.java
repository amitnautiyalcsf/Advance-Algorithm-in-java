package com.bat.petra.commons.domain.model.types;

/**
 * @author arkadiusz.wronski, created on 2019-02-11.
 */
public enum RecordTypeValue {
  EDI("Bulk Order Azure Blob Store Configuration"),
  TRADE_SKU("Trade SKU");

  private String typeName;

  RecordTypeValue(String typeName){this.typeName = typeName;}

  public String getTypeName() {
    return typeName;
  }
}
