package com.bat.petra.commons.domain.order.validation.validator;

import com.bat.petra.commons.domain.order.repository.AccountRepository;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.model.Account;
import com.bat.petra.commons.domain.order.validation.OrderValidator;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import lombok.extern.log4j.Log4j2;

import java.util.Map;
import java.util.Optional;

import static com.bat.petra.commons.domain.order.validation.OrderValidationResult.withError;

/**
 * @author arkadiusz.wronski, created on 2019-06-13.
 */
@Log4j2
public class AccountValidator implements OrderValidator {
  private AccountRepository accountRepository;

  public AccountValidator(AccountRepository accountRepository){
    this.accountRepository = accountRepository;
  }

  @Override
  public OrderValidationResult validateOrder(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    try {
      String customerSapId = context.getValidationParams().get(OrderItemValidationObject.SAP_CUSTOMER_ID.name()).toString();
      Optional<Account> dbAccount = accountRepository.findBySapCustomerId(customerSapId);

      if (!dbAccount.isPresent()) {
        return withError("Account with customer Code " + orderItem.getSapCustomerId() + " does not exist.");
      }
      Account account = dbAccount.get();
      if (account.isBlockedToSales()) {
        return withError("The account is blocked for sales");
      }
      initAdditionalContextParams(account, context.getValidationParams());
    }catch (NullPointerException e){
      throw new OrderItemValidationException("Has not found validation param with name "+ OrderItemValidationObject.SAP_CUSTOMER_ID.name()
          +"\n"+e.getLocalizedMessage());
    }catch (Exception ex){
      throw new OrderItemValidationException(ex.getLocalizedMessage());
    }
    return OrderValidationResult.builder().valid(true).build();
  }

  private void initAdditionalContextParams(Account account, Map<String, Object> validationParams) {
    validationParams.put(OrderItemValidationObject.MAIN_ACCOUNT.name(), account);
    validationParams.put(OrderItemValidationObject.ACCOUNT_SF_ID.name(),account.getSfId());
    validationParams.put(OrderItemValidationObject.PREFERRED_DELIVERY_DAY.name(),account.getPreferredDeliveryDay());
    validationParams.put(OrderItemValidationObject.BASE_DELIVERY_LEAD_TIME.name(),account.getBaseDeliveryLeadTime());
    validationParams.put(OrderItemValidationObject.LOCATION_HIERARCHY.name(),account.getLocationHierarchy());
  }


}
