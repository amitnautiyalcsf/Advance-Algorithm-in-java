package com.bat.petra.commons.domain.orderitem.validation.validator;

import com.bat.petra.commons.domain.model.types.RecordTypeValue;
import com.bat.petra.commons.domain.orderitem.repository.ProductRepo;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationResult;
import com.bat.petra.commons.domain.model.Product;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidator;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

/**
 * @author arkadiusz.wronski, created on 2019-06-17.
 */
public class ProductInternalIdValidator implements OrderItemValidator {
  private ProductRepo productRepo;

  public ProductInternalIdValidator(ProductRepo productRepo){
    this.productRepo = productRepo;
  }

  @Override
  public OrderItemValidationResult validateOrderItem(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    List<Product> products =
        productRepo.findByInternalIdAndMarketISOAndActiveAndRecordTypeName(new BigInteger(orderItem.getProductInternalId()),
            orderItem.getAccountMarketISO(), "Yes", RecordTypeValue.TRADE_SKU.getTypeName());

    if (products.isEmpty()) {
      return OrderItemValidationResult.withError("Product " + orderItem.getProductInternalId() + " is not found, " +
          "Product & and Account must have the same Market ISO, Product must be defined as \"Active\" and be of type " + RecordTypeValue.TRADE_SKU.getTypeName());
    }
    initContextProductParam(products.get(0),orderItem, context.getValidationParams());
    return validResult();
  }

  private void initContextProductParam(Product product, OrderItem orderItem, Map<String, Object> validationParams) {
    validationParams.put(OrderItemValidationObject.PRODUCT.name()+"_"+orderItem.getProductInternalId(),product);
  }

}
