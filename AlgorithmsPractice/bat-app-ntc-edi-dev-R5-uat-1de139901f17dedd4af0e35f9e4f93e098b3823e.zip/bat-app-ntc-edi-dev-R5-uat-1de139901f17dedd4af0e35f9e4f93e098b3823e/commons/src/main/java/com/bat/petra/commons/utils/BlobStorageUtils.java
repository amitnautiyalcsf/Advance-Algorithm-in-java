package com.bat.petra.commons.utils;

import com.bat.petra.commons.domain.model.BulkOrderUploadStatus;
import com.microsoft.azure.storage.CloudStorageAccount;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlob;
import com.microsoft.azure.storage.blob.CloudBlobClient;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import com.microsoft.azure.storage.blob.CloudBlockBlob;
import com.microsoft.azure.storage.blob.ListBlobItem;
import org.apache.commons.lang3.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.security.InvalidKeyException;
import java.util.ArrayList;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-02-27.
 */
public class BlobStorageUtils {

  public static CloudBlob getAzureBlob(String connectionString, String containerName, String blobName)
      throws StorageException, URISyntaxException, InvalidKeyException {
    CloudBlobContainer blobContainer = getCloudBlobContainer(connectionString, containerName);
    return blobContainer.getBlockBlobReference(blobName);
  }

  public static CloudBlobContainer getCloudBlobContainer(String connectionString, String containerName) throws URISyntaxException, InvalidKeyException, StorageException {
    CloudStorageAccount account = CloudStorageAccount.parse(connectionString);
    if (account == null) {
      throw new IllegalStateException(" - Cloud Storage Account Configuration is missing");
    }
    CloudBlobClient blobClient = account.createCloudBlobClient();
    return blobClient.getContainerReference(containerName);
  }

  public static List<ListBlobItem> getBlobFileList(String connectionString, String containerName) throws URISyntaxException, InvalidKeyException, StorageException {
    List<ListBlobItem> files = new ArrayList<>();
    CloudBlobContainer blobContainer = getCloudBlobContainer(connectionString, containerName);
    blobContainer.listBlobs()
        .forEach(listBlobItem -> {
          if (listBlobItem instanceof CloudBlockBlob) {
            files.add(listBlobItem);
          }
        });
    return files;
  }

  public static void uploadBlob(ByteArrayOutputStream file, String  connectionString, String fileName, String containerName)
      throws StorageException, URISyntaxException, InvalidKeyException, IOException {
    CloudBlob blob = getAzureBlob(connectionString,containerName,fileName);
    blob.uploadFromByteArray(file.toByteArray(), 0, file.size());
  }

  public static InputStream getCloudBlobInputStream(String connectionString, BulkOrderUploadStatus azureFileConfig)
      throws StorageException, URISyntaxException, InvalidKeyException {
    String blobName = getBlobName(azureFileConfig);
    return getAzureBlob(connectionString, azureFileConfig.getContainerName(), blobName).openInputStream();
  }

  private static String getBlobName(BulkOrderUploadStatus azureFileConfig) {
    return StringUtils.isEmpty(azureFileConfig.getFilePath()) ? azureFileConfig.getFileName() : azureFileConfig.getFilePath();
  }

}
