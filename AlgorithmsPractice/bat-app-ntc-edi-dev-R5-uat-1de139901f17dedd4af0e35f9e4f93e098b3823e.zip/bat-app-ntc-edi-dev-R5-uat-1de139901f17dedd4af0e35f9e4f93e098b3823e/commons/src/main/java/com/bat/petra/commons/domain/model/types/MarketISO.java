package com.bat.petra.commons.domain.model.types;

/**
 * @author arkadiusz.wronski, created on 2019-06-27.
 */
public enum MarketISO {
  BR("BR"),
  SA("ZA");

  private String value;

  MarketISO(String value){
    this.value = value;
  }

  public String getValue(){
    return this.value;
  }

}
