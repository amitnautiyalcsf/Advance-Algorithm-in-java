package com.bat.petra.commons.domain.order.repository;

import com.bat.petra.commons.domain.model.Account;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-02-19.
 */
@Repository
public interface AccountRepository extends CrudRepository<Account, Long> {
  Optional<Account> findBySapCustomerId(String sapCustomerId);
  Optional<Account> findByGlnNumber(String glnNumber);
}
