package com.bat.petra.commons.domain.orderitem.repository;

import com.bat.petra.commons.domain.model.ProductUOM;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-07-01.
 */
public interface ProductUOMRepo extends JpaRepository<ProductUOM, Long> {
  Optional<ProductUOM> findByBarCode(String barCode);
}
