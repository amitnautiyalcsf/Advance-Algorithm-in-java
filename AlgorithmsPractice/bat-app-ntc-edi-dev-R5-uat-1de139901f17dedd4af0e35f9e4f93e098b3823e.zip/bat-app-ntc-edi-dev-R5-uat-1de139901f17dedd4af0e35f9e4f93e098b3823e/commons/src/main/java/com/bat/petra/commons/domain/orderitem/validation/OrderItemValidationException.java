package com.bat.petra.commons.domain.orderitem.validation;

/**
 * @author arkadiusz.wronski, created on 2019-06-14.
 */
public class OrderItemValidationException extends Exception {
  public OrderItemValidationException(String message){
    super(message);
  }
}
