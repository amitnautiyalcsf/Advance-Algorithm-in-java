package com.bat.petra.commons.domain.config;

import com.bat.petra.commons.domain.model.BulkOrderUploadStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-02-27.
 */
@Repository
public interface BulkOrderUploadStatusRepo extends JpaRepository<BulkOrderUploadStatus, Long> {

  @Query(value = "select b.id , b.name , b.sfid, b.container__c, b.file_name__c, b.file_path__c, b.file_type__c , " +
      " b.ownerid , b.status__c, b.type__c, b.uploaded_url__c, b.createddate, b.error_file__c " +
      " from salesforce.bulk_order_upload_status__c b where (b.type__c = ?1 or b.type__c is null) and b.status__c = ?2 limit 1 for update of b",
  nativeQuery = true)
  BulkOrderUploadStatus findFirstByTypeAndStatus(String type, String status);
  @Query(value = "select b from BulkOrderUploadStatus b where (b.type = ?1 or b.type is null) and b.status = ?2")
  List<BulkOrderUploadStatus> finaAllByTypeAndStatus(String type, String status);
}
