package com.bat.petra.commons.domain.model;

import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.time.LocalDateTime;

/**
 * @author arkadiusz.wronski, created on 2019-02-27.
 */
@Entity
@Table(name = "bulk_order_upload_status__c", schema = "salesforce")
@Data
@ToString(callSuper = false)
public class BulkOrderUploadStatus extends IvyEntity {
  @Column(name = "uploaded_url__c")
  private String uploadedUrl;
  @Column (name = "file_name__c")
  private String fileName;
  @Column (name = "container__c")
  private String containerName;
  @Column (name = "file_path__c")
  private String filePath;
  @Column (name = "status__c")
  private String status;
  @Column (name = "file_type__c")
  private String fileType;
  @Column (name = "type__c")
  private String type;
  @Column(name = "ownerid", length = 18)
  private String ownerId;
  @Column(name = "createddate")
  private LocalDateTime createdDate;
  @Column(name = "error_file__c")
  private String errorFile;
  @Column(name = "designated_user__c")
  private String designatedUser;

}
