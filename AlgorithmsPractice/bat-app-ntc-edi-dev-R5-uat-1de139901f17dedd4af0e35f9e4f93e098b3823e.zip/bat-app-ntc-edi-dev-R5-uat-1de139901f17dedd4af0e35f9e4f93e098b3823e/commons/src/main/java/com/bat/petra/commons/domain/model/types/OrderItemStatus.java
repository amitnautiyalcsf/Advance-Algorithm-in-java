package com.bat.petra.commons.domain.model.types;

/**
 * @author arkadiusz.wronski, created on 2019-03-14.
 */
public enum OrderItemStatus {
  COMPLETED("Completed"),
  ONHOLD("On-hold"),
  ERROR("Contains errors");

  private String status;

  OrderItemStatus(String status){
    this.status = status;
  }

  public String getStatusName(){
    return this.status;
  }
}
