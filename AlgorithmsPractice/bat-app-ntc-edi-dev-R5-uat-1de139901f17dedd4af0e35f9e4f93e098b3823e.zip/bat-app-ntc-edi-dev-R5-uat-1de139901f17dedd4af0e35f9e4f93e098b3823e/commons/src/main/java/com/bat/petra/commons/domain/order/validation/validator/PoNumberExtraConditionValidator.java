package com.bat.petra.commons.domain.order.validation.validator;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.model.Order;
import com.bat.petra.commons.domain.order.service.OrderFacade;
import com.bat.petra.commons.utils.OrderItemUtils;
import com.bat.petra.commons.domain.order.validation.OrderValidator;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import org.apache.commons.lang3.StringUtils;

import java.util.List;

import static com.bat.petra.commons.domain.order.validation.OrderValidationResult.withError;

/**
 * @author arkadiusz.wronski, created on 2019-06-14.
 */
public class PoNumberExtraConditionValidator implements OrderValidator {
  private OrderFacade orderFacade;

  public PoNumberExtraConditionValidator(OrderFacade orderFacade){
    this.orderFacade = orderFacade;
  }
  @Override
  public OrderValidationResult validateOrder(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    List<OrderItem> orderItems = (List<OrderItem>)context.getValidationParams().get(OrderItemValidationObject.ORDER_ITEM_LIST.name());
    String sapCustomerId = context.getValidationParams().get(OrderItemValidationObject.SAP_CUSTOMER_ID.name()).toString();

    if(orderItem.hasPoNumber()) {
      //if grouped by poNumber must check if all dates are the same
      if (OrderItemUtils.ifAnyDateDifferent(orderItems)) {
        return withError("Multiple Delivery Dates under the same PO number.");
      }
      List<Order> orders = orderFacade.findOrderForSapIdByPoNumber(orderItem.getPoNumber(), sapCustomerId);
      if (!orders.isEmpty()) {
        return withError("Po number " + orderItem.getPoNumber()+" already exists.");
      }
    }

    return validResult();
  }
}
