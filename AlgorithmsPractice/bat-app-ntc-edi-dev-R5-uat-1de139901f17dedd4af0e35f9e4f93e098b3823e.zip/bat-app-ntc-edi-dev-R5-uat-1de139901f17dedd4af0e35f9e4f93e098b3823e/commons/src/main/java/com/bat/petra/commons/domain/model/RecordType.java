package com.bat.petra.commons.domain.model;

import com.bat.petra.commons.domain.model.EndMarketConfiguration;
import com.bat.petra.commons.domain.model.IvyEntity;
import com.bat.petra.commons.domain.model.Product;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-02-13.
 */
@Entity
@Table (name = "recordtype", schema = "salesforce")
@Data
@NoArgsConstructor
public class RecordType extends IvyEntity {
  @Column(name = "developername", length = 80)
  private String developerName;
  @OneToMany (mappedBy = "recordType", fetch = FetchType.EAGER)
  private List<EndMarketConfiguration> endMarketConfiguration;

  @OneToMany(mappedBy = "recordType")
  private List<Product> products;

  @Override
  public String toString() {
    return "RecordType{" +
        "developerName='" + developerName + '\'' +
        '}';
  }
}
