package com.bat.petra.commons.domain.config;

import com.bat.petra.commons.domain.model.EndMarketConfiguration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-02-11.
 */
@Repository
public interface EndMarketConfigurationRepo extends JpaRepository<EndMarketConfiguration,Long> {
  List<EndMarketConfiguration> findByRecordTypeNameAndActiveAndMarketISO(String recordTypeName, boolean active,String marketISO);
  List<EndMarketConfiguration> findAllByGlobalAndActiveAndRecordTypeName(boolean global, boolean active, String recordTypeName);

}
