package com.bat.petra.commons.domain.model.types;

/**
 * @author arkadiusz.wronski, created on 2019-02-11.
 */
public enum AzureFileStatus {
  UPLOADED("Uploaded"),
  PROCESSING("In Processing"),
  FINISHED("Finished"),
  FAILED("Finished with errors"),
  REMOVED("Released");
  private String statusName;
  AzureFileStatus(String statusName){this.statusName = statusName;}
  public String getStatusName(){return statusName;}
}
