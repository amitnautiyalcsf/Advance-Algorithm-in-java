package com.bat.petra.commons.domain.orderitem.validation;

import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.order.validation.OrderValidator;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author arkadiusz.wronski, created on 2019-02-19.
 */
@Service
@RequiredArgsConstructor
public class OrderItemValidationService {
  private static final Logger LOGGER = LoggerFactory.getLogger(OrderItemValidationService.class);
  private final ValidatorsFactory validatorsFactory;

  public OrderValidationResult validateOrderByOrderItem(List<OrderItem> orderItems) {
    OrderItem item = orderItems.get(0);
    String jobId = item.getJobId();

    Map<String, Object> validationParams = initOrderValidationParams(orderItems, jobId);
    OrderItemValidationContext context = new OrderItemValidationContext();
    context.getValidationParams().putAll(validationParams);

    List<OrderValidator> validators = validatorsFactory.getOrderValidators();
    for (OrderValidator validator : validators) {
      try {
        OrderValidationResult result = validator.validateOrder(item, context);
        if (!result.isValid() || result.isExists()) {
          result.setContext(context);
          return result;
        }
      } catch (OrderItemValidationException ex) {
        ex.printStackTrace();
        return OrderValidationResult.withError(ex.getLocalizedMessage());
      }
    }
    item.setHerokuExternalId(UUID.randomUUID().toString());
    setSoldToAndShipTo(orderItems);
    context.validationParams.put(OrderItemValidationObject.HEROKU_EXTERNAL_ID.name(),item.getHerokuExternalId());
    LOGGER.info("Order " + item.getHerokuExternalId() + " validated successfully." + item.getJobId());
    return OrderValidationResult.builder()
        .exists(true)
        .needsUpdate(true)
        .context(context)
        .order(item)
        .valid(true)
        .build();
  }

  private void setSoldToAndShipTo(List<OrderItem> orderItems) {
    orderItems.subList(1, orderItems.size()).forEach(
        i -> i.setSapCustomerId(orderItems.get(0).getSapCustomerId()));
  }

  private Map<String, Object> initOrderValidationParams(List<OrderItem> orderItems, String jobId) {
    Map<String, Object> validationParams = new HashMap<>();
    validationParams.put(OrderItemValidationObject.ORDER_ITEM_LIST.name(), orderItems);
    validationParams.put(OrderItemValidationObject.JOB_ID.name(), jobId);
    validationParams.put(OrderItemValidationObject.ORDER_PROCESSING_DATE.name(), LocalDate.now());
    if(orderItems.get(0).hasSapCustomerId()) {
      validationParams.put(OrderItemValidationObject.SAP_CUSTOMER_ID.name(), orderItems.get(0).getSapCustomerId());
    }
    return validationParams;
  }

  public OrderItemValidationResult validateOrderItem(OrderItem item, OrderItemValidationContext context) {
    if (item.hasNotBeenValidated()) {
      List<OrderItemValidator> orderItemValidators = validatorsFactory.getOrderItemValidators();
      for (OrderItemValidator validator : orderItemValidators) {
        try {
          OrderItemValidationResult result = validator.validateOrderItem(item, context);
          if (!result.isValid()) {
            result.setContext(context);
            return result;
          }
        } catch (OrderItemValidationException ex) {
          ex.printStackTrace();
          return OrderItemValidationResult.withError(ex.getLocalizedMessage());
        }
      }
      return OrderItemValidationResult.builder()
          .valid(true)
          .orderLineItem(item)
          .context(context)
          .build();
    } else {
      OrderItemValidationResult result = OrderItemValidationResult.withError(item.getErrorMsg());
      result.setContext(context);
      return result;
    }
  }

}
