package com.bat.petra.commons.domain.order.repository;

import com.bat.petra.commons.domain.model.HHModuleMaster;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-05-24.
 */
public interface HHModuleMasterRepo extends JpaRepository<HHModuleMaster,Long> {
  Optional<HHModuleMaster> findByNameAndResourceTypeTypeAndLocationHierarchy(String name, String resourceType, String locationHierarchy);
}
