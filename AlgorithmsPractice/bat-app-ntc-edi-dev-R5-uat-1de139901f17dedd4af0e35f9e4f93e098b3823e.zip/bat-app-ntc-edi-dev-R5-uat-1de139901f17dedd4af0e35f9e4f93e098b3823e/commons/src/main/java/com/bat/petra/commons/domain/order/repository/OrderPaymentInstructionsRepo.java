package com.bat.petra.commons.domain.order.repository;

import com.bat.petra.commons.domain.model.OrderPaymentInstructions;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-05-29.
 */
@Repository
public interface OrderPaymentInstructionsRepo extends JpaRepository<OrderPaymentInstructions,Long> {
  Optional<OrderPaymentInstructions> findByOrderHerokuExternalId(String orderHerokuExternalId);
}
