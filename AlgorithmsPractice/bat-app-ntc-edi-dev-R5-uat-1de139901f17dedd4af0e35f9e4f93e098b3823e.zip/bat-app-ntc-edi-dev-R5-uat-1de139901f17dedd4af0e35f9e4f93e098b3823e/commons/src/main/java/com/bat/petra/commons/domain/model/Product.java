package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.math.BigInteger;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-02-12.
 */
@Entity
@Table(name = "ivybase__Product__c", schema = "salesforce")
@Data
public class Product extends IvyEntity {

  @Column(name = "Name")
  private String name;
  @Column(name = "ivybase__internalid__c")
  private BigInteger internalId;
  @Column(name = "ivybase__active__c")
  private String active;
  @Column(name = "ivybat__market_iso__c", length = 2)
  private String marketISO;

  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "recordtypeid", referencedColumnName = "sfid")
  private RecordType recordType;

  @OneToMany(mappedBy = "product", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
  private List<OrderLineItem> orderLineItemList;

  @OneToMany(mappedBy = "manufacturingSKU", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
  private List<OrderLineItem> orderLineItemListByManufacturingSKU;

  @Override
  public String toString() {
    return "Product{" +
        "name='" + name + '\'' +
        ", internalId='" + internalId + '\'' +
        '}';
  }
}
