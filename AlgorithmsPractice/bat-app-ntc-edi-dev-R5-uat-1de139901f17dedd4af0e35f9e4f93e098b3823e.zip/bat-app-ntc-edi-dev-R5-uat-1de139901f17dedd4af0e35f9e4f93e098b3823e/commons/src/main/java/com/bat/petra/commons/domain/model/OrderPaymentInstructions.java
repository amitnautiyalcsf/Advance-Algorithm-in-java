package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author arkadiusz.wronski, created on 2019-05-28.
 */
@Data
@Entity
@Table(name = "order_payment_instructions__c", schema = "salesforce")
public class OrderPaymentInstructions extends OrderPaymentInstructionsBase{
  @Column(name = "order__r__herokuexternalid__c")
  private String orderHerokuExternalId;

}
