package com.bat.petra.commons.domain.model.types;

public enum OrderType {
  EDI(null),
  FOC("FOC"),
  TPO("TPO");

  private String typeName;

  OrderType(String typeName) {
    this.typeName = typeName;
  }

  public String getTypeName() {
    return typeName;
  }
}
