package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.math.BigInteger;
import java.time.LocalDate;

/**
 * @author arkadiusz.wronski, created on 2019-05-29.
 */
@Data
@MappedSuperclass
public class OrderPaymentInstructionsBase  extends IvyEntity {
  @Column(name = "credit_days__c")
  private BigInteger creditDays;
  @Column(name = "payment_mode__c")
  private String paymentMode;
  @Column(name = "due_date__c ")
  private LocalDate dueDate;
  @Column(name = "payment_instruction_date__c ")
  private LocalDate paymentInstructionDate;
  @Column(name = "split_percentage__c")
  private BigInteger splitPercentage;
}
