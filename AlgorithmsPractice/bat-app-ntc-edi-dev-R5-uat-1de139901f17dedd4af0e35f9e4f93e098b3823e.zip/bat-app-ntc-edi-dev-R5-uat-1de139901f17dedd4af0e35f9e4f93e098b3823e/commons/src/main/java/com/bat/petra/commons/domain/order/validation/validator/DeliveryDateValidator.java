package com.bat.petra.commons.domain.order.validation.validator;

import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.order.validation.OrderValidator;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.utils.DateUtils;
import com.bat.petra.commons.utils.OrderItemUtils;

import java.math.BigInteger;
import java.time.LocalDate;

import static com.bat.petra.commons.domain.order.validation.OrderValidationResult.withError;
import static com.bat.petra.commons.utils.DateUtils.LOCAL_DATE_FORMATTER;

/**
 * @author arkadiusz.wronski, created on 2019-06-14.
 */
public class DeliveryDateValidator implements OrderValidator {
  @Override
  public OrderValidationResult validateOrder(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    BigInteger baseDeliveryLeadTime = (BigInteger) getParamOrThrow(context, OrderItemValidationObject.BASE_DELIVERY_LEAD_TIME.name());
    String preferredDeliveryDay = (String) getParamOrThrow(context, OrderItemValidationObject.PREFERRED_DELIVERY_DAY.name());
    LocalDate orderProcessingDate = (LocalDate) getParamOrThrow(context, OrderItemValidationObject.ORDER_PROCESSING_DATE.name());
    try {
      if (orderItem.hasDeliveryDate()) {
        if (!DateUtils.parseDate(orderItem.getDeliveryDate()).isPresent()) {
          return withError("Delivery date must be in " + DateUtils.getDateFormat() + " format");
        }
        if (deliveryDateLessThanDeliveryLeadTime(orderItem, orderProcessingDate, baseDeliveryLeadTime.longValue())) {
          return withError("Delivery Date is less than Delivery Lead Time");
        }
      } else {
        orderItem.setDeliveryDate(
            DateUtils.formatDate(OrderItemUtils.calculateDeliveryDate(orderProcessingDate,
                baseDeliveryLeadTime.doubleValue(), preferredDeliveryDay)));
      }
    } catch (Exception e) {
      throw new OrderItemValidationException(e.getLocalizedMessage());
    }
    return validResult();
  }

  private Object getParamOrThrow(OrderItemValidationContext context, String paramName) throws OrderItemValidationException {
    if (context == null || context.getValidationParams() == null) {
      throw new OrderItemValidationException("OrderItemValidationContext params not found!");
    }
    Object param = context.getValidationParams().get(paramName);
    if (param == null) {
      throw new OrderItemValidationException("Has not found validation param with name " + paramName);
    }
    return param;
  }

  private boolean deliveryDateLessThanDeliveryLeadTime(OrderItem item, LocalDate orderProcessingDate, long baseDeliveryLeadTime) {
    return DateUtils.parseLocalDate(item.getDeliveryDate())
        .isBefore(orderProcessingDate.plusDays(baseDeliveryLeadTime));
  }


}
