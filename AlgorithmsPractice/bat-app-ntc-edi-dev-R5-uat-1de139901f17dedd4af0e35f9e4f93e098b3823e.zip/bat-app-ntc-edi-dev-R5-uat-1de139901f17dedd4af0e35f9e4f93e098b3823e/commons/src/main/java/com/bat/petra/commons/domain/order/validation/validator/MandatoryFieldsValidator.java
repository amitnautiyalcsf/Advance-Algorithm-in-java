package com.bat.petra.commons.domain.order.validation.validator;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.order.validation.OrderValidator;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import org.apache.commons.lang3.StringUtils;

import java.util.function.Predicate;
import java.util.stream.Stream;

import static com.bat.petra.commons.domain.order.validation.OrderValidationResult.withError;

/**
 * @author arkadiusz.wronski, created on 2019-06-14.
 */
public class MandatoryFieldsValidator implements OrderValidator {
  private static Predicate<OrderItem> HAS_EMPTY_MANDATORY_FIELDS = item ->
      Stream.of(item.getSapCustomerId(),item.getProductInternalId())
          .anyMatch(StringUtils::isEmpty);

  @Override
  public OrderValidationResult validateOrder(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    if(isMissingRequiredFields(orderItem)){
      return withError("All Mandatory fields must be populated");
    }
    return validResult();
  }

  private boolean isMissingRequiredFields(OrderItem orderItem){
    return HAS_EMPTY_MANDATORY_FIELDS.test(orderItem);
  }
}
