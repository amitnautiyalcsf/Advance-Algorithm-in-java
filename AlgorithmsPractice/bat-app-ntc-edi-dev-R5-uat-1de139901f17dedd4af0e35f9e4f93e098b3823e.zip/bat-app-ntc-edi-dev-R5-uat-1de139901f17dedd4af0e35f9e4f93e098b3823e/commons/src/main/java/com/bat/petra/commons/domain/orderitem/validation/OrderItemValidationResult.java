package com.bat.petra.commons.domain.orderitem.validation;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderItemValidationResult {

  private boolean valid = true;

  private OrderItem orderLineItem;

  private OrderItemValidationContext context;

  private String errorDescription;

  public static OrderItemValidationResult withError(String errorDescription) {
    return OrderItemValidationResult.builder()
        .valid(false)
        .context(null)
        .errorDescription(errorDescription)
        .build();
  }

}
