package com.bat.petra.commons.utils;

import java.time.LocalDateTime;

/**
 * @author arkadiusz.wronski, created on 2019-06-25.
 */
public class FilenameUtils {
  public static String removeExtension(String filename, String extension) {
    if (filename.endsWith(extension))
      return filename.substring(0, filename.length() - extension.length());
    else
      return filename;
  }

  public static String convertToSafeWindowsName(String name) {
    return name.replaceAll("[\\s+:\\\\/*?|<>]", "_");
  }

  public static String getErrorFileName(String fileName, String extension){
    String startTime = LocalDateTime.now().withSecond(0).withNano(0).toString();
    return convertToSafeWindowsName(removeExtension(fileName, extension) + "-" + startTime + extension);
  }
}
