package com.bat.petra.commons.domain.model;

import org.springframework.data.domain.Persistable;

import javax.persistence.*;

/**
 * @author arkadiusz.wronski, created on 2019-02-08.
 */
@MappedSuperclass
public abstract class PersistableEntity implements Persistable<Long> {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "ID")
  private Long id;

  @Override
  public Long getId() {
    return id;
  }

  public void setId(Long id) {
    this.id = id;
  }

  @Override
  public boolean isNew() {
    return this.id == null;
  }
}
