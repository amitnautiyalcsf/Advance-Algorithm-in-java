package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import java.io.Serializable;

/**
 * @author arkadiusz.wronski, created on 2019-02-13.
 */
@MappedSuperclass
@Data
public abstract class IvyEntity extends PersistableEntity implements Serializable {
  @Column
  private String name;
  @Column(name = "sfid",length = 18)
  private String sfId;
}
