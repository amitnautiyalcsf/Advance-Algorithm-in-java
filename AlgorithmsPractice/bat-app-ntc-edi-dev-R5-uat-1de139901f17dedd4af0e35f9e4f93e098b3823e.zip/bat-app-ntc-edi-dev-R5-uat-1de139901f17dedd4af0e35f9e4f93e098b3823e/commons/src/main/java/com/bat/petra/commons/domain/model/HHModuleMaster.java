package com.bat.petra.commons.domain.model;

import com.bat.petra.commons.domain.model.IvyEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author arkadiusz.wronski, created on 2019-05-24.
 */
@Entity
@Table(name = "ivybase__HHTModule_Master__c", schema = "salesforce")
@Data
public class HHModuleMaster extends IvyEntity {
  @Column(name = "ivybase__rfield__c")
  private Integer maxDeliveryLeadTime;
  @ManyToOne
  @JoinColumn(name = "ivybase__resource_type__c", referencedColumnName = "sfid")
  private ResourceType resourceType;
  @Column(name = "ivybase__location_hierarchy__c", length = 18)
  private String locationHierarchy;
}
