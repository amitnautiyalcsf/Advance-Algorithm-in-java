package com.bat.petra.commons.domain.orderitem.validation.validator;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationResult;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidator;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * @author arkadiusz.wronski, created on 2019-06-17.
 */
public class PriceValidator implements OrderItemValidator {
  @Override
  public OrderItemValidationResult validateOrderItem(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    String uomLow = orderItem.getSalesUomLow();
    String uomHigh = orderItem.getSalesUomHigh();
    List<String> values = Stream.of(uomHigh,uomLow).filter(StringUtils::isNotEmpty)
        .filter(value -> !"0".equals(value.trim()))
        .collect(Collectors.toList());
    if(values.isEmpty()){
      return OrderItemValidationResult.withError("Both High & Low UOM cannot be blank or 0.");
    }
    boolean noDecimals = values.stream()
        .filter(value -> value.contains(".")).collect(Collectors.toList()).isEmpty();
    if(!noDecimals){
      return OrderItemValidationResult.withError("UOM's cannot contain decimal places.");
    }
    try {
      boolean noNegative = values.stream()
          .filter(value -> Integer.valueOf(value.trim()) < 0)
          .collect(Collectors.toList()).isEmpty();
      if(!noNegative){
        return OrderItemValidationResult.withError("Negative numbers cannot be populated.");
      }
    }catch (NumberFormatException ex){
      throw new OrderItemValidationException("Wrong UOM format "+ex.getLocalizedMessage());
    }
    return validResult();
  }

}
