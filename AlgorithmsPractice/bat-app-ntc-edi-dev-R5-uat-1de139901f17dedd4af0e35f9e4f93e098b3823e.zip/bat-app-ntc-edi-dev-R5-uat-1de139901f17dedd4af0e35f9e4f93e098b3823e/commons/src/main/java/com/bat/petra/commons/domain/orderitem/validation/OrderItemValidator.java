package com.bat.petra.commons.domain.orderitem.validation;

import com.bat.petra.commons.domain.orderitem.OrderItem;

/**
 * @author arkadiusz.wronski, created on 2019-06-17.
 */
public interface OrderItemValidator {
  OrderItemValidationResult validateOrderItem(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException;
  default OrderItemValidationResult validResult(){ return OrderItemValidationResult.builder().valid(true).build();  }
}
