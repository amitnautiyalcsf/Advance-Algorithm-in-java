package com.bat.petra.commons.domain.orderitem.repository;

import com.bat.petra.commons.domain.model.CreditDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-06-03.
 */
@Repository
public interface CreditDetailsRepo extends JpaRepository<CreditDetails, Long> {
  Optional<CreditDetails> findFirstByAccountSfIdOrderByCreatedDateDesc(String accountSfId);
}
