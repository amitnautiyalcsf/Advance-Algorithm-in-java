package com.bat.petra.commons.domain.orderitem.validation;

import lombok.Getter;

import java.util.HashMap;
import java.util.Map;

/**
 * @author arkadiusz.wronski, created on 2019-06-14.
 */
@Getter
public class OrderItemValidationContext {
  Map<String,Object> validationParams = new HashMap<>();

}
