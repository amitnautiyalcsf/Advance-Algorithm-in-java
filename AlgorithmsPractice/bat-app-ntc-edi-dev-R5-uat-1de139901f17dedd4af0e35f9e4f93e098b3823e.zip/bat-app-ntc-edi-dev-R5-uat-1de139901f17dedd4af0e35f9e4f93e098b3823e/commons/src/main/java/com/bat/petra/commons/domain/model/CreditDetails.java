package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigInteger;
import java.time.LocalDateTime;

/**
 * @author arkadiusz.wronski, created on 2019-06-03.
 */
@Entity
@Table(name = "ivybat__credit_details__c", schema = "salesforce")
@Data
public class CreditDetails extends IvyEntity {
  @Column(name = "base_credit_days__c")
  private BigInteger baseCreditDays;
  @Column(name = "createddate")
  private LocalDateTime createdDate;
  @Column(name = "ivybat__account__c", length = 18)
  private String accountSfId;
}
