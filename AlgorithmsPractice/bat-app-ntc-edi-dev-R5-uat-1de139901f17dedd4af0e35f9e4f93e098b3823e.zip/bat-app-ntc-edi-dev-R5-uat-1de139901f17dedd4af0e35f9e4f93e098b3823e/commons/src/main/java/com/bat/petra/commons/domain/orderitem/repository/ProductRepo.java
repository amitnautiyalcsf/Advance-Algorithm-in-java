package com.bat.petra.commons.domain.orderitem.repository;

import com.bat.petra.commons.domain.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-04-05.
 */
@Repository
public interface ProductRepo extends JpaRepository<Product, Long> {
  List<Product> findByInternalIdAndMarketISOAndActiveAndRecordTypeName(BigInteger internalId, String marketISO, String active, String recordTypeName);
}
