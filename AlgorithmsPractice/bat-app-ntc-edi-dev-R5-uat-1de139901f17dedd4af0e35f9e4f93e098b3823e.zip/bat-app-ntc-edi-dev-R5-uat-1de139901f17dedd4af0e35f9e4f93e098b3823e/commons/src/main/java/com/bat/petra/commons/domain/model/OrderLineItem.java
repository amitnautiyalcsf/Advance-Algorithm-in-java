package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author arkadiusz.wronski, created on 2019-02-12.
 */
@Entity
@Table(name = "ivydsd__Order_Line_Item__c", schema = "salesforce")
@Data
public class OrderLineItem extends OrderLineBase {
  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "Manufacturing_SKU__c", referencedColumnName = "sfid")
  private Product manufacturingSKU;
}
