package com.bat.petra.commons.domain.orderitem.validation;

import com.bat.petra.commons.domain.orderitem.OrderItem;

import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-06-26.
 */
public interface OrderItemListValidator {
  List<? extends OrderItem> validateOrderItemList(List<? extends OrderItem> orderItemList);
}
