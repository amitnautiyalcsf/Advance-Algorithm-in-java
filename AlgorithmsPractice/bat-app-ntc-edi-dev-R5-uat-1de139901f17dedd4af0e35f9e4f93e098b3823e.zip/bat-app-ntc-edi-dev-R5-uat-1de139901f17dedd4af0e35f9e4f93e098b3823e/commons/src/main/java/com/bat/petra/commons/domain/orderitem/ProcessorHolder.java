package com.bat.petra.commons.domain.orderitem;

import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationResult;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

/**
 * @author arkadiusz.wronski, created on 2019-06-28.
 */
public class ProcessorHolder {

  @Getter
  public class ProcessingState {
    private Map<String, OrderValidationResult> orders = new HashMap<>();
    private Map<String,List<OrderItem>> orderLineItems = new HashMap<>();
    private List<? extends OrderItem> orderLineItemWithErrors = new ArrayList<>();
    // For Brazil use, map <externalId, status> stores orders that already exist and have to has status updated
    private Map<String, String> orderWithStatus = new HashMap<>();
  }

  @Getter
  @AllArgsConstructor
  public class ResultHolder {
    private List<OrderItem> orderItems;
    private Future<OrderValidationResult> orderValidationResultFuture;
  }

  @Getter
  @AllArgsConstructor
  public class OrderLineResultHolder {
    private OrderValidationResult orderValidationResult;
    private List<Future<OrderLineItemWithResult>> futures;
  }

  @Getter
  @AllArgsConstructor
  public class OrderLineItemWithResult {
    private OrderItemValidationResult orderItemValidationResult;
    private OrderItem orderItem;
  }

}
