package com.bat.petra.commons.domain.model;

import com.bat.petra.commons.domain.model.PersistableEntity;
import lombok.Data;

import javax.persistence.*;

/**
 * @author arkadiusz.wronski, created on 2019-02-11.
 */
@Entity
@Table(name = "End_Market_Configuration__c", schema = "salesforce")
@Data
public class EndMarketConfiguration extends PersistableEntity {
  @ManyToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "recordtypeid", referencedColumnName = "sfid")
  private RecordType recordType;
  @Column(name = "market_iso__c")
  private String marketISO;
  @Column(name = "blob_endpoint__c")
  private String blobEndpoint;
  @Column(name = "connection_string__c")
  private String connectionString;
  @Column(name = "container_name__c")
  private String containerName;
  @Column(name = "active__c")
  private boolean active;
  @Column(name = "isglobal__c")
  private boolean global;
  @Column(name = "designated_user__c")
  private String designatedUser;

  @Override
  public String toString() {
    return "EndMarketConfiguration{" +
        "recordTypeId=" + recordType +
        ", marketISO='" + marketISO + '\'' +
        ", blobEndpoint='" + blobEndpoint + '\'' +
        ", connectionString='" + connectionString + '\'' +
        ", containerName='" + containerName + '\'' +
        ", active=" + active +
        ", global=" + global +
        ", designatedUser=" + designatedUser +
        '}';
  }

}
