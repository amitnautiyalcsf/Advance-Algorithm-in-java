package com.bat.petra.commons.domain.orderitem.service;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;

/**
 * @author arkadiusz.wronski, created on 2019-03-18.
 */

public interface OrderItemMapper {
  <T extends OrderItem> T mapOrderItemToError(OrderItem orderLineItem, OrderItemValidationContext context);
}
