package com.bat.petra.commons.domain.order.repository;

import com.bat.petra.commons.domain.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OrderRepo extends JpaRepository<Order,Long> {
  List<Order> findByPurchaseOrderNumberAndStoreSapCustomerId(String poNo, String sapCustomerId);
}
