package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import java.time.LocalDate;

/**
 * @author arkadiusz.wronski, created on 2019-03-14.
 */
@MappedSuperclass
@Data
public class OrderBase extends IvyEntity {

  @Column(name = "herokuexternalid__c")
  private String herokuExternalId;
  @Column(name = "ivydsd__Purchase_Order_Number__c")
  private String purchaseOrderNumber;
  @Column(name = "ivydsd__Delivery_Date__c")
  private LocalDate deliveryDate;
  @Column(name="ivydsd__order_date__c")
  private LocalDate orderUploadDate;
  @Column(name = "ivydsd__Order_Type__c")
  private String orderType;
  @Column (name="ivydsd__order_status__c")
  private String status;
  @Column(name = "ownerid", length = 18)
  private String ownerId;
  @Column(name="market_iso__c")
  private String marketISO;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "ivydsd__store__c", referencedColumnName = "sfid")
  private Account store;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "payer__c  ", referencedColumnName = "sfid")
  private Account payer;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "bill_to__c  ", referencedColumnName = "sfid")
  private Account billTo;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "ship_to__c", referencedColumnName = "sfid")
  private Account shipTo;

  @Override
  public String toString() {
    return "OrderBase{" +
        "herokuExternalId='" + herokuExternalId + '\'' +
        ", purchaseOrderNumber='" + purchaseOrderNumber + '\'' +
        ", deliveryDate=" + deliveryDate +
        ", orderUploadDate=" + orderUploadDate +
        ", orderType='" + orderType + '\'' +
        ", status='" + status + '\'' +
        ", ownerId='" + ownerId + '\'' +
        ", marketISO='" + marketISO + '\'' +
        '}';
  }
}
