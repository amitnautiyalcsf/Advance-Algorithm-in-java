package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author arkadiusz.wronski, created on 2019-06-28.
 */
@Entity
@Table(name = "ivybase__Product_UOM__c", schema = "salesforce")
@Data
public class ProductUOM extends IvyEntity{
  @OneToOne(fetch = FetchType.EAGER)
  @JoinColumn(name = "ivybase__Product__c", referencedColumnName = "sfid")
  private Product product;
  @Column(name = "ivybase__Bar_Code__c")
  private String barCode;
}
