package com.bat.petra.commons.domain.orderitem.validation;

import com.bat.petra.commons.domain.order.validation.OrderValidator;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-06-25.
 */
@Component
public interface ValidatorsFactory {
  List<OrderItemValidator> getOrderItemValidators();
  List<OrderValidator> getOrderValidators();
  List<OrderItemListValidator> getOrderItemListValidators();
}
