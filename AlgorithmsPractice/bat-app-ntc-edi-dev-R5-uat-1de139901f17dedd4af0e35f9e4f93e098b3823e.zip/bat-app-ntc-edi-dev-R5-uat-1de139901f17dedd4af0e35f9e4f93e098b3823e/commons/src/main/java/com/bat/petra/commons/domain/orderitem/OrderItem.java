package com.bat.petra.commons.domain.orderitem;

import com.bat.petra.commons.utils.DateUtils;
import lombok.AccessLevel;
import lombok.Data;
import lombok.Setter;
import org.apache.commons.lang3.StringUtils;

import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;
import java.time.LocalDate;

/**
 * @author arkadiusz.wronski, created on 2019-02-07.
 */
@Data
@MappedSuperclass
public class OrderItem {
  @Setter(AccessLevel.NONE)
  private String sapCustomerId;
  private String deliveryDate = "";
  private String poNumber;
  private String productInternalId;
  private String salesUomHigh;
  private String salesUomLow;
  private String orderType;
  private String bulkOrderSfid;
  private String ownerId;
  private String herokuExternalId;
  private String jobId;
/*  @Transient
  private String status;*/
  @Transient
  private String accountMarketISO;
  @Transient
  @Setter(AccessLevel.NONE)
  private LocalDate orderUploadDate;
  @Transient
  private String errorMsg;

  public void setSapCustomerId(String sapCustomerId) {
    if(StringUtils.isNotEmpty(sapCustomerId) && sapCustomerId.length()<10){
      this.sapCustomerId = StringUtils.leftPad(sapCustomerId, 10,"0");
    } else {
      this.sapCustomerId = sapCustomerId;
    }
  }

  public void setOrderUploadDate(String orderUploadDate){
    DateUtils.parseDate(orderUploadDate).ifPresent( uploadDate -> this.orderUploadDate = uploadDate);}

  public void setOrderUploadDate(LocalDate orderUploadDate){this.orderUploadDate = orderUploadDate;}

  public boolean hasDeliveryDate(){
    return StringUtils.isNotEmpty(this.deliveryDate);
  }

  public boolean hasPoNumber(){
    return StringUtils.isNotEmpty(this.poNumber);
  }

  public boolean hasNotBeenValidated(){
    return StringUtils.isEmpty(this.errorMsg);
  }

  public boolean hasSapCustomerId() {return StringUtils.isNotEmpty(this.sapCustomerId);}
/*
  public boolean hasStatus() {return StringUtils.isNotEmpty(this.status);}*/
}
