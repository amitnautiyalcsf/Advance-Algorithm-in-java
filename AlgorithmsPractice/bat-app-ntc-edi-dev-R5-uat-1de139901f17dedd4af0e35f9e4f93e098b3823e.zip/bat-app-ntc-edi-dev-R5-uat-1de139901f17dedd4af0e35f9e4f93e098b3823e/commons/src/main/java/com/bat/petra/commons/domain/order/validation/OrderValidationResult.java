package com.bat.petra.commons.domain.order.validation;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OrderValidationResult {

  private boolean valid;

  private boolean exists;

  private boolean needsUpdate;

  private OrderItem order;

  private OrderItemValidationContext context;

  private String errorDescription;

  public static OrderValidationResult withError(String errorDescription) {
    return new OrderValidationResult(false, false, false, null, null, errorDescription);
  }

}
