package com.bat.petra.commons.domain.config;

import com.bat.petra.commons.domain.model.EndMarketConfiguration;
import com.bat.petra.commons.domain.model.types.MarketISO;
import com.bat.petra.commons.domain.model.types.RecordTypeValue;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-07-04.
 */
@Service
@RequiredArgsConstructor
public class EndMarketConfigurationService {
  private final EndMarketConfigurationRepo endMarketConfigurationRepo;

  public EndMarketConfiguration getActiveMarketConfig(String recordType, String marketISO) {
    List<EndMarketConfiguration> endpoint = endMarketConfigurationRepo
        .findByRecordTypeNameAndActiveAndMarketISO(recordType, true, marketISO);
    if (endpoint.isEmpty()) {
      throw new IllegalStateException("No active End Market Configuration for recordType " + recordType
      + " and marketISO "+ marketISO);
    }
    return endpoint.get(0);
  }

  public EndMarketConfiguration getGlobalActiveEndMarketConfig(String recordType){
    List<EndMarketConfiguration> marketConfigurations= endMarketConfigurationRepo
        .findAllByGlobalAndActiveAndRecordTypeName(true, true, recordType);
    if (marketConfigurations.isEmpty()) {
      throw new IllegalStateException("No active global End Market Configuration for "+ recordType);
    }
    return marketConfigurations.get(0);
  }


}
