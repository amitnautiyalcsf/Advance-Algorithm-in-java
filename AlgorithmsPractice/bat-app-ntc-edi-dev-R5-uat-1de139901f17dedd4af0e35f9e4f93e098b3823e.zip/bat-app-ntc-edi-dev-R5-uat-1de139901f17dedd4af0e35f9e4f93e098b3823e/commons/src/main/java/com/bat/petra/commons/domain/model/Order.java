package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import java.math.BigInteger;

/**
 * @author arkadiusz.wronski, created on 2019-02-12.
 */
@Entity
@Table(name = "ivydsd__Order__c", schema = "salesforce")
@Data
public class Order extends OrderBase {
  @Column(name = "number_of_line_items__c")
  private Double numberOfLines;
}
