package com.bat.petra.commons.domain.order.service;

import com.bat.petra.commons.domain.model.Order;
import com.bat.petra.commons.domain.order.repository.OrderRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-05-24.
 */
@Service
@RequiredArgsConstructor
public class OrderFacade {
  private final HHModuleService moduleService;
  private final OrderRepo orderRepo;

  public Optional<Integer> getOrderMaxDeliveryDate(String locationHierarchy){
    return moduleService.getOrderMaxDeliveryLeadTime(locationHierarchy);
  }

  public List<Order> findOrderForSapIdByPoNumber(String poNumber, String sapId) {
    return orderRepo.findByPurchaseOrderNumberAndStoreSapCustomerId(poNumber, sapId);
  }
}
