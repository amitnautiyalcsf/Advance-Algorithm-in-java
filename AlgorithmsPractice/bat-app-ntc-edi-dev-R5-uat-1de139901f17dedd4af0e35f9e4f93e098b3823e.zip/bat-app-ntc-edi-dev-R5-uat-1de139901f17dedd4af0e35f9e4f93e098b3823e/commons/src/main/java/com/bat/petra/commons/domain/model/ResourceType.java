package com.bat.petra.commons.domain.model;

import com.bat.petra.commons.domain.model.HHModuleMaster;
import com.bat.petra.commons.domain.model.IvyEntity;
import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-06-05.
 */
@Data
@Entity
@Table(name = "ivybase__resource_type__c", schema = "salesforce")
public class ResourceType extends IvyEntity {
  @Column(name = "ivybat__type__c")
  private String type;
  @OneToMany(mappedBy = "resourceType")
  List<HHModuleMaster> moduleMasters;
}
