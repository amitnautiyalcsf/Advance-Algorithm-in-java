package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.*;
import java.math.BigInteger;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-02-12.
 */
@Entity
@Table(name = "Account", schema = "salesforce")
@Data
public class Account extends IvyEntity {

  @Column(name = "Name")
  private String name;
  @Column(name = "ivybat__sap_customerid__c")
  private String sapCustomerId;
  @Column(name = "ivybat__market_iso__c", length = 2)
  private String marketISO;
  @Column(name = "ivybase__location_hierarchy__c", length = 18)
  private String locationHierarchy;
  @Column(name = "ivybat__delivery_lead_time__c")
  private BigInteger baseDeliveryLeadTime;
  @Column(name = "preferred_delivery_day__c")
  private String preferredDeliveryDay;
  @Column(name = "default_payment_method__c")
  private String defaultPaymentMethod;
  @Column(name = "ivybat__is_blocked_to_sales__c")
  private boolean isBlockedToSales;
  @Column(name = "GLN_Number__c")
  private String glnNumber;
  @OneToMany(mappedBy = "shipTo", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
  private List<Order> orderListByShipTo;

  @OneToMany(mappedBy = "store", fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
  private List<Order> orderListByStore;

}
