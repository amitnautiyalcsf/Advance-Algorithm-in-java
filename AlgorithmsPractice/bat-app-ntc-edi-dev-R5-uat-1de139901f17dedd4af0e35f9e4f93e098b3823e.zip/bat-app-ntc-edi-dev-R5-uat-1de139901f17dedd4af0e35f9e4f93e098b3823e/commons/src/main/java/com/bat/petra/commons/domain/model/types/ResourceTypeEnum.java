package com.bat.petra.commons.domain.model.types;

/**
 * @author arkadiusz.wronski, created on 2019-05-27.
 */
public enum ResourceTypeEnum {
  PRE_SALES("Pre-sales Rep");

  private String desc;

  ResourceTypeEnum(String desc){
    this.desc = desc;
  }

  public String getDesc(){return this.desc;}

}
