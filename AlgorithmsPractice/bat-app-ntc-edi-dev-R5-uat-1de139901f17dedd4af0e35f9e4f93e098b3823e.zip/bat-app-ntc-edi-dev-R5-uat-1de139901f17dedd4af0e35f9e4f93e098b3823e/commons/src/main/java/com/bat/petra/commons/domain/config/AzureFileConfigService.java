package com.bat.petra.commons.domain.config;

import com.bat.petra.commons.domain.model.types.AzureFileStatus;
import com.bat.petra.commons.domain.model.BulkOrderUploadStatus;
import com.bat.petra.commons.domain.model.types.OrderType;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.List;

@Component
@RequiredArgsConstructor
@Log4j2
public class AzureFileConfigService {
  private final BulkOrderUploadStatusRepo bulkOrderRepo;

  @Transactional(Transactional.TxType.REQUIRES_NEW)
  public Long findNextAndUpdateStatus() {
    BulkOrderUploadStatus azureFileConfig =
        bulkOrderRepo.findFirstByTypeAndStatus( OrderType.FOC.getTypeName(),AzureFileStatus.UPLOADED.getStatusName());
    if (azureFileConfig == null) {
      return null;
    }
    azureFileConfig.setStatus(AzureFileStatus.PROCESSING.getStatusName());
    bulkOrderRepo.save(azureFileConfig);
    return azureFileConfig.getId();
  }

  @Transactional
  public String markAsFailed(Long id){
    BulkOrderUploadStatus item = bulkOrderRepo.findById(id)
        .orElseThrow(() -> new IllegalStateException("No config with id " + id));
    item.setStatus(AzureFileStatus.FAILED.getStatusName());
    return item.getSfId();
  }

  @Transactional
  public List<BulkOrderUploadStatus> findAllWithStatus(String status){
    return bulkOrderRepo.finaAllByTypeAndStatus(OrderType.FOC.getTypeName() ,status);
  }

  @Transactional
  public void updateDeletedFileStatus(Long id){
    BulkOrderUploadStatus file = bulkOrderRepo.findById(id).
        orElseThrow(() ->new IllegalStateException("There is no file with id "+id));
    log.info("BulkOrder "+file.getFileName()+" set status "+AzureFileStatus.REMOVED.getStatusName());
    file.setStatus(AzureFileStatus.REMOVED.getStatusName());
  }

  public BulkOrderUploadStatus findBulkOrderByConfigId(Long configId){
    return bulkOrderRepo.findById(configId)
        .orElseThrow(() -> new IllegalStateException("No config with id " + configId));
  }

  @Transactional
  public void findBulkOrderAndSetupErrorFile(Long configId, String errorFile){
    log.info("Setting error file "+errorFile);
    bulkOrderRepo.findById(configId)
        .ifPresent(bulkOrderUploadStatus -> {
          bulkOrderUploadStatus.setErrorFile(errorFile);
          bulkOrderUploadStatus.setStatus(AzureFileStatus.FAILED.getStatusName()); //PTX-25344
          log.info(" File set successfully for "+bulkOrderUploadStatus.getFileName()+" sfId "+bulkOrderUploadStatus.getSfId());
        });
  }

  @Transactional
  public void saveBulkOrder(BulkOrderUploadStatus bulkOrderUploadStatus){
    log.info("Creating new record with bulkOrderUploadStatus "+bulkOrderUploadStatus);
    bulkOrderRepo.save(bulkOrderUploadStatus);
  }



}
