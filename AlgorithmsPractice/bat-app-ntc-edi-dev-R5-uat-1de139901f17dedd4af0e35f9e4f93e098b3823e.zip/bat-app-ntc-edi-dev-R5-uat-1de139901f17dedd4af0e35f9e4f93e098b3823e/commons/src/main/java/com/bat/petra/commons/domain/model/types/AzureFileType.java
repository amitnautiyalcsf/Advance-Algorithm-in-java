package com.bat.petra.commons.domain.model.types;

/**
 * @author arkadiusz.wronski, created on 2019-02-18.
 */
public enum AzureFileType {
  CSV("application/vnd.ms-excel"),
  ZIP("application/x-zip-compressed");
  AzureFileType(String type){this.type = type;}

  private String type;

  public String getName() {
    return type;
  }
}
