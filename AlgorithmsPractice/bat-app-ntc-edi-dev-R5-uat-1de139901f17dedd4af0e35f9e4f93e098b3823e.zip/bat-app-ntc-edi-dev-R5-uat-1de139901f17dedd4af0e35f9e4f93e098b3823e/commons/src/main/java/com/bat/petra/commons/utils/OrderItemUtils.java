package com.bat.petra.commons.utils;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.google.common.base.Predicates;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * @author arkadiusz.wronski, created on 2019-05-22.
 */
public class OrderItemUtils {
  private static final Logger LOGGER = LoggerFactory.getLogger(OrderItemUtils.class);

  public static List<List<OrderItem>> createOrdersListsGroupedBySapId(List<? extends OrderItem> allItems) {
    List<OrderItem> workingItems = new ArrayList<>(allItems);
    List<List<OrderItem>> result;

    List<OrderItem> itemsWithDate = workingItems.stream()
        .filter(OrderItem::hasDeliveryDate)
        .filter(Predicates.not(OrderItem::hasPoNumber))
        .collect(Collectors.toList());
    result = new ArrayList<>(getSapCustomerItemsGroupedBy(itemsWithDate, OrderItem::getDeliveryDate).values());
    workingItems.removeAll(itemsWithDate);

    List<OrderItem> itemsWithPoNumber = workingItems.stream().
        filter(OrderItem::hasPoNumber)
        .collect(Collectors.toList());
    result.addAll(getSapCustomerItemsGroupedBy(itemsWithPoNumber,OrderItem::getPoNumber).values());
    workingItems.removeAll(itemsWithPoNumber);

    List<List<OrderItem>> sapCustomerOrders = new ArrayList<>(workingItems.stream()
        .collect(Collectors.groupingBy(OrderItem::getSapCustomerId)).values());

    result.addAll(sapCustomerOrders);
    return result;
  }

  public static boolean ifAnyDateDifferent(List<OrderItem> items){
    OrderItem item = items.get(0);
    return items.stream()
        .anyMatch(any -> !any.getDeliveryDate().equals(item.getDeliveryDate()));
  }

  public static LocalDate calculateDeliveryDate(LocalDate orderUploadDate, Double baseDeliveryLeadTime, String preferredDeliveryDays) {
    Optional<String[]> preferredDays =
        preferredDeliveryDays != null ? Optional.of(preferredDeliveryDays.split(";")) : Optional.empty();
    LocalDate baseDeliveryDate = orderUploadDate.plusDays(baseDeliveryLeadTime.longValue());
    if(preferredDays.isPresent()) {
      if (DateUtils.isWeekDayOfDateInPreferred(baseDeliveryDate, preferredDays.get())) {
        return baseDeliveryDate;
      } else {
        Optional<DayOfWeek> nextDeliveryDay =
            DateUtils.getDateNextDeliveryDay(baseDeliveryDate, preferredDeliveryDays.split(";"));
        if(nextDeliveryDay.isPresent()){
          return calculateNextDeliveryDayDate(baseDeliveryDate, nextDeliveryDay.get());
        }
      }
    }
    return baseDeliveryDate;
  }

  public static boolean ifDeliveryDateLaterThanMaxDeliveryTime(LocalDate deliveryDate, LocalDate orderUploadDate, Integer maxDeliveryLeadTime){
    return orderUploadDate.plusDays(maxDeliveryLeadTime).isBefore(deliveryDate);
  }

  private static LocalDate calculateNextDeliveryDayDate(LocalDate baseDeliveryDate, DayOfWeek nextDeliveryDay) {
    int nexDayInt = nextDeliveryDay.getValue();
    int baseDayInt = baseDeliveryDate.getDayOfWeek().getValue();
    if (baseDayInt < nexDayInt){
      return baseDeliveryDate.plusDays(nexDayInt-baseDayInt);
    }
    return baseDeliveryDate.plusDays(7-baseDayInt+nexDayInt);
  }

  private static Map<String, List<OrderItem>> getSapCustomerItemsGroupedBy(List<OrderItem> sapCustomerOrders,
                                                                           Function<OrderItem,String> groupingSupplier) {
    return sapCustomerOrders
        .stream()
        .collect(Collectors.groupingBy(item -> item.getSapCustomerId()+groupingSupplier.apply(item)));
  }
}
