package com.bat.petra.commons.domain.orderitem;

import com.bat.petra.commons.domain.model.Account;
import com.bat.petra.commons.domain.model.types.OrderItemStatus;
import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.orderitem.service.OrderItemMapper;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationService;
import com.bat.petra.commons.domain.orderitem.validation.ValidatorsFactory;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * @author arkadiusz.wronski, created on 2019-06-28.
 */
@Component
@Log4j2
public class OrderItemProcessor {

  @Autowired
  private OrderItemValidationService validationService;
  @Autowired
  private ValidatorsFactory validatorsFactory;
  @Autowired
  private OrderItemMapper orderItemMapper;

  private final ExecutorService executor = Executors.newFixedThreadPool(5);
  private final ExecutorService orderLinesValidationExecutor = Executors.newFixedThreadPool(5);

  public List<ProcessorHolder.ResultHolder> processOrderItemOrder(List<List<OrderItem>> ordersItems) {
    ProcessorHolder processorHolder = new ProcessorHolder();
    List<ProcessorHolder.ResultHolder> futures = new LinkedList<>();
    for (List<OrderItem> itemsInOrder : ordersItems) {
      futures.add(processorHolder.new ResultHolder(itemsInOrder,
          executor.submit(() -> validationService.validateOrderByOrderItem(itemsInOrder))));
    }
    return futures;
  }

  public List<ProcessorHolder.OrderLineResultHolder> processOrderItemLines
      (List<ProcessorHolder.ResultHolder> futures, ProcessorHolder.ProcessingState state) throws Exception {
    List<ProcessorHolder.OrderLineResultHolder> orderLinesFutures = new LinkedList<>();
    ProcessorHolder processorHolder = new ProcessorHolder();
    for (ProcessorHolder.ResultHolder future : futures) {
      List<OrderItem> orderItems = future.getOrderItems();
      OrderValidationResult result = future.getOrderValidationResultFuture().get();
      if (!result.isValid()) {
        handleInvalidOrder(state, orderItems, result.getErrorDescription(), result.getContext());
      } else {
        initEmptyOrderLineListForGivenOrder(state, result.getOrder().getHerokuExternalId());
        validatorsFactory.getOrderItemListValidators().forEach(validator -> validator.validateOrderItemList(orderItems));
        List<Future<ProcessorHolder.OrderLineItemWithResult>> futureList = orderItems.stream()
            .map(item -> {
              setupOrderLineAdditionalParams(result.getContext(), item);
              return orderLinesValidationExecutor.submit(
                  () -> processorHolder.new OrderLineItemWithResult(
                      validationService.validateOrderItem(item,result.getContext()),
                      item));
            })
            .collect(Collectors.toList());
        orderLinesFutures.add(processorHolder.new OrderLineResultHolder(result, futureList));
      }
    }
    return orderLinesFutures;
  }

  private void initEmptyOrderLineListForGivenOrder(ProcessorHolder.ProcessingState state, String externalId) {
    state.getOrderLineItems().put(externalId, new ArrayList<>());
  }


  public void processValidOrders(List<ProcessorHolder.OrderLineResultHolder> orderLinesFutures,
                                 ProcessorHolder.ProcessingState state)throws ExecutionException, InterruptedException{
    for (ProcessorHolder.OrderLineResultHolder resultHolder : orderLinesFutures) {
      handleValidOrder(state, resultHolder.getFutures(), resultHolder.getOrderValidationResult());
    }
  }


  private void handleValidOrder(ProcessorHolder.ProcessingState state,
                                List<Future<ProcessorHolder.OrderLineItemWithResult>> orderItems,
                                OrderValidationResult result) throws ExecutionException, InterruptedException {
    boolean hasAnyOrderLinesValid = false;
    boolean hasAnyOrderLinesInvalid = false;
    for (Future<ProcessorHolder.OrderLineItemWithResult> orderItemResultFuture : orderItems) {
      ProcessorHolder.OrderLineItemWithResult orderLineItemWithResult = orderItemResultFuture.get();
      if (orderLineItemWithResult.getOrderItemValidationResult().isValid()) {
        hasAnyOrderLinesValid = true;
        handleValidOrderLine(state, orderLineItemWithResult.getOrderItem());
      } else {
        hasAnyOrderLinesInvalid = true;
        handleInvalidOrderLine(state, orderLineItemWithResult.getOrderItemValidationResult().getErrorDescription(),
            orderLineItemWithResult.getOrderItem(), orderLineItemWithResult.getOrderItemValidationResult().getContext());
      }
    }
    if (hasAnyOrderLinesValid || hasAnyOrderLinesInvalid) {
      if (!result.isExists() || result.isNeedsUpdate()) {
        state.getOrders().put(result.getOrder().getHerokuExternalId(), result);
        if (hasAnyOrderLinesInvalid) {
          updateOrderStatus(state, result, OrderItemStatus.ERROR.getStatusName());
        }
      }
    }
  }

  private void handleInvalidOrderLine(ProcessorHolder.ProcessingState state, String errorDescription,
                                      OrderItem orderItem, OrderItemValidationContext context) {
    log.info("Job "+orderItem.getJobId()+" with "+state.getOrderLineItemWithErrors().size()+" errors");
    orderItem.setErrorMsg(orderItem.hasNotBeenValidated()?errorDescription:orderItem.getErrorMsg());
    state.getOrderLineItemWithErrors().add(orderItemMapper.mapOrderItemToError(orderItem, context));
  }

  private void updateOrderStatus(ProcessorHolder.ProcessingState state, OrderValidationResult result, String status) {
    OrderItem item = result.getOrder();
    if (state.getOrders().keySet().contains(item.getHerokuExternalId())) {
      result.getContext().getValidationParams().put(OrderItemValidationObject.ORDER_STATUS.name(), status);
    } else {
      state.getOrderWithStatus().put(item.getHerokuExternalId(),status);
    }
  }

  private void handleValidOrderLine(ProcessorHolder.ProcessingState state, OrderItem line) {
    state.getOrderLineItems().get(line.getHerokuExternalId()).add(line);
  }

  private void handleInvalidOrder(ProcessorHolder.ProcessingState state, List<OrderItem> orderItems,
                                  String errorDescription,OrderItemValidationContext context ) {
    for (OrderItem orderItem : orderItems) {
      handleInvalidOrderLine(state, errorDescription, orderItem, context);
    }
  }

  private void setupOrderLineAdditionalParams(OrderItemValidationContext context, OrderItem item) {
    item.setAccountMarketISO(((Account)context.getValidationParams().get(OrderItemValidationObject.MAIN_ACCOUNT.name())).getMarketISO());
    item.setHerokuExternalId(context.getValidationParams().get(OrderItemValidationObject.HEROKU_EXTERNAL_ID.name()).toString());
  }

}
