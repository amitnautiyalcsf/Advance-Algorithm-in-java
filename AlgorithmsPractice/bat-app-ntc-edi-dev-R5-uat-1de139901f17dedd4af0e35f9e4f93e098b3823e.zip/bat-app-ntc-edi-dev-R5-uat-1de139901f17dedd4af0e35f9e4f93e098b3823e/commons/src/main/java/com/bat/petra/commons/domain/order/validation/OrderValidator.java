package com.bat.petra.commons.domain.order.validation;


import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;

/**
 * @author arkadiusz.wronski, created on 2019-06-13.
 */
public interface OrderValidator {
  OrderValidationResult validateOrder(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException;

  default OrderValidationResult validResult(){return OrderValidationResult.builder().valid(true).build();}
}
