package com.bat.petra.commons.domain.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MappedSuperclass;
import java.math.BigInteger;

/**
 * @author arkadiusz.wronski, created on 2019-03-15.
 */
@Data
@MappedSuperclass
public class OrderLineBase  extends IvyEntity {
  @Column(name = "ivydsd__uom_1_quantity__c")
  private BigInteger uom1price;
  @Column(name = "ivydsd__uom_2_quantity__c")
  private BigInteger uom2price;

  @Column(name = "ivydsd__Order__c")
  private String orderId;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "ivydsd__Product1__c", referencedColumnName = "sfid")
  private Product product;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "Manufacturing_SKU__c", referencedColumnName = "sfid")
  private Product manufacturingSKU;

  @Column(name = "ivydsd__order__r__herokuexternalid__c", length = 50)
  private String orderHerokuExternalId;
  @Column(name = "migration_external_id__c", length = 50)
  private String migrationExternalId;
  @Column(name = "ivydsd__line_item_type__c")
  private String lineItemType;
  @Override
  public String toString() {
    return "OrderLineBase{" +
        "uom1price=" + uom1price +
        ", uom2price=" + uom2price +
        ", orderId='" + orderId + '\'' +
        ", orderHerokuExternalId='" + orderHerokuExternalId + '\'' +
        '}';
  }
}
