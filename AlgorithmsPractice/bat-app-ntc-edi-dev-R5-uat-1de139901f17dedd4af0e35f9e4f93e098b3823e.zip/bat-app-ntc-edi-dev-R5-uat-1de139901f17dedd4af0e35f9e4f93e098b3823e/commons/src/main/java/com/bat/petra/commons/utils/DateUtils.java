package com.bat.petra.commons.utils;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;
import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-02-20.
 */
public class DateUtils {
  private static final Logger LOGGER = LoggerFactory.getLogger(DateUtils.class);
  public static DateTimeFormatter LOCAL_DATE_FORMATTER;
  private static String DATE_FORMAT;

  public static void initDateDateFormatter(String dateFormat){
    DATE_FORMAT = dateFormat;
    LOCAL_DATE_FORMATTER = DateTimeFormatter.ofPattern(DATE_FORMAT);
  }

  private static void checkFormatter(){
    if(LOCAL_DATE_FORMATTER==null){
      throw new RuntimeException("Date format has not been initialized. Invoke initDateDateFormatter(String dateFormat).");
    }
  }

  public static String getDateFormat() {
    return DATE_FORMAT;
  }

  public static Optional<LocalDate> parseDate(String date) {
    if (date == null) {
      return Optional.empty();
    }
    try {
      checkFormatter();
      return Optional.of(LocalDate.parse(date, LOCAL_DATE_FORMATTER));
    } catch (Exception ex) {
      LOGGER.warn("Incorrect date format " + ex.getLocalizedMessage());
    }
    return Optional.empty();
  }

  public static LocalDate parseLocalDate(String date) {
    checkFormatter();
    return LocalDate.parse(date, LOCAL_DATE_FORMATTER);
  }

  public static String formatDate(LocalDate date) {
    checkFormatter();
    return date.format(LOCAL_DATE_FORMATTER);}


  public static boolean isWeekDayOfDateInPreferred(LocalDate orderDate, String[] preferredWeekDays){
    for (String day : preferredWeekDays) {
      Optional<DayOfWeek> preferredWeekDay = getDayOffWeekForAbbr(day);
      if (preferredWeekDay.isPresent() && preferredWeekDay.get().getValue() == orderDate.getDayOfWeek().getValue()) {
        return true;
      }
    }
    return false;
  }

  public static Optional<DayOfWeek> getDateNextDeliveryDay(LocalDate orderDate, String[] preferredWeekDays) {
    //find another available day after current
    for (String day : preferredWeekDays) {
      Optional<DayOfWeek> preferredWeekDay = getDayOffWeekForAbbr(day);
      if (preferredWeekDay.isPresent() && preferredWeekDay.get().getValue() > orderDate.getDayOfWeek().getValue()) {
        return preferredWeekDay;
      }
    }
    // if not found, return first one
    return getDayOffWeekForAbbr(preferredWeekDays[0]);
  }

  private static Optional<DayOfWeek> getDayOffWeekForAbbr(String dayAbbr) {
    DayOfWeek result = null;
    for (DayOfWeek weekDay : DayOfWeek.values()) {
      if (weekDay.getDisplayName(TextStyle.SHORT, Locale.ENGLISH).toUpperCase().equals(dayAbbr.toUpperCase())) {
        result = weekDay;
        break;
      }
    }
    return Optional.ofNullable(result);
  }

  public static LocalDate addDaysToDate(String date, Long days){
    return DateUtils.parseLocalDate(date).plusDays(days);
  }

  public enum DateFormat{
    BRAZIL("yyyyMMdd"),
    SOUTH_AFRICA("dd/MM/yyyy");
    private String pattern;
    DateFormat(String dateFormat){this.pattern = dateFormat;}
    public String getStringPattern(){return this.pattern;}
  }

}
