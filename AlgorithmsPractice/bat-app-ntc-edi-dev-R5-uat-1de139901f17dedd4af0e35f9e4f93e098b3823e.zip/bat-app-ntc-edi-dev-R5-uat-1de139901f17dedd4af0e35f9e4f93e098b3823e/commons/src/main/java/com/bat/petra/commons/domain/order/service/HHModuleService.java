package com.bat.petra.commons.domain.order.service;

import com.bat.petra.commons.domain.model.HHModuleMaster;
import com.bat.petra.commons.domain.model.types.ResourceTypeEnum;
import com.bat.petra.commons.domain.order.repository.HHModuleMasterRepo;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-05-24.
 */
@Service
@RequiredArgsConstructor
public class HHModuleService {
  private final HHModuleMasterRepo moduleMasterRepo;

  public Optional<Integer> getOrderMaxDeliveryLeadTime(String locationHierarchy){
    return Optional.ofNullable(moduleMasterRepo
        .findByNameAndResourceTypeTypeAndLocationHierarchy("ORDB30", ResourceTypeEnum.PRE_SALES.getDesc(), locationHierarchy)
            .orElseGet(HHModuleMaster::new).getMaxDeliveryLeadTime());
  }

}
