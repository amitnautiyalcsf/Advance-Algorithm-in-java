package com.bat.petra.commons.domain.order.validation.validator

import com.bat.petra.commons.domain.orderitem.OrderItem
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject
import com.bat.petra.commons.utils.DateUtils
import spock.lang.Specification

import java.time.LocalDate
import java.time.format.DateTimeFormatter

import static com.bat.petra.commons.utils.DateUtils.LOCAL_DATE_FORMATTER

class DeliveryDateValidatorTest extends Specification {

  def orderItem = new OrderItem()
  def context = new OrderItemValidationContext()
  def validator = new DeliveryDateValidator()

  def "Delivery Date is in the past"() {
    given:
    init(
        "21/08/2019",
        "19/08/2019",
        3
    )

    when:
    def result = validator.validateOrder(orderItem, context)

    then:
    result.errorDescription == "Delivery Date is less than Delivery Lead Time"
  }

  def "Delivery Date is less than Delivery Lead Time"() {
    given:
    init(
        "21/08/2019",
        "23/08/2019",
        3
    )

    when:
    def result = validator.validateOrder(orderItem, context)

    then:
    result.errorDescription == "Delivery Date is less than Delivery Lead Time"
  }

  def "Delivery Date is NOT less than Delivery Lead Time"() {
    given:
    init(
        "21/08/2019",
        "25/08/2019",
        3
    )

    when:
    def result = validator.validateOrder(orderItem, context)

    then:
    result.valid
    orderItem.deliveryDate == "25/08/2019"
  }

  def "Delivery Date not set"() {
    given:
    init(
        "21/08/2019",
        null,
        3
    )

    when:
    def result = validator.validateOrder(orderItem, context)

    then:
    result.valid
    orderItem.deliveryDate == "27/08/2019"
  }

  def init(
      String processingDate,
      String deliveryDate,
      int deliveryLeadTime
  ) {
    orderItem.deliveryDate = deliveryDate

    context.validationParams.put(OrderItemValidationObject.ORDER_PROCESSING_DATE.name(), LocalDate.parse(processingDate, LOCAL_DATE_FORMATTER))
    context.validationParams.put(OrderItemValidationObject.BASE_DELIVERY_LEAD_TIME.name(), BigInteger.valueOf(deliveryLeadTime))
    context.validationParams.put(OrderItemValidationObject.PREFERRED_DELIVERY_DAY.name(), "Tue;Thu")
  }

  def setup() {
    LOCAL_DATE_FORMATTER = DateTimeFormatter.ofPattern(DateUtils.DateFormat.SOUTH_AFRICA.getStringPattern())
  }
}
