

create table salesforce.order_line_item_with_error
(
  id serial not null
    constraint order_line_item_with_error_pkey
      primary key,
  bulk_order_sfid varchar(18),
  error_desc varchar(2048),
  sap_customer_id varchar(64),
  delivery_date varchar(64),
  po_number varchar(64),
  product_internal_id varchar(64),
  sales_uom_high varchar(64),
  sales_uom_low varchar(64),
  order_type varchar(64),
  owner_id varchar(18)
);

