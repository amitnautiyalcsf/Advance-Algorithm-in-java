INSERT INTO salesforce.bulk_order_upload_status__c (container__c, file_type__c, name,  status__c, uploaded_url__c, file_name__c, file_path__c, sfid, id, type__c, ownerid, createddate)
VALUES ('batcontainer', 'application/vnd.ms-excel', 'test', 'Uploaded', 'https://batstorppnepetrabrzedi.blob.core.windows.net', 'orderLineItemTest.csv', 'orderLineItemTest.csv', 'bo_sfid', 1, null,'ediTestOwnerId','2019-05-27 00:30:00');
INSERT INTO salesforce.recordtype (name, sfid, id) VALUES ('Trade SKU', 'recortype_sfid', 1);
INSERT INTO salesforce.ivybase__product__c (name, ivybase__internalid__c, sfid, id, ivybat__market_iso__c,ivybase__active__c,recordtypeid) VALUES (null, 1112, 'product_sfid_1', 49, 'BR','Yes','recortype_sfid');
INSERT INTO salesforce.ivybase__product__c (name, ivybase__internalid__c, sfid, id, ivybat__market_iso__c,ivybase__active__c,recordtypeid) VALUES (null, 1113, 'product_sfid_2', 50, 'BR','Yes','recortype_sfid');
INSERT INTO salesforce.ivybase__product__c (name, ivybase__internalid__c, sfid, id, ivybat__market_iso__c,ivybase__active__c,recordtypeid) VALUES (null, 1114, 'product_sfid_3', 51, 'BR','Yes','recortype_sfid');
INSERT INTO salesforce.account (name, ivybat__sap_customerid__c, sfid, id,ivybat__market_iso__c, ivybat__is_blocked_to_sales__c, ivybase__location_hierarchy__c,ivybat__delivery_lead_time__c,preferred_delivery_day__c)
VALUES ('Hector Stores33', '0000000003', 'account_sfid_1', 22,'BR',false, '1234sfId',10,'Mon');
INSERT INTO salesforce.ivybat__credit_details__c (id, sfid, createddate, base_credit_days__c,  ivybat__account__c )
VALUES (11, 'sfid1', '2019-01-30 16:33:46', 10, 'account_sfid_1' ),
(12, 'sfid2', '2019-04-30 11:33:00', 5, 'account_sfid_1' );

INSERT INTO salesforce.ivydsd__order__c (id, sfid, ivydsd__purchase_order_number__c, herokuexternalid__c, ship_to__c,market_iso__c,ivydsd__store__c)
VALUES (1, 'order_sfid_1', 'PO_EXISTING1', null, 'account_sfid_1','BR','account_sfid_1'),
       (2, 'order_sfid_2', 'PO_EXISTING2', 'EXISTING_HEROKU_ID_1', 'account_sfid_1','BR','account_sfid_1');


INSERT INTO salesforce.order_line_item_with_error (id, error_desc, sap_customer_id, delivery_date, po_number, product_internal_id, sales_uom_high, sales_uom_low, order_type)
VALUES (1, 'fake error 1', '0000000003', '20991010', 'ODR-2019-02-11-9990',1112,'100','998','FOC'),
       (2, 'fake error 2', '0000000005', '20991010', 'ODR-2019-02-11-9991',1112,'100','999','EDI');
