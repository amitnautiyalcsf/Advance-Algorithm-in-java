package com.bat.petra.edibr.infrastructure.batch.steps

import com.bat.petra.commons.domain.config.EndMarketConfigurationService
import com.bat.petra.commons.domain.model.types.MarketISO
import com.bat.petra.commons.domain.model.types.RecordTypeValue
import com.bat.petra.commons.domain.model.BulkOrderUploadStatus
import com.bat.petra.commons.domain.model.EndMarketConfiguration
import com.bat.petra.commons.domain.config.BulkOrderUploadStatusRepo
import com.bat.petra.commons.domain.config.EndMarketConfigurationRepo
import com.bat.petra.commons.domain.config.AzureFileConfigService
import spock.lang.Specification

import java.util.zip.ZipInputStream

class AzureFileServiceTest extends Specification {

  private BulkOrderUploadStatusRepo azureFileConfigRepo = Mock()

  private EndMarketConfigurationRepo endMarketConfigurationRepo = Mock()

  private AzureFileConfigService azureFileConfigService = Mock()

  private EndMarketConfigurationService marketSrv = Spy(EndMarketConfigurationService,constructorArgs: [endMarketConfigurationRepo])

  private AzureFileService azureFileServiceSpy = Spy(AzureFileService,
      constructorArgs: [azureFileConfigRepo, marketSrv,azureFileConfigService])

  def "Download CSV File"() {
    given: "There is file with id 1 to process"
    def config = new BulkOrderUploadStatus(id: 1, uploadedUrl: "blobUrl", fileType: "application/vnd.ms-excel")
    azureFileConfigRepo.findById(1) >> Optional.of(config)
    and: "There is configuration of blob"
    endMarketConfigurationRepo.findByRecordTypeNameAndActiveAndMarketISO(RecordTypeValue.EDI.getTypeName(), true,
        MarketISO.BR.getValue()) >> Collections.singletonList(new EndMarketConfiguration(connectionString: "connection_string"))
    and: "Downloaded blob has content 'text_text'"
    azureFileServiceSpy.getCloudBlobInputStream(
        "connection_string", config) >> new ByteArrayInputStream("test_text".bytes)
    when: "File with config id 1 is downloaded"
    InputStream file = azureFileServiceSpy.downloadFile(1)
    then: "File is properly downloaded"
    file.text == "test_text"
  }

  def "Download ZIP File"() {
    given: "There is file with id 1 to process"
    def config = new BulkOrderUploadStatus(id: 1, uploadedUrl: "blobUrl", fileType: "application/x-zip-compressed")
    azureFileConfigRepo.findById(1) >> Optional.of(config)
    and: "There is configuration of blob"
    endMarketConfigurationRepo.findByRecordTypeNameAndActiveAndMarketISO(RecordTypeValue.EDI.getTypeName(), true,
        MarketISO.BR.getValue()) >> Collections.singletonList(new EndMarketConfiguration(connectionString: "connection_string"))
    and: "Downloaded blob has content 'text_text' compressed in first file"
    azureFileServiceSpy.getCloudBlobInputStream(
        "connection_string", config) >> getClass().getClassLoader().getResourceAsStream("azure_file_service_test.zip")
    when:
    ZipInputStream file = azureFileServiceSpy.downloadFile(1)
    then:
    file.text == "test_text"
  }

}
