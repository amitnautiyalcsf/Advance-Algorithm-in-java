package com.bat.petra.edibr.infrastructure.batch.config

import com.bat.petra.commons.domain.config.BulkOrderUploadStatusRepo
import com.bat.petra.commons.domain.orderline.OrderLineItemRepo
import com.bat.petra.edibr.domain.orderitemerror.OrderLineItemWithErrorRepo
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmpRepo
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmpRepo
import com.bat.petra.edibr.infrastructure.service.SchedulingService
import com.bat.petra.edibr.infrastructure.batch.steps.AzureFileService
import com.bat.petra.commons.domain.order.repository.OrderPaymentInstructionsRepo
import com.bat.petra.commons.domain.order.repository.OrderRepo
import com.bat.petra.commons.utils.DateUtils
import groovy.sql.Sql
import org.springframework.batch.core.Job
import org.springframework.batch.core.JobParametersBuilder
import org.springframework.batch.core.launch.JobLauncher
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import spock.lang.Specification
import spock.mock.DetachedMockFactory

import javax.sql.DataSource
import java.time.LocalDate

/**
 * @author arkadiusz.wronski , created on 2019-02-18.
 */
@SpringBootTest
class BatchConfigurationTest extends Specification {
  private final static SAP_ID='0000000003'
  @Autowired
  SchedulingService azureService

  @Autowired
  BatchConfiguration batchConfiguration
  @Autowired
  private JobLauncher jobLauncher

  @Autowired
  private DataSource dataSource

  @Autowired
  private OrderRepo orderRepo

  @Autowired
  private OrderLineItemRepo orderLineRepo

  @Autowired
  private OrderHerokuTmpRepo orderTmpRepo

  @Autowired
  private OrderLineHerokuTmpRepo orderLineTmpRepo

  @Autowired
  private Job azureJob

  @Autowired
  private OrderLineItemWithErrorRepo errorRepo

  @Autowired
  private AzureFileService azureFileService

  @Autowired
  private BulkOrderUploadStatusRepo configRepo

  @Autowired
  private OrderPaymentInstructionsRepo instructionsRepo

  def params = new JobParametersBuilder()
      .addString("ID", "1324")
      .addLong("configId", 1)
      .toJobParameters()

  def setup() {
    new Sql(dataSource).execute(new File(getClass().getResource('/insertsForTest.sql').toURI()).text)
  }

  def cleanup() {
    new Sql(dataSource).execute(new File(getClass().getResource('/cleanup.sql').toURI()).text)
  }

  def "Item from csv file is saved to a database"() {
    given:
    azureFileService.downloadFile(1) >> getTestFileInputStream()
    azureFileService.uploadFileToAzure(_,_) >> Optional.empty()
    when:
    jobLauncher.run(azureJob, params)
    then:
    def orderLinesItems = orderLineRepo.findAll().sort({ a, b -> a.uom1price<=>b.uom1price})
    def errors = errorRepo.findAll().sort({a,b -> a.salesUomLow<=>b.salesUomLow})
    and: "Valid order with one line is successfully saved"

    def orderLine1 = orderLinesItems.get(0)
    def order1 = orderRepo.findByPurchaseOrderNumberAndStoreSapCustomerId('ODR-2019-02-11-0340',SAP_ID).get(0)
    orderLine1.uom1price == 1
    orderLine1.uom2price == 100
    orderLine1.orderHerokuExternalId != null
    orderLine1.product.internalId == 1112
    order1.herokuExternalId == orderLine1.orderHerokuExternalId
    order1.numberOfLines == 1
    order1.deliveryDate == LocalDate.parse('20991010', DateUtils.LOCAL_DATE_FORMATTER)
    order1.orderType == null
    order1.ownerId == "ediTestOwnerId"
    def instruction1 = instructionsRepo.findByOrderHerokuExternalId(order1.herokuExternalId)
    instruction1.get().dueDate == LocalDate.parse('20991015', DateUtils.LOCAL_DATE_FORMATTER)

    and: "Valid order with lines is successfully saved"
    def orderLine2 = orderLinesItems.get(1)
    def order2 = orderRepo.findByPurchaseOrderNumberAndStoreSapCustomerId('ODR-2019-02-11-0341',SAP_ID).get(0)
    orderLine2.uom1price == 2
    orderLine2.uom2price == 100
    orderLine2.orderHerokuExternalId != null
    orderLine2.product.internalId == 1112
    order2.numberOfLines == 2
    order2.herokuExternalId == orderLine2.orderHerokuExternalId
    order2.deliveryDate == LocalDate.parse('20991010', DateUtils.LOCAL_DATE_FORMATTER)
    def orderLine3 = orderLinesItems.get(2)
    orderLine3.uom1price == 3
    orderLine3.uom2price == 100
    orderLine3.orderHerokuExternalId != null
    orderLine3.product.internalId == 1113
    order2.herokuExternalId == orderLine3.orderHerokuExternalId
    order2.deliveryDate == LocalDate.parse('20991010', DateUtils.LOCAL_DATE_FORMATTER)

    order2.orderType == null
    order2.ownerId == "ediTestOwnerId"
    def instruction2 = instructionsRepo.findByOrderHerokuExternalId(order2.herokuExternalId)
    instruction2.get().dueDate == LocalDate.parse('20991015', DateUtils.LOCAL_DATE_FORMATTER)

    and: "Invalid order not belonging to product is saved to error"
    def error1 = errors.get(0)
    error1.sapCustomerId == "0000000003"
    error1.deliveryDate == "20991010"
    error1.poNumber == "ODR-2019-02-11-0342"
    error1.productInternalId == "111"
    error1.salesUomHigh == "100"
    error1.salesUomLow == "4"
    error1.orderType == null
    error1.errorDesc.contains("roduct & and Account must have the same Market ISO")

    and: "Invalid order without account is saved to error"
    def error2 = errors.get(1)
    error2.sapCustomerId == "0000000004"
    error2.deliveryDate == "20991010"
    error2.poNumber == "ODR-2019-02-11-0343"
    error2.productInternalId == "111"
    error2.salesUomHigh == "100"
    error2.salesUomLow == "5"
    error2.orderType == null
    error2.errorDesc.contains(error2.sapCustomerId+' does not exist.')

    and: "Invalid order with date in the past is saved to error"
    def error3 = errors.get(2)
    error3.sapCustomerId == "0000000003"
    error3.deliveryDate == "19991010"
    error3.poNumber == "ODR-2019-02-11-0344"
    error3.productInternalId == "111"
    error3.salesUomHigh == "100"
    error3.salesUomLow == "6"
    error3.orderType == null
    error3.errorDesc.contains("Delivery Date is less than Delivery Lead Time")

    and: "Invalid Order Line with decimal UOM's is saved to error"
    def error4 = errors.get(5)
    error4.sapCustomerId == "0000000003"
    error4.deliveryDate == "20991010"
    error4.poNumber == "ODR-2019-02-11-0345"
    error4.productInternalId == "1112"
    error4.salesUomHigh == "10.5"
    error4.salesUomLow == "90"
    error4.orderType == null
    error4.errorDesc.contains("UOM's cannot contain decimal places")

    and: "Invalid Order Line with zeros in UOM is saved to error"
    def error5 = errors.get(6)
    error5.sapCustomerId == "0000000003"
    error5.deliveryDate == "20991010"
    error5.poNumber == "ODR-2019-02-11-0345"
    error5.productInternalId == "1114"
    error5.salesUomHigh == "-10"
    error5.salesUomLow == "92"
    error5.orderType == null
    error5.errorDesc.contains("Negative numbers cannot be populated.")

    and: "Existing invalid order with fake error 1"
    def error6 = errors.get(7)
    error6.sapCustomerId == "0000000003"
    error6.deliveryDate == "20991010"
    error6.poNumber == "ODR-2019-02-11-9990"
    error6.productInternalId == "1112"
    error6.salesUomHigh == "100"
    error6.salesUomLow == "998"
    error6.orderType == "FOC"
    error6.errorDesc.contains("fake error 1")

    and: "Invalid Order Line with existing po number"
    def error7 = errors.get(3)
    error7.sapCustomerId == "0000000003"
    error7.deliveryDate == "20991010"
    error7.poNumber == "PO_EXISTING1"
    error7.productInternalId == "1112"
    error7.salesUomHigh == "100"
    error7.salesUomLow == "7"
    error7.orderType == null
    error7.errorDesc.contains("already exists.")

    and: "Invalid Order Line with another existing po number"
    def error8 = errors.get(4)
    error8.sapCustomerId == "0000000003"
    error8.deliveryDate == "20991010"
    error8.poNumber == "PO_EXISTING2"
    error8.productInternalId == "1112"
    error8.salesUomHigh == "100"
    error8.salesUomLow == "8"
    error8.orderType == null
    error8.errorDesc.contains("already exists.")

    and: "Existing invalid order with fake error 2"
    def error9 = errors.get(8)
    error9.sapCustomerId == "0000000005"
    error9.deliveryDate == "20991010"
    error9.poNumber == "ODR-2019-02-11-9991"
    error9.productInternalId == "1112"
    error9.salesUomHigh == "100"
    error9.salesUomLow == "999"
    error9.orderType == "EDI"
    error9.errorDesc.contains("fake error 2")

    and: "There are no duplicated objects"
    orderRepo.count() == 4
    orderLineRepo.count() == 3
    orderLineTmpRepo.count() == 0
    orderTmpRepo.count() == 0
    // in db already were two orders without instruction
    instructionsRepo.count() == orderRepo.count() - 2
    errorRepo.count() == 9
    and: "Status is correct"
    configRepo.findById(1L).get().status == "Finished with errors"
  }

  InputStream getTestFileInputStream() {
    InputStream inputStream = getClass().getClassLoader().getResourceAsStream("orderItemTest.csv")
    return inputStream
  }

  @TestConfiguration
  static class MockConfig {
    def detachedMockFactory = new DetachedMockFactory()

    @Bean
    AzureFileService azureFileService() {
      return detachedMockFactory.Mock(AzureFileService)
    }
  }


}
