package com.bat.petra.edibr.order.facade

import com.bat.petra.commons.domain.model.HHModuleMaster
import com.bat.petra.commons.domain.model.types.ResourceTypeEnum
import com.bat.petra.commons.domain.order.repository.HHModuleMasterRepo
import com.bat.petra.commons.domain.order.repository.OrderRepo
import com.bat.petra.commons.domain.order.service.HHModuleService
import com.bat.petra.commons.domain.order.service.OrderFacade
import spock.lang.Specification

/**
 * @author arkadiusz.wronski , created on 2019-05-24.
 */
class OrderFacadeTest extends Specification{
  private OrderRepo orderRepo = Mock()
  private HHModuleMasterRepo moduleRepo = Mock()
  private HHModuleService moduleService = Spy(HHModuleService, constructorArgs:[moduleRepo])
  private OrderFacade orderFacade = Spy(OrderFacade, constructorArgs: [moduleService, orderRepo])

  private static final String LOCATION_HIERARCHY = "12sfid"

  def module = new HHModuleMaster()


  def "returns default value if no sf config"(){
    given:
    moduleRepo.findByNameAndResourceTypeTypeAndLocationHierarchy("ORDB30", ResourceTypeEnum.PRE_SALES.getDesc(),LOCATION_HIERARCHY) >> Optional.ofNullable()
    when:
    def result = orderFacade.getOrderMaxDeliveryDate(LOCATION_HIERARCHY)
    then:
    result == Optional.empty()
  }

  def "returns sf value when set"(){
    given:
    module.maxDeliveryLeadTime = 25
    moduleRepo.findByNameAndResourceTypeTypeAndLocationHierarchy("ORDB30", ResourceTypeEnum.PRE_SALES.getDesc(),LOCATION_HIERARCHY) >> Optional.of(module)
    when:
    def result = orderFacade.getOrderMaxDeliveryDate(LOCATION_HIERARCHY)
    then:
    result.get() == 25
  }
}
