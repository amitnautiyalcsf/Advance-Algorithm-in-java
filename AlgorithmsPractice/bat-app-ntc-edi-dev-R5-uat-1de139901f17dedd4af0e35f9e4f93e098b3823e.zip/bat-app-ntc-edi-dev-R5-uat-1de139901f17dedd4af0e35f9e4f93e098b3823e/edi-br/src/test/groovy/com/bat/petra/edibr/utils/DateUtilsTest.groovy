package com.bat.petra.edibr.utils

import com.bat.petra.commons.utils.DateUtils
import spock.lang.Specification

import java.time.DayOfWeek

/**
 * @author arkadiusz.wronski , created on 2019-05-24.
 */
class DateUtilsTest extends Specification{


  def"delivery day set to MON"(){
    given:
    //Friday
    def localDate = java.time.LocalDate.parse("2019-05-24")
    when:
    def result = DateUtils.getDateNextDeliveryDay(localDate,"MON,THU".split(","))
    then:
    DayOfWeek.valueOf("MONDAY") == result.get()
  }

  def"delivery day set to FRI"(){
    given:
    //Thursday
    def localDate = java.time.LocalDate.parse("2019-05-23")
    when:
    def result = DateUtils.getDateNextDeliveryDay(localDate,"MON,FRI".split(","))
    then:
    DayOfWeek.valueOf("FRIDAY") == result.get()
  }

}
