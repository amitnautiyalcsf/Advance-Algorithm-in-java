package com.bat.petra.edibr.utils

import com.bat.petra.commons.domain.orderitem.OrderItem
import com.bat.petra.commons.utils.OrderItemUtils
import spock.lang.Specification

import java.time.LocalDate

/**
 * @author arkadiusz.wronski , created on 2019-05-22.
 */
class OrderItemUtilsTest extends Specification{
  private static final String SAP_ID = "SAP_ID"
  def item1 = new OrderItem()
  def item2 = new OrderItem()
  def item3 = new OrderItem()
  def item4 = new OrderItem()
  def item5 = new OrderItem()
  def setup(){
    item1.sapCustomerId = SAP_ID+'1'
    item2.sapCustomerId = SAP_ID+'1'
    item3.sapCustomerId = SAP_ID+'1'
    item4.sapCustomerId = SAP_ID+'2'
    item5.sapCustomerId = SAP_ID+'2'
  }

  def"Group items by sapId"(){
    given:
    def list = Arrays.asList(item1,item2,item3,item4,item5)
    when:
    def result = OrderItemUtils.createOrdersListsGroupedBySapId(list)
    then:
    result.size() == 2
  }

  def"Group items by sapId and deliveryDate"(){
    given:
    item1.deliveryDate = '20191010'
    item2.deliveryDate = '20191010'
    item3.deliveryDate = '20191011'
    item4.deliveryDate = '20191010'
    item5.deliveryDate = '20191010'
    def list = Arrays.asList(item1,item2,item3,item4,item5)
    when:
    def result = OrderItemUtils.createOrdersListsGroupedBySapId(list)
    then:
    result.size() == 3
  }

  def"Group items by sapId and poNumber"(){
    given:
    item1.poNumber = 'poNumber1'
    item2.poNumber = 'poNumber1'
    item3.poNumber = 'poNumber2'
    item4.poNumber = 'poNumber1'
    item5.poNumber = 'poNumber1'
    def list = Arrays.asList(item1,item2,item3,item4,item5)
    when:
    def result = OrderItemUtils.createOrdersListsGroupedBySapId(list)
    then:
    result.size() == 3
  }

  def"Group items by date and poNumber"(){
    given:
    item1.poNumber = 'poNumber1'
    item1.deliveryDate = '20191010'
    item2.poNumber = 'poNumber1'
    item3.deliveryDate = '20191010'
    item4.poNumber = 'poNumber1'
    item5.poNumber = 'poNumber1'
    def list = Arrays.asList(item1,item2,item3,item4,item5)
    when:
    def result = OrderItemUtils.createOrdersListsGroupedBySapId(list)
    then:
    result.size() == 3
    result.get(0).size() == 1
  }

  def"check if all dates are the same = true"(){
    given:
    item1.deliveryDate = '20191010'
    item2.deliveryDate = '20191010'
    item3.deliveryDate = '20191010'
    item4.deliveryDate = '20191010'
    item5.deliveryDate = '20191010'
    when:
    def result = OrderItemUtils.ifAnyDateDifferent(Arrays.asList(item1,item2,item3,item4,item5))
    then:
    !result
  }

  def"check if all dates are the same = false"(){
    given:
    item1.deliveryDate = '20191010'
    item2.deliveryDate = '20191010'
    item4.deliveryDate = '20191010'
    item5.deliveryDate = '20191010'
    when: "item 3 has empty delivery date"
    def result = OrderItemUtils.ifAnyDateDifferent(Arrays.asList(item1,item2,item3,item4,item5))
    then: "Method finds list contains object with different dates"
    result
  }

  def"set order delivery date to friday 2019-05-17"(){
    given:
    item1.orderUploadDate = LocalDate.parse('2019-05-06')
    when:
    def calculatedDate = OrderItemUtils.calculateDeliveryDate(item1.orderUploadDate,8,"Mon;Fri")
    then:
    calculatedDate == LocalDate.parse('2019-05-17')
  }

  def"set order delivery date to tue 2019-05-14"(){
    given:
    item1.orderUploadDate = LocalDate.parse('2019-05-06')
    when:
    def calculatedDate = OrderItemUtils.calculateDeliveryDate(item1.orderUploadDate,7,"TUE;WED")
    then:
    calculatedDate == LocalDate.parse('2019-05-14')
  }

  def"delivery date exceed max delivery lead time"(){
    given:
    item1.orderUploadDate = LocalDate.parse('2019-05-06')
    def deliveryDate= LocalDate.parse('2019-05-16')
    when:
    def result = OrderItemUtils.ifDeliveryDateLaterThanMaxDeliveryTime(deliveryDate,item1.orderUploadDate, 5)
    then:
    result
  }



}
