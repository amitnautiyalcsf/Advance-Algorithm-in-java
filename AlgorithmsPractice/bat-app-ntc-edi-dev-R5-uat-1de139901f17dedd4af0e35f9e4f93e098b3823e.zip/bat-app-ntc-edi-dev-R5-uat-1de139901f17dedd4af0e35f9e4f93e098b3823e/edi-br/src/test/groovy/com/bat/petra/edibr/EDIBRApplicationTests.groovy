package com.bat.petra.edibr

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.context.ApplicationContext
import spock.lang.Specification

@SpringBootTest
class EDIBRApplicationTests extends Specification {

    @Autowired
    private ApplicationContext applicationContext

    def "Application starts"() {
        expect:
        applicationContext
    }

}

