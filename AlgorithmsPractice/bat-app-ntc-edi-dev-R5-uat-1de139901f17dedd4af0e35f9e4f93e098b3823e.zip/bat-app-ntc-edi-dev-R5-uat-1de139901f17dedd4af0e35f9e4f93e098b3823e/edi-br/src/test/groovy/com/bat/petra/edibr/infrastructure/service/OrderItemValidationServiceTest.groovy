package com.bat.petra.edibr.infrastructure.service

import com.bat.petra.commons.domain.model.types.RecordTypeValue

import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationService
import com.bat.petra.commons.domain.order.repository.AccountRepository
import com.bat.petra.commons.domain.orderitem.repository.CreditDetailsRepo
import com.bat.petra.commons.domain.orderitem.repository.ProductRepo
import com.bat.petra.commons.domain.orderitem.OrderItem
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationResult
import com.bat.petra.commons.domain.order.validation.OrderValidationResult
import com.bat.petra.commons.domain.model.Account
import com.bat.petra.commons.domain.model.CreditDetails
import com.bat.petra.commons.domain.model.Order
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidator
import com.bat.petra.commons.domain.orderitem.validation.validator.ProductInternalIdValidator
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmp
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmpRepo
import com.bat.petra.commons.domain.model.Product
import com.bat.petra.commons.domain.order.service.OrderFacade
import com.bat.petra.commons.domain.order.repository.HHModuleMasterRepo
import com.bat.petra.commons.domain.order.repository.OrderRepo
import com.bat.petra.commons.domain.order.service.HHModuleService
import com.bat.petra.commons.domain.order.validation.OrderValidator
import com.bat.petra.commons.utils.DateUtils
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext
import com.bat.petra.edibr.domain.configuration.ValidatorsFactoryBr

import com.bat.petra.commons.domain.order.validation.validator.AccountValidator
import com.bat.petra.commons.domain.order.validation.validator.DeliveryDateValidator
import com.bat.petra.commons.domain.order.validation.validator.MandatoryFieldsValidator
import com.bat.petra.commons.domain.order.validation.validator.MaxDeliveryLeadTimeValidator
import com.bat.petra.edibr.domain.order.validation.validator.OrderTmpExistenceValidator
import com.bat.petra.commons.domain.order.validation.validator.PoNumberExtraConditionValidator
import com.bat.petra.commons.domain.orderitem.validation.validator.PriceValidator
import com.bat.petra.edibr.domain.ordertmp.service.OrderTmpFacade
import spock.lang.Specification
import spock.lang.Subject

import java.time.LocalDate

class OrderItemValidationServiceTest extends Specification {
  private AccountRepository accountRepo = Mock()
  private ProductRepo productRepo = Mock()
  private OrderHerokuTmpRepo orderHerokuTmpRepo = Mock()
  private OrderRepo orderRepo = Mock()
  private HHModuleMasterRepo moduleRepo = Mock()
  private CreditDetailsRepo creditDetailsRepo = Mock()
  private OrderItemValidationContext validatorContext = new OrderItemValidationContext()
  private PriceValidator priceValidator = new PriceValidator()
  private validatorsFactoryBr = new ValidatorsFactoryBr()

  private  HHModuleService moduleService = (HHModuleService)Spy(HHModuleService, constructorArgs:[moduleRepo])
  private  OrderFacade orderFacade = (OrderFacade)Spy(OrderFacade, constructorArgs: [moduleService,orderRepo])
  private OrderTmpFacade orderTmpFacade = (OrderTmpFacade)Spy(OrderTmpFacade, constructorArgs:[orderHerokuTmpRepo] )

  private static final String ACCOUNT_ISO='BR'
  private static final String ACCOUNT_SFID='ACCOUNT_SFID'
  private static final String SAP_CUSTOMER_ID='0123456789'
  private static final String JOB_ID='123123'
  private static final String LOCATION_HIERARCHY='1234SFID'

  @Subject
  private OrderItemValidationService service = (OrderItemValidationService)Spy(
      OrderItemValidationService, constructorArgs: [validatorsFactoryBr])

  private OrderItem orderItem = new OrderItem()
  private Order order = new Order()
  private Account account = new Account()
  private orderTmp = new OrderHerokuTmp()


  def setup(){
    DateUtils.initDateDateFormatter(DateUtils.DateFormat.BRAZIL.getStringPattern())
    account.sfId = ACCOUNT_SFID
    account.sapCustomerId = 'sapId'
    account.marketISO = ACCOUNT_ISO
    account.locationHierarchy = LOCATION_HIERARCHY
    account.preferredDeliveryDay = 'Mon'
    account.baseDeliveryLeadTime = BigInteger.valueOf(1)
    account.isBlockedToSales = false
    orderItem.sapCustomerId = SAP_CUSTOMER_ID
    orderItem.productInternalId = '1'
    orderItem.deliveryDate = "2019-02-22"
    orderItem.orderUploadDate = LocalDate.parse('2019-02-22')
    orderItem.poNumber = "PO1234"
    orderItem.jobId = "job1"
    creditDetailsRepo.findFirstByAccountSfIdOrderByCreatedDateDesc(account.sfId) >> Optional.of(new CreditDetails())
  }
  def "validate for empty UOM's"() {
    given:
    orderItem.productInternalId = null
    orderItem.salesUomLow = ''
    orderItem.salesUomHigh = ''
    when:
    OrderItemValidationResult result = priceValidator.validateOrderItem(orderItem, validatorContext)
    then:
    result.errorDescription.contains("Both High & Low UOM cannot be blank or 0.")
  }

  def "validate for zeros UOM's"() {
    given:
    orderItem.productInternalId = null
    orderItem.salesUomLow = ' 0'
    orderItem.salesUomHigh = '0 '
    when:
    OrderItemValidationResult result = priceValidator.validateOrderItem(orderItem, validatorContext)
    then:
    result.errorDescription.contains("Both High & Low UOM cannot be blank or 0.")
  }

  def "uomLow empty but uomHigh has correct value"() {
    given:
    orderItem.productInternalId = null
    orderItem.salesUomLow = ''
    orderItem.salesUomHigh = '123'
    when:
    OrderItemValidationResult result = priceValidator.validateOrderItem(orderItem, validatorContext)
    then:
    result.errorDescription == null
  }

  def "uomLow correct but uomHigh 0"() {
    given:
    orderItem.productInternalId = null
    orderItem.salesUomLow = '1234'
    orderItem.salesUomHigh = '0'
    when:
    OrderItemValidationResult result = priceValidator.validateOrderItem(orderItem, validatorContext)
    then:
    result.errorDescription == null
  }


  def "validate for empty fields"() {
    given:
    orderItem.productInternalId = null
    def orderItem2 = new OrderItem()
    accountRepo.findBySapCustomerId(orderItem.sapCustomerId) >> Optional.of(account)
    orderTmpFacade.getOrderTmpForPoNumberAndSapId(_,_) >> Optional.empty()
    validatorsFactoryBr.getOrderValidators().addAll(Arrays.asList(new MandatoryFieldsValidator()))
    when:
    OrderValidationResult result = service.validateOrderByOrderItem( Arrays.asList(orderItem,orderItem2))
    then:
    result.errorDescription.contains("All Mandatory fields must be populated")
  }

  def "validate for order with no proper account"() {
    given:
    accountRepo
        .findBySapCustomerId(orderItem.sapCustomerId) >> Optional.empty()
    validatorsFactoryBr.getOrderValidators().addAll(Arrays.asList(new AccountValidator(accountRepo)))
    when:
    OrderValidationResult result = service.validateOrderByOrderItem(Arrays.asList(orderItem))
    then:
    result.errorDescription.contains(orderItem.sapCustomerId+' does not exist.')
  }

  def "validate for order with past date"() {
    given:
    orderItem.deliveryDate='19901010'
    accountRepo.findBySapCustomerId(orderItem.sapCustomerId) >> Optional.of(account)
    orderFacade.findOrderForSapIdByPoNumber(orderItem.poNumber,orderItem.sapCustomerId) >> Collections.emptyList()
    orderTmpFacade.getOrderTmpForPoNumberAndSapId(_,_) >> Optional.empty()
    validatorsFactoryBr.getOrderValidators().addAll(Arrays.asList(new AccountValidator(accountRepo),new DeliveryDateValidator()))
    when:
    OrderValidationResult result = service.validateOrderByOrderItem(Arrays.asList(orderItem))
    then:
    result.errorDescription.contains('Delivery Date is less than Delivery Lead Time')
  }

  def "incorrect date format"() {
    given:
    orderItem.deliveryDate='10062021'
    accountRepo.findBySapCustomerId(orderItem.sapCustomerId) >> Optional.of(account)
    orderFacade.findOrderForSapIdByPoNumber(orderItem.poNumber,orderItem.sapCustomerId) >> Collections.emptyList()
    orderTmpFacade.getOrderTmpForPoNumberAndSapId(_,_) >> Optional.empty()
    validatorsFactoryBr.getOrderValidators().addAll(Arrays.asList(new AccountValidator(accountRepo), new DeliveryDateValidator()))
    when:
    OrderValidationResult result = service.validateOrderByOrderItem( Arrays.asList(orderItem))
    then:
    result.errorDescription.contains('Delivery date must be in yyyyMMdd format')
  }

  def "validate for orderLineItem with no product"() {
    given:
    orderItem.accountMarketISO=ACCOUNT_ISO
    productRepo.findByInternalIdAndMarketISOAndActiveAndRecordTypeName(new BigInteger(orderItem.productInternalId),ACCOUNT_ISO,'Yes', RecordTypeValue.TRADE_SKU.getTypeName()) >>
        Collections.emptyList()
    validatorsFactoryBr.getOrderItemValidators().addAll(new ProductInternalIdValidator(productRepo))
    when:
    OrderItemValidationResult result = service.validateOrderItem(orderItem,validatorContext)
    then:
    result.errorDescription.contains('Product & and Account must have the same Market ISO, Product must be defined as "Active"')
  }

  def "validate for existing order"() {
    given:
    order.herokuExternalId = "1234"
    order.purchaseOrderNumber = orderItem.poNumber
    orderFacade.findOrderForSapIdByPoNumber(_,_) >> Arrays.asList(new Order())
    validatorsFactoryBr.getOrderValidators().addAll(Arrays.asList(new PoNumberExtraConditionValidator(orderFacade)))
    when:
    OrderValidationResult result = service.validateOrderByOrderItem( Arrays.asList(orderItem))
    then:
    result.errorDescription.contains("already exists.")
  }

  def "validate for no OrderTmp with the given poNumber"() {
    given:
    LocalDate today = LocalDate.now().plusDays(1)
    orderItem.deliveryDate = today.format(DateUtils.LOCAL_DATE_FORMATTER)
    orderRepo.findByPurchaseOrderNumberAndStoreSapCustomerId(orderItem.poNumber,orderItem.sapCustomerId) >> Collections.emptyList()
    orderFacade.findOrderForSapIdByPoNumber(orderItem.poNumber,account.sapCustomerId) >> Collections.emptyList()
    accountRepo.findBySapCustomerId(orderItem.sapCustomerId) >> Optional.of(account)
    orderFacade.getOrderMaxDeliveryDate(LOCATION_HIERARCHY) >> Optional.empty()
    orderTmp.jobId = JOB_ID
    orderTmpFacade.getOrderTmpForPoNumberAndSapId(_,_) >> Optional.empty()
    validatorsFactoryBr.getOrderValidators().addAll(getOrderValidators())
    when:
    OrderValidationResult result = service.validateOrderByOrderItem( Arrays.asList(orderItem))
    then:
    result.valid
    result.exists
    result.needsUpdate
    result.order.poNumber == orderItem.poNumber
    result.order.deliveryDate == orderItem.deliveryDate
    result.errorDescription == null
  }

  def "validate order line with success"() {
    given:
    orderItem.productInternalId = '1112'
    orderItem.salesUomLow = "1"
    orderItem.salesUomHigh = "2"
    orderItem.herokuExternalId = "external_id"
    orderItem.accountMarketISO = ACCOUNT_ISO
    Product product = new Product()
    product.sfId = 'product_sfid'
    productRepo.findByInternalIdAndMarketISOAndActiveAndRecordTypeName(new BigInteger("1112"), ACCOUNT_ISO,'Yes',RecordTypeValue.TRADE_SKU.getTypeName()) >> Arrays.asList(product)
    validatorsFactoryBr.getOrderItemValidators().addAll(getOrderItemValidators())
    when:
    OrderItemValidationResult result = service.validateOrderItem(orderItem,validatorContext)

    then:
    result.valid
    result.errorDescription == null
    result.orderLineItem.herokuExternalId == orderItem.herokuExternalId
    result.orderLineItem.salesUomLow == '1'
    result.orderLineItem.salesUomHigh == '2'
  }


List<OrderValidator> getOrderValidators() {
  return Arrays.asList(
      new AccountValidator(accountRepo),
      new OrderTmpExistenceValidator(orderTmpFacade),
      //MandatoryFieldsValidator it could be removed here as we have the same validation
      new MandatoryFieldsValidator(),
      new PoNumberExtraConditionValidator(orderFacade),
      new DeliveryDateValidator(),
      new MaxDeliveryLeadTimeValidator(orderFacade)
  )
}

  List<OrderItemValidator> getOrderItemValidators(){
    return Arrays.asList(
        new com.bat.petra.commons.domain.orderitem.validation.validator.MandatoryFieldsValidator(),
        new ProductInternalIdValidator(productRepo),
        new PriceValidator()
    )
  }

}
