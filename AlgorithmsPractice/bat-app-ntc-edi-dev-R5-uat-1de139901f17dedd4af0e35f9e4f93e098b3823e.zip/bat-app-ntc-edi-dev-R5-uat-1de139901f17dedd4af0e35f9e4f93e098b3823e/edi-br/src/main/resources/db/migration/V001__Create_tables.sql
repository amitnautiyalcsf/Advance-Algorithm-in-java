--

create table salesforce.order_line_item_with_error
(
  id serial not null
    constraint order_line_item_with_error_pkey
      primary key,
  bulk_order_sfid varchar(18),
  error_desc varchar(2048),
  sap_customer_id varchar(64),
  delivery_date varchar(64),
  po_number varchar(64),
  product_internal_id varchar(64),
  sales_uom_high varchar(64),
  sales_uom_low varchar(64),
  order_type varchar(64),
  owner_id varchar(18),
  heroku_external_id varchar(50),
  job_id varchar(100)
);

create index ha_idx_order_line_item_with_error_jobid on salesforce.order_line_item_with_error (job_id);
create index ha_idx_order_line_item_with_error_herokuexternalid on salesforce.order_line_item_with_error (heroku_external_id);

--

create table salesforce.order_line_item__c__tmp
(
  product_alias__c varchar(18),
  manufacturing_sku__c varchar(18),
  name varchar(80),
  isdeleted boolean,
  systemmodstamp timestamp,
  ivydsd__uom_2_quantity__c INTEGER,
  ivydsd__uom_1_quantity__c INTEGER,
  createddate timestamp,
  ivydsd__product1__c varchar(18),
  ivydsd__order__c varchar(18),
  sfid varchar(18),
  id serial not null
    constraint ivydsd__order_line_item__c__tmp_pkey
    primary key,
  "_hc_lastop" varchar(32),
  "_hc_err" text,
  ivydsd__order__r__herokuexternalid__c varchar(50),
  migration_external_id__c varchar(50),
  product_internal_id varchar(255),
  ivydsd__line_item_type__c varchar(255)
);

create index ha_idx_order_line_item__c__tmp_ivydsdorderrherokuexternalid on salesforce.order_line_item__c__tmp (ivydsd__order__r__herokuexternalid__c);
create index ha_idx_order_line_item__c__tmp_ivydsdProduct1 on salesforce.order_line_item__c__tmp (ivydsd__Product1__c);

--

create table salesforce.order__c__tmp
(
  ship_to__c varchar(18),
  payer__c varchar(18),
  bill_to__c varchar(18),
  ivydsd__store__c varchar(18),
  ivydsd__price_list__c varchar(18),
  name varchar(80),
  job_id varchar(100),
  ivydsd__order_type__c varchar(255),
  ivydsd__order_status__c varchar(255),
  isdeleted boolean,
  systemmodstamp timestamp,
  ivydsd__delivery_date__c date,
  ivydsd__order_date__c date,
  ivydsd__purchase_order_number__c varchar(255),
  createddate timestamp,
  sfid varchar(18),
  market_iso__c varchar(18),
  id serial not null
    constraint ivydsd__order__c__tmp_pkey
    primary key,
  "_hc_lastop" varchar(32),
  "_hc_err" text,
  herokuexternalid__c varchar(50),
  ownerid varchar(18),
  instruction_id numeric
);

--

create unique index hau_idx_order__c__tmp_herokuexternalid on salesforce.order__c__tmp (herokuexternalid__c);
create index hau_idx_order__c__tmp_ivydsdpurchaseordernumber on salesforce.order__c__tmp (ivydsd__purchase_order_number__c);
create index ha_idx_order__c__tmp_ivydsdstore on salesforce.order__c__tmp (ivydsd__store__c);
create index ha_idx_order__c__tmp_ivydsddeliverydate on salesforce.order__c__tmp (ivydsd__delivery_date__c);
create index ha_idx_order__c__tmp_shipto on salesforce.order__c__tmp (ship_to__c);
create index ha_idx_order__c__tmp__jobid on salesforce.order__c__tmp (job_id);
create index ha_idx_order__c__tmp__instructionid on salesforce.order__c__tmp (instruction_id);

--

create table salesforce.order_payment_instructions__c__tmp
(
  credit_days__c numeric,
  payment_mode__c varchar(255),
  name varchar(80),
  isdeleted boolean,
  systemmodstamp timestamp,
  due_date__c date,
  payment_instruction_date__c date,
  split_percentage__c numeric,
  createddate timestamp,
  sfid varchar(18),
  id serial not null
    constraint order_payment_instructions__c__tmp_pkey
    primary key,
  "_hc_lastop" varchar(32),
  "_hc_err" text,
  ivydsd__order__r__herokuexternalid__c varchar(50)
);

create unique index hau_idx_order_payment_instructions__c__tmp_id on salesforce.order_payment_instructions__c__tmp (id);
