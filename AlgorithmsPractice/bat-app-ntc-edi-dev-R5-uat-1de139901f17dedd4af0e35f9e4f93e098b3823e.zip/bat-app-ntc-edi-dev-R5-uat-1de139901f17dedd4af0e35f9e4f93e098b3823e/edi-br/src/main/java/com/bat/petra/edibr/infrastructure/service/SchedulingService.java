package com.bat.petra.edibr.infrastructure.service;

import com.bat.petra.commons.domain.config.AzureFileConfigService;
import com.bat.petra.commons.domain.model.types.AzureFileStatus;
import com.bat.petra.commons.domain.model.BulkOrderUploadStatus;
import com.bat.petra.edibr.infrastructure.batch.steps.AzureFileService;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobInstance;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.JobParametersInvalidException;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.NoSuchJobException;
import org.springframework.batch.core.launch.NoSuchJobExecutionException;
import org.springframework.batch.core.repository.JobInstanceAlreadyCompleteException;
import org.springframework.batch.core.repository.JobRestartException;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author arkadiusz.wronski, created on 2019-02-08.
 */
@Service
@RequiredArgsConstructor
public class SchedulingService {
  private static final Logger LOGGER = LoggerFactory.getLogger(SchedulingService.class);

  private final AzureFileConfigService azureFileConfigService;

  private final JobLauncher jobLauncher;

  private final JobExplorer jobExplorer;

  private final JobOperator jobOperator;

  private final Job azureJob;

  private final AzureFileService azureFileService;

  private final OrderErrorService orderErrorService;

  @Scheduled(cron = "${worker.scheduling.job.cron}")
  public void processAzureFile() {
    LOGGER.info("Azure File processing job started");
    Long configId;
    while ((configId = azureFileConfigService.findNextAndUpdateStatus()) != null) {
      long processId = System.currentTimeMillis();
      LOGGER.info("--------------- PROCESS AZURE START processId " + processId + " ----------------");
      LOGGER.info("Downloading file for config id " + configId);
      try {
        String jobId = String.valueOf(System.currentTimeMillis());
        JobParameters params = new JobParametersBuilder()
            .addString("ID", jobId)
            .addLong("configId", configId)
            .toJobParameters();
        JobExecution execution = jobLauncher.run(azureJob, params);
/*        if (execution.getAllFailureExceptions().size()>0){
          markAsFailed(configId);
        } //PTX-25344 fix already does that */
        LOGGER.info("Job with id " + jobId + " ended with status " + execution.getStatus());
        long endMillis = System.currentTimeMillis();
        LOGGER.info("--------------- PROCESS AZURE STOP processId " + processId + "----------------");
        LOGGER.info("Time elapsed: " + TimeUnit.MILLISECONDS.toSeconds(endMillis - processId) + " seconds.");
      } catch (Exception ex) {
        LOGGER.info("Exception during azure file streaming ", ex);
      }
    }
  }

  @Scheduled(initialDelay = 10_000, fixedDelay = 3600_000)
  public void processUnfinishedAzureFile() {
    List<JobInstance> instances = jobExplorer.getJobInstances("persistFileFromAzure", 0, Integer.MAX_VALUE);
    for (JobInstance instance : instances) {
      List<JobExecution> persistFileFromAzure = jobExplorer.getJobExecutions(instance);
      for (JobExecution jobExecution : persistFileFromAzure) {
        if (Arrays.asList(BatchStatus.FAILED, BatchStatus.STOPPED).contains(jobExecution.getStatus())) {
          try {
            LOGGER.info("Retrying job with id {}", jobExecution.getJobId());
            jobOperator.restart(jobExecution.getJobId());
            LOGGER.info("Retrying job with id {} finished", jobExecution.getJobId());
          } catch (JobInstanceAlreadyCompleteException | JobParametersInvalidException | JobRestartException
              | NoSuchJobException | NoSuchJobExecutionException e) {
            LOGGER.error("Job retry failed", e);
          }
        }
      }
    }
  }
  @Scheduled(cron = "${worker.scheduling.deletejob.cron}")
  public void deleteFinishedFiles() {
    long processId = System.currentTimeMillis();
    LOGGER.info("--------------- DELETE JOB START processId " + processId + " ----------------");
    Map<String, List<BulkOrderUploadStatus>> filesToDeleteMap = azureFileConfigService
        .findAllWithStatus(AzureFileStatus.FINISHED.getStatusName()).stream().
            collect(Collectors.groupingBy(BulkOrderUploadStatus::getUploadedUrl));
    ExecutorService executorService = Executors.newFixedThreadPool(filesToDeleteMap.size());
    filesToDeleteMap.entrySet().
        forEach((entry) -> executorService.submit(() -> azureFileService.deleteFiles(entry.getValue())));
    long endMillis = System.currentTimeMillis();
    LOGGER.info("Time elapsed: " + TimeUnit.MILLISECONDS.toSeconds(endMillis - processId) + " seconds.");
    LOGGER.info("--------------- DELETE JOB STOP processId " + processId + "----------------");
  }

}
