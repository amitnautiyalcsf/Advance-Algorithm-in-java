package com.bat.petra.edibr.domain.orderlinetmp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-03-14.
 */
@Repository
public interface OrderLineHerokuTmpRepo extends JpaRepository<OrderLineHerokuTmp, Long> {
  List<OrderLineHerokuTmp> findAllByOrderHerokuExternalId(String orderExternalId);

  @Query(value = "select oLHT from OrderLineHerokuTmp oLHT join fetch oLHT.product where oLHT.orderHerokuExternalId = ?1 ")
  List<OrderLineHerokuTmp> findAllByOrderHerokuExternalIdFetchProduct(String orderExternalId);

}
