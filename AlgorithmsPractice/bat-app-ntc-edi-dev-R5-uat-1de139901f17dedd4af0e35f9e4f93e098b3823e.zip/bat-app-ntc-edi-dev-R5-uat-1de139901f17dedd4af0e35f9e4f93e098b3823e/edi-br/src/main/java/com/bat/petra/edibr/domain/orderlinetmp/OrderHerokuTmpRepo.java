package com.bat.petra.edibr.domain.orderlinetmp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import javax.transaction.Transactional;
import java.time.LocalDate;
import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-03-14.
 */
@Repository
@Transactional
public interface OrderHerokuTmpRepo extends JpaRepository<OrderHerokuTmp, Long> {
  Optional<OrderHerokuTmp> findByHerokuExternalId(String herokuExternalId);
  Optional<OrderHerokuTmp> findByPurchaseOrderNumberAndStoreSapCustomerId(String poNumber, String sapCustomerId);
  Optional<OrderHerokuTmp> findByDeliveryDateAndStoreSapCustomerId(LocalDate deliveryDate, String sapCustomerId);
  Optional<OrderHerokuTmp> findByShipToSfId(String accountSfId);

}
