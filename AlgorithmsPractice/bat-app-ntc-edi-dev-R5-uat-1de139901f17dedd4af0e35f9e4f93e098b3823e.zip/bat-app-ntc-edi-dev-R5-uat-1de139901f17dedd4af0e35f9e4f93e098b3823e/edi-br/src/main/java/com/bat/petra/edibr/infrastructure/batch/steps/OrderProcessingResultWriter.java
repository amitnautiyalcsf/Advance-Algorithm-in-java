package com.bat.petra.edibr.infrastructure.batch.steps;


import com.bat.petra.commons.domain.config.BulkOrderUploadStatusRepo;
import com.bat.petra.commons.domain.model.BulkOrderUploadStatus;
import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.OrderItemProcessor;
import com.bat.petra.commons.domain.orderitem.ProcessorHolder;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.edibr.domain.orderitem.OrderItemTmpFactory;
import com.bat.petra.edibr.domain.orderitemerror.OrderLineItemWithError;
import com.bat.petra.edibr.domain.orderitemerror.OrderLineItemWithErrorRepo;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmpRepo;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmpRepo;
import com.bat.petra.commons.utils.OrderItemUtils;
import com.bat.petra.edibr.domain.ordertmp.service.OrderTmpFacade;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
@StepScope
public class OrderProcessingResultWriter implements ItemWriter<OrderItem> {
  private static final Logger LOGGER = LoggerFactory.getLogger(OrderProcessingResultWriter.class);

  private static final String CONFIG_ID_PARAMETER = "configId";
  private static final String BULK_ORDER_SFID_PARAMETER = "bulkOrderSfid";
  private static final String OWNER_ID_PARAMETER = "ownerId";
  private static final String ORDER_TYPE_PARAMETER = "orderType";
  private static final String ORDER_UPLOAD_DATE_PARAMETER = "orderUploadDate";
  private static final String JOB_ID_PARAMETER = "ID";

  @Autowired
  private BulkOrderUploadStatusRepo azureFileConfigRepo;
  @Autowired
  private OrderItemProcessor itemProcessor;
  @Autowired
  private OrderLineItemWithErrorRepo orderLineItemWithErrorRepo;
  @Autowired
  private OrderLineHerokuTmpRepo orderLineTmpItemRepo;
  @Autowired
  private OrderTmpFacade orderTmpFacade;
  @Autowired
  private OrderItemTmpFactory orderItemTmpFactory;

  @Value("#{stepExecution}")
  private StepExecution stepExecution;


  @Override
  @Transactional
  public void write(List<? extends OrderItem> items) throws Exception {
    if (!items.isEmpty()) {
      ProcessorHolder processorHolder = new ProcessorHolder();
      List<List<OrderItem>> ordersWithLines = OrderItemUtils.createOrdersListsGroupedBySapId(items);
      ordersWithLines.stream().flatMap(Collection::stream).forEach(item -> setupOrderAdditionalParams(item));
      LOGGER.info("Start writing package "+items.size()+" items, for job "+stepExecution.getJobParameters().getString(JOB_ID_PARAMETER));
      List<ProcessorHolder.ResultHolder> futures = itemProcessor.processOrderItemOrder(ordersWithLines);

      ProcessorHolder.ProcessingState state = processorHolder.new ProcessingState();
      List<ProcessorHolder.OrderLineResultHolder> orderLinesFutures = itemProcessor.processOrderItemLines(futures, state);
      itemProcessor.processValidOrders(orderLinesFutures, state);

      if (!state.getOrderLineItemWithErrors().isEmpty() && !stepExecution.getExecutionContext().containsKey("containsErrors")) {
        stepExecution.getExecutionContext().putString("containsErrors", "true");
      }
      updateOrderStatus(state.getOrderWithStatus());
      persistValidationResult(state);
    }
  }

  private void updateOrderStatus(Map<String,String> orderWithStatus) {
    orderWithStatus.entrySet().forEach(entry ->
        orderTmpFacade.updateOrderStatus(entry.getKey(),entry.getValue()));
  }

  private void persistValidationResult(ProcessorHolder.ProcessingState state) {
    orderTmpFacade.saveAllOrders(createOrders(new ArrayList<>(state.getOrders().values())));
    orderLineTmpItemRepo.saveAll(createOrderLines(state));
    orderLineItemWithErrorRepo.saveAll((List<OrderLineItemWithError>)state.getOrderLineItemWithErrors());
  }

  private List<OrderLineHerokuTmp> createOrderLines(ProcessorHolder.ProcessingState state) {
    List<OrderLineHerokuTmp> linesTmp = new ArrayList<>();
    Map<String,List<OrderItem>> orderLines = state.getOrderLineItems();
    orderLines.entrySet().stream().forEach(entry->{
      String externalId = entry.getKey();
      OrderItemValidationContext context = state.getOrders().get(externalId).getContext();
      entry.getValue().forEach(lineTmp ->linesTmp.add(orderItemTmpFactory.createOrderLineTmp(lineTmp,context)));
    });
    return linesTmp;
  }

  private List<OrderHerokuTmp> createOrders(List<OrderValidationResult> ordersWithContext) {
    List<OrderHerokuTmp> orderTmp = new ArrayList<>();
    ordersWithContext.stream().forEach(result ->
        orderTmp.add(orderItemTmpFactory.createOrderTmp(result.getOrder(),result.getContext()))
    );
    return orderTmp;
  }


  private void setupOrderAdditionalParams(OrderItem item) {
    item.setJobId(stepExecution.getJobParameters().getString(JOB_ID_PARAMETER));
    item.setOrderType(getJobStringParameter(ORDER_TYPE_PARAMETER));
    item.setOrderUploadDate(LocalDateTime.parse(getJobStringParameter(ORDER_UPLOAD_DATE_PARAMETER)).toLocalDate());
    item.setOwnerId(getJobStringParameter(OWNER_ID_PARAMETER));
    item.setBulkOrderSfid(getJobStringParameter(BULK_ORDER_SFID_PARAMETER));
  }

  private String getJobStringParameter(String paramName) {
    String paramValue = Optional.ofNullable(stepExecution.getJobExecution().getExecutionContext().get(paramName))
        .orElse("").toString();
    if (StringUtils.isEmpty(paramValue)) {
      setupJobAdditionalParams();
      paramValue = Optional.ofNullable(stepExecution.getJobExecution().getExecutionContext().get(paramName))
          .orElse("").toString();
    }
    return paramValue;
  }

  private void setupJobAdditionalParams() {
    Long configId = stepExecution.getJobParameters().getLong(CONFIG_ID_PARAMETER);
    BulkOrderUploadStatus azureFileConfig = azureFileConfigRepo.findById(configId)
        .orElseThrow(() -> new IllegalStateException("No config with id " + configId));
    String orderType = azureFileConfig.getType();
    String orderUploadDate = azureFileConfig.getCreatedDate().toString();
    String bulkOrderSfid = azureFileConfig.getSfId();
    String ownerId = azureFileConfig.getOwnerId();
    stepExecution.getJobExecution().getExecutionContext()
        .put(ORDER_TYPE_PARAMETER, new JobParameter(orderType));
    stepExecution.getJobExecution().getExecutionContext()
        .put(ORDER_UPLOAD_DATE_PARAMETER, new JobParameter(orderUploadDate));
    stepExecution.getJobExecution().getExecutionContext()
        .put(BULK_ORDER_SFID_PARAMETER, new JobParameter(bulkOrderSfid));
    stepExecution.getJobExecution().getExecutionContext()
        .put(OWNER_ID_PARAMETER, new JobParameter(ownerId));
  }
}
