package com.bat.petra.edibr.infrastructure.batch.steps;

import com.bat.petra.commons.domain.model.Account;
import com.bat.petra.commons.domain.model.BulkOrderUploadStatus;
import com.bat.petra.edibr.domain.orderitemerror.OrderLineItemWithError;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmpRepo;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmpRepo;
import com.bat.petra.commons.utils.DateUtils;
import com.bat.petra.edibr.infrastructure.batch.config.CsvFileConfig;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author arkadiusz.wronski, created on 2019-05-29.
 */
@Component
@StepScope
public class OrderTmpErrorProcessingResultWriter implements ItemWriter<OrderLineItemWithError> {
  private static final Logger LOGGER = LoggerFactory.getLogger(OrderTmpErrorProcessingResultWriter.class);
  private static final String ERROR_COLUMN_NAME = "ERROR MESSAGE";
  @Autowired
  private OrderLineHerokuTmpRepo orderLineHerokuTmpRepo;
  @Autowired
  private OrderHerokuTmpRepo orderHerokuTmpRepo;
  @Autowired
  private CsvFileConfig csvFileConfig;
  @Autowired
  private AzureFileService azureService;
  @Value("#{stepExecution}")
  private StepExecution stepExecution;

  @Override
  public void write(List<? extends OrderLineItemWithError> invalidOrders) throws Exception {
    Long bulkOrderId = stepExecution.getJobParameters().getLong("configId");
    azureService.uploadFileToAzure(getCSVErrorStream(invalidOrders),bulkOrderId)
        .ifPresent(result -> updateBulkConfiguration(bulkOrderId, result));
  }

  private void updateBulkConfiguration(long configId, BulkOrderUploadStatus uploadingResult) {
    azureService.updateBulkUploadConfig(configId, uploadingResult);
  }

  private ByteArrayOutputStream getCSVErrorStream(List<? extends OrderLineItemWithError> allErrorLines) throws IOException {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    baos.write(getColumnNames().getBytes(Charset.forName("UTF-8")));
    Map<String,List<OrderLineItemWithError>> ordersWithErrorLines = allErrorLines.stream()
        .collect(Collectors.groupingBy(order -> Optional.ofNullable(order.getHerokuExternalId()).orElse("")));

    ordersWithErrorLines.entrySet().forEach( entry -> {
      String orderHerokuExternalId = entry.getKey();
      if(StringUtils.isNotEmpty(orderHerokuExternalId)){
        processExistingOrders(baos, entry, orderHerokuExternalId);
      }else{
        createCsvLineFromErrorLines(baos, entry.getValue());
      }
    });
    return baos;
  }

  private void createCsvLineFromErrorLines(ByteArrayOutputStream baos, List<OrderLineItemWithError> errorLines) {
    errorLines.forEach(errorLine -> {
      try {
        baos.write(generateLineFromOrderLineError(errorLine).getBytes(Charset.forName("UTF-8")));
      } catch (IOException e) {
        LOGGER.warn("Exception during error file generation: " + e.getLocalizedMessage());
      }
    });
  }

  private void processExistingOrders(ByteArrayOutputStream baos, Map.Entry<String, List<OrderLineItemWithError>> entry, String orderHerokuExternalId) {
    OrderHerokuTmp order = orderHerokuTmpRepo.findByHerokuExternalId(orderHerokuExternalId)
        .orElseThrow(()-> new IllegalStateException("No Order Tmp with herokuExternalId "+orderHerokuExternalId));
    createCsvLinesFromOrderLineTmps(baos, order,
        orderLineHerokuTmpRepo.findAllByOrderHerokuExternalIdFetchProduct(orderHerokuExternalId));
    createCsvLineFromErrorLines(baos, entry.getValue());
  }

  private void createCsvLinesFromOrderLineTmps(ByteArrayOutputStream baos, OrderHerokuTmp order, List<OrderLineHerokuTmp> linesTmp) {
    linesTmp.forEach(line -> {
      try {
        baos.write(generateLineFromOrderLineTmp(order, line).getBytes(Charset.forName("UTF-8")));
      }catch (IOException e){LOGGER.warn("Exception during error file generation: "+e.getLocalizedMessage());}
    });
  }

  private String getColumnNames() {
    String columnNames = String.join(",",csvFileConfig.getColumnNames());
    return columnNames +","+ERROR_COLUMN_NAME+"\n";
  }

  private String generateLineFromOrderLineTmp(OrderHerokuTmp order, OrderLineHerokuTmp orderLine){
    Account shipTo = order.getShipTo();
    StringBuilder sb = new StringBuilder(shipTo.getSapCustomerId());
    sb.append(",").append(DateUtils.formatDate(order.getDeliveryDate())).append(",").append(order.getPurchaseOrderNumber()).append(",")
        .append(orderLine.getProduct().getInternalId().toString()).append(",").append(orderLine.getUom2price())
        .append(",").append(orderLine.getUom1price()).append(",\n");
    return sb.toString().replaceAll("null","");
  }

  private String generateLineFromOrderLineError(OrderLineItemWithError errorLine){
    StringBuilder sb = new StringBuilder(errorLine.getSapCustomerId());
    sb.append(",").append(errorLine.getDeliveryDate()).append(",").append(errorLine.getPoNumber()).append(",")
        .append(errorLine.getProductInternalId()).append(",").append(errorLine.getSalesUomHigh())
        .append(",").append(errorLine.getSalesUomLow()).append(",").append(errorLine.getErrorDesc()).append("\n");
    return sb.toString().replaceAll("null","");
  }
}
