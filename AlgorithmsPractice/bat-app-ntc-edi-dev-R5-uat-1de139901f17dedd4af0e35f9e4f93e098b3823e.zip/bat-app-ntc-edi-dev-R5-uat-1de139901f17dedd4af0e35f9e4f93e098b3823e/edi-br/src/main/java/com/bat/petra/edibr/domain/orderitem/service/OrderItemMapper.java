package com.bat.petra.edibr.domain.orderitem.service;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.edibr.domain.orderitemerror.OrderLineItemWithError;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmp;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * @author arkadiusz.wronski, created on 2019-07-01.
 */
@Mapper
public interface OrderItemMapper {

  OrderItemMapper MAPPER = Mappers.getMapper(OrderItemMapper.class);

  @Mapping(source = "errorMsg", target = "errorDesc")
  OrderLineItemWithError mapOrderLineItemToError(OrderItem orderLineItem);

  @Mapping(source = "herokuExternalId", target = "orderHerokuExternalId")
  @Mapping(source = "orderType", target = "lineItemType")
  OrderLineHerokuTmp mapOrderItemToOrderLineTmp(OrderItem orderItem);

}
