package com.bat.petra.edibr.domain.orderlinetmp;

import com.bat.petra.commons.domain.model.OrderLineItem;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * @author arkadiusz.wronski, created on 2019-06-24.
 */
@Mapper
public interface OrderLineTmpMapper {
  OrderLineTmpMapper MAPPER = Mappers.getMapper(OrderLineTmpMapper.class);

  @Mapping(target = "id", ignore = true)
  OrderLineItem mapOrderLineTmpToOrderLine(OrderLineHerokuTmp tmpLine);
}
