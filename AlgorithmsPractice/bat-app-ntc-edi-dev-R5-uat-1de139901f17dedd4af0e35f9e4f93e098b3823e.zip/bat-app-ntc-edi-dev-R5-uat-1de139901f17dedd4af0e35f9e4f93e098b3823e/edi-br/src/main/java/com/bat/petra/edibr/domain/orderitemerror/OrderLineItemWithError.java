package com.bat.petra.edibr.domain.orderitemerror;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author arkadiusz.wronski, created on 2019-07-01.
 */
@Entity
@Table(name = "order_line_item_with_error", schema = "salesforce")
@Data
@ToString(callSuper = true)
public class OrderLineItemWithError extends OrderItem {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @Column(name = "error_desc")
  private String errorDesc;
}

