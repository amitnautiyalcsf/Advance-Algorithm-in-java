package com.bat.petra.edibr.domain.ordertmp.service;

import com.bat.petra.commons.domain.model.OrderPaymentInstructions;
import com.bat.petra.edibr.domain.orderlinetmp.OrderPaymentInstructionsTmp;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author arkadiusz.wronski, created on 2019-07-02.
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface OrderInstructionsTmpMapper {
  OrderInstructionsTmpMapper INSTANCE = Mappers.getMapper(OrderInstructionsTmpMapper.class);

  @Mapping(target = "id", ignore = true)
  OrderPaymentInstructions mapInstructionsTmpToInstructions(OrderPaymentInstructionsTmp instructionsTmp);
}
