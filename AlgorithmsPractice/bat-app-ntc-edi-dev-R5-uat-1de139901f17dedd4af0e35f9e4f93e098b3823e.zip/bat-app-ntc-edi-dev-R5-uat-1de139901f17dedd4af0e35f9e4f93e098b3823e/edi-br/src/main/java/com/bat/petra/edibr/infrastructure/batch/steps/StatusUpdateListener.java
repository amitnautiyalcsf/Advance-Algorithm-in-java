package com.bat.petra.edibr.infrastructure.batch.steps;

import com.bat.petra.commons.domain.config.BulkOrderUploadStatusRepo;
import com.bat.petra.commons.domain.model.BulkOrderUploadStatus;
import com.bat.petra.commons.domain.model.types.AzureFileStatus;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.Optional;

@Component
public class StatusUpdateListener implements StepExecutionListener {

  @Autowired
  private BulkOrderUploadStatusRepo azureFileConfigRepo;

  @Override
  public void beforeStep(StepExecution stepExecution) {

  }

  @Override
  @Transactional
  public ExitStatus afterStep(StepExecution stepExecution) {
    Long configId = stepExecution.getJobParameters().getLong("configId");
    boolean containsErrors = stepExecution.getExecutionContext().containsKey("containsErrors");
    Optional<BulkOrderUploadStatus> azureFileConfig = azureFileConfigRepo.findById(configId);
    azureFileConfig.ifPresent(config -> config.setStatus(containsErrors
        ? AzureFileStatus.FAILED.getStatusName() : AzureFileStatus.FINISHED.getStatusName()));
    return null;
  }
}
