package com.bat.petra.edibr.domain.order.validation.validator;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.order.validation.OrderValidator;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmp;
import com.bat.petra.edibr.domain.ordertmp.service.OrderTmpFacade;
import com.bat.petra.edibr.domain.ordertmp.service.OrderTmpMapper;

import java.util.Map;
import java.util.Optional;

import static com.bat.petra.commons.domain.order.validation.OrderValidationResult.withError;

/**
 * @author arkadiusz.wronski, created on 2019-06-14.
 */
public class OrderTmpExistenceValidator implements OrderValidator {

  private OrderTmpFacade orderTmpFacade;

  public OrderTmpExistenceValidator(OrderTmpFacade orderFacade){
    this.orderTmpFacade = orderFacade;
  }

  @Override
  public OrderValidationResult validateOrder(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    try{
    Map<String,Object> params = context.getValidationParams();
    return checkIfOrderTmpExists(orderItem, params.get(OrderItemValidationObject.SAP_CUSTOMER_ID.name()).toString(),
        params.get(OrderItemValidationObject.ACCOUNT_SF_ID.name()).toString(), params.get(OrderItemValidationObject.JOB_ID.name()).toString());
    }catch (NullPointerException e){
      throw new OrderItemValidationException("Has not found validation param with name "+ OrderItemValidationObject.SAP_CUSTOMER_ID.name()
          +", "+ OrderItemValidationObject.ACCOUNT_SF_ID.name()+" or "+ OrderItemValidationObject.JOB_ID.name()+"\n"+e.getLocalizedMessage());
    }catch (Exception e){
      throw new OrderItemValidationException(e.getLocalizedMessage());
    }
  }

  private OrderValidationResult checkIfOrderTmpExists(OrderItem item, String sapCustomerId,
                                                      String accountSfId, String jobId){
    Optional<OrderHerokuTmp> existingOrder;
    if(item.hasPoNumber()){
      existingOrder = orderTmpFacade.getOrderTmpForPoNumberAndSapId(item.getPoNumber(), sapCustomerId);
    } else if (item.hasDeliveryDate()){
      existingOrder = orderTmpFacade.findOrderTmpForDateAndSapId(item.getDeliveryDate(), sapCustomerId);
    } else {
      existingOrder = orderTmpFacade.findByAccountSfId(accountSfId);
    }

    if(existingOrder.isPresent()){
      if(!existingOrder.get().getJobId().equals(jobId)){
        return withError("Order, sapCustomerId: "+ item.getSapCustomerId()+", PO_NUMBER:"+item.getPoNumber()+", deliveryDate: "+
            item.getDeliveryDate()+" is already registered with different file.");
      } else {
        return OrderValidationResult.builder()
            .exists(true)
            .needsUpdate(true)
            .order(OrderTmpMapper.INSTANCE.mapOrderTmpToOrderItem(existingOrder.get()))
            .valid(true)
            .build();
      }
    }
    return OrderValidationResult.builder().valid(true).exists(false).build();
  }
}
