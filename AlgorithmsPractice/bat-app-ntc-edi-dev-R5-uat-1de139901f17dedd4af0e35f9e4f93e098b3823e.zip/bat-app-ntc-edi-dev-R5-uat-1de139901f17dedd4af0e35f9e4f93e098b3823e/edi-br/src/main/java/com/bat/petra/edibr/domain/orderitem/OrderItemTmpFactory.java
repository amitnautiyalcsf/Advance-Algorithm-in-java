package com.bat.petra.edibr.domain.orderitem;

import com.bat.petra.commons.domain.orderitem.repository.CreditDetailsRepo;
import com.bat.petra.commons.domain.model.Account;
import com.bat.petra.commons.domain.model.Product;
import com.bat.petra.commons.domain.model.types.OrderItemStatus;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.utils.DateUtils;
import com.bat.petra.edibr.domain.orderitem.service.OrderItemMapperSrv;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderPaymentInstructionsTmp;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.UUID;

/**
 * @author arkadiusz.wronski, created on 2019-06-27.
 */
@Service
@Log4j2
@RequiredArgsConstructor
public class OrderItemTmpFactory{

  private final CreditDetailsRepo creditDetailsRepo;
  private final OrderItemMapperSrv orderItemMapperSrv;

  public OrderHerokuTmp createOrderTmp(OrderItem orderItem, OrderItemValidationContext context) {
    OrderHerokuTmp order = null;
    try {
      Account account = (Account) context.getValidationParams().get(OrderItemValidationObject.MAIN_ACCOUNT.name());
      Object status = context.getValidationParams().get(OrderItemValidationObject.ORDER_STATUS.name());
      order = createTmpOrder(orderItem,account, status);
    }catch(NullPointerException ex){
      log.warn("Has not found validation param "+OrderItemValidationObject.MAIN_ACCOUNT.name());
      ex.printStackTrace();
    }
    return order;
  }

  public OrderLineHerokuTmp createOrderLineTmp(OrderItem orderItem, OrderItemValidationContext context) {
    OrderLineHerokuTmp line = null;
    try {
      Product product = (Product) context.getValidationParams().get(OrderItemValidationObject.PRODUCT.name()+"_"+orderItem.getProductInternalId());
      line = createOrderLineTmp(orderItem,product);
    }catch (NullPointerException ex){
      log.warn("Has not found validation param "+OrderItemValidationObject.PRODUCT.name());
    }
    return line;
  }

  private OrderHerokuTmp createTmpOrder(OrderItem item, Account account, Object status) {
    OrderHerokuTmp orderTmp = new OrderHerokuTmp();
    orderTmp.setDeliveryDate(DateUtils.parseLocalDate(item.getDeliveryDate()));
    orderTmp.setPurchaseOrderNumber(item.getPoNumber());
    orderTmp.setOrderType(item.getOrderType());
    orderTmp.setStore(account);
    orderTmp.setShipTo(account);
    orderTmp.setPayer(account);
    orderTmp.setBillTo(account);
    orderTmp.setHerokuExternalId(item.getHerokuExternalId());
    orderTmp.setStatus(null!=status?status.toString():OrderItemStatus.COMPLETED.getStatusName());
    orderTmp.setOwnerId(item.getOwnerId());
    orderTmp.setMarketISO(account.getMarketISO());
    orderTmp.setJobId(item.getJobId());
    orderTmp.setOrderUploadDate(item.getOrderUploadDate());
    OrderPaymentInstructionsTmp instructions = createOrderInstruction(item, account);
    instructions.setOrderTmp(orderTmp);
    orderTmp.setPaymentInstructions(instructions);
    return orderTmp;
  }

  private OrderPaymentInstructionsTmp createOrderInstruction(OrderItem item, Account account) {
    OrderPaymentInstructionsTmp instructions = new OrderPaymentInstructionsTmp();
    creditDetailsRepo.findFirstByAccountSfIdOrderByCreatedDateDesc(account.getSfId())
        .ifPresent(creditDetails ->
            instructions.setCreditDays(creditDetails.getBaseCreditDays() != null ? creditDetails.getBaseCreditDays() : BigInteger.ZERO)
        );
    instructions.setDueDate(DateUtils.addDaysToDate
        (item.getDeliveryDate(), instructions.getCreditDays() != null ? instructions.getCreditDays().longValue() : 0));
    instructions.setPaymentMode(account.getDefaultPaymentMethod());
    instructions.setPaymentInstructionDate(item.getOrderUploadDate());
    instructions.setSplitPercentage(BigInteger.valueOf(100));
    return instructions;
  }

  private OrderLineHerokuTmp createOrderLineTmp(OrderItem item, Product product) {
    OrderLineHerokuTmp orderLineItem = orderItemMapperSrv.mapOrderItemToOrderLineTmp(item);
    orderLineItem.setUom2price(StringUtils.isNotEmpty(item.getSalesUomHigh()) ? new BigInteger(item.getSalesUomHigh()) : null);
    orderLineItem.setUom1price(StringUtils.isNotEmpty(item.getSalesUomLow()) ? new BigInteger(item.getSalesUomLow()) : null);
    orderLineItem.setMigrationExternalId(UUID.randomUUID().toString());
    orderLineItem.setProduct(product);
    return orderLineItem;
  }
}
