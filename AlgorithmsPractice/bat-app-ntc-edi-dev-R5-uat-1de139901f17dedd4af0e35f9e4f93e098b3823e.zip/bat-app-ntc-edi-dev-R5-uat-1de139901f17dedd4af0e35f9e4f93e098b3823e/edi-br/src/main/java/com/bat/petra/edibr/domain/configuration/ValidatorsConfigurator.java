package com.bat.petra.edibr.domain.configuration;

import com.bat.petra.commons.domain.order.repository.AccountRepository;
import com.bat.petra.edibr.domain.order.validation.validator.OrderTmpExistenceValidator;
import com.bat.petra.commons.domain.orderitem.repository.ProductRepo;
import com.bat.petra.commons.domain.order.service.OrderFacade;
import com.bat.petra.commons.domain.orderitem.validation.ValidatorsFactory;
import com.bat.petra.commons.domain.order.validation.validator.AccountValidator;
import com.bat.petra.commons.domain.order.validation.validator.DeliveryDateValidator;
import com.bat.petra.commons.domain.order.validation.validator.MandatoryFieldsValidator;
import com.bat.petra.commons.domain.order.validation.validator.MaxDeliveryLeadTimeValidator;
import com.bat.petra.commons.domain.order.validation.validator.PoNumberExtraConditionValidator;
import com.bat.petra.edibr.domain.orderitem.validation.validator.MultipleSKUValidatorBR;
import com.bat.petra.commons.domain.orderitem.validation.validator.PriceValidator;
import com.bat.petra.commons.domain.orderitem.validation.validator.ProductInternalIdValidator;
import com.bat.petra.commons.utils.DateUtils;
import com.bat.petra.edibr.domain.ordertmp.service.OrderTmpFacade;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.Arrays;

/**
 * @author arkadiusz.wronski, created on 2019-06-25.
 */
@Configuration
public class ValidatorsConfigurator {
  @Autowired
  AccountRepository accountRepository;
  @Autowired
  OrderFacade orderFacade;
  @Autowired
  OrderTmpFacade orderTmpFacade;
  @Autowired
  ProductRepo productRepo;

  @PostConstruct
  public void init(){
    DateUtils.initDateDateFormatter(DateUtils.DateFormat.BRAZIL.getStringPattern());
  }

  @Bean
  public ValidatorsFactory brazilOrderItemValidatorsFactory(){
    ValidatorsFactory factoryBr = new ValidatorsFactoryBr();
    initOrderItemValidators(factoryBr);
    initOrderValidators(factoryBr);
    initOrderItemListValidators(factoryBr);
    return factoryBr;
  }

  private void initOrderItemListValidators(ValidatorsFactory factoryBr) {
    factoryBr.getOrderItemListValidators().addAll(Arrays.asList(new MultipleSKUValidatorBR()));
  }

  private void initOrderValidators(ValidatorsFactory factoryBr) {
    factoryBr.getOrderValidators().addAll(Arrays.asList(
        new AccountValidator(accountRepository),
        new OrderTmpExistenceValidator(orderTmpFacade),
        //MandatoryFieldsValidator it could be removed here as we have the same validation
        new MandatoryFieldsValidator(),
        new PoNumberExtraConditionValidator(orderFacade),
        new DeliveryDateValidator(),
        new MaxDeliveryLeadTimeValidator(orderFacade)
    ));
  }

  private void initOrderItemValidators(ValidatorsFactory factoryBr) {
    factoryBr.getOrderItemValidators().addAll(Arrays.asList(
        new com.bat.petra.commons.domain.orderitem.validation.validator.MandatoryFieldsValidator(),
        new ProductInternalIdValidator(productRepo),
        new PriceValidator()
    ));
  }
}
