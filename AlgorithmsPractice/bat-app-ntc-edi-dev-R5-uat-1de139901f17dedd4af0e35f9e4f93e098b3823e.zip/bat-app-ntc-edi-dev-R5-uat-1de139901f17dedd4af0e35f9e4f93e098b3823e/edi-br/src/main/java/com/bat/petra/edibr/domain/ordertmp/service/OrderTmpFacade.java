package com.bat.petra.edibr.domain.ordertmp.service;

import com.bat.petra.commons.utils.DateUtils;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmpRepo;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-07-02.
 */
@Service
@RequiredArgsConstructor
@Log4j2
public class OrderTmpFacade {
  private final OrderHerokuTmpRepo orderHerokuTmpRepo;
  public Optional<OrderHerokuTmp> getOrderTmpForPoNumberAndSapId(String poNumber, String sapId) {
    return orderHerokuTmpRepo.findByPurchaseOrderNumberAndStoreSapCustomerId(poNumber, sapId);
  }

  public Optional<OrderHerokuTmp> findOrderTmpForDateAndSapId(String deliveryDate, String sapId) {
    return orderHerokuTmpRepo.findByDeliveryDateAndStoreSapCustomerId(DateUtils.parseLocalDate(deliveryDate), sapId);
  }
  public Optional<OrderHerokuTmp> findByAccountSfId(String sfId){
    return orderHerokuTmpRepo.findByShipToSfId(sfId);
  }

  public void saveAllOrders(List<OrderHerokuTmp> orders){
    log.info("Saving tmp orders with size "+orders.size());
    orderHerokuTmpRepo.saveAll(orders);
  }

  @Transactional
  public void updateOrderStatus(String externalId, String status){
    log.info("Updating order "+externalId+" status "+status);
    Optional<OrderHerokuTmp> existed = orderHerokuTmpRepo.findByHerokuExternalId(externalId);
    existed.ifPresent(order -> order.setStatus(status));
  }

}
