package com.bat.petra.edibr.infrastructure.batch.steps;


import com.bat.petra.commons.domain.config.BulkOrderUploadStatusRepo;
import com.bat.petra.commons.domain.config.EndMarketConfigurationService;
import com.bat.petra.commons.domain.model.BulkOrderUploadStatus;
import com.bat.petra.commons.domain.model.EndMarketConfiguration;
import com.bat.petra.commons.domain.model.types.AzureFileType;
import com.bat.petra.commons.domain.model.types.MarketISO;
import com.bat.petra.commons.domain.model.types.RecordTypeValue;
import com.bat.petra.commons.utils.BlobStorageUtils;
import com.bat.petra.commons.utils.FilenameUtils;
import com.bat.petra.commons.domain.config.AzureFileConfigService;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlob;
import com.microsoft.azure.storage.blob.CloudBlobContainer;
import lombok.RequiredArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.security.InvalidKeyException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.zip.ZipInputStream;

@Component
@RequiredArgsConstructor
public class AzureFileService {
  private static final Logger LOGGER  = LoggerFactory.getLogger(AzureFileService.class);

  private final BulkOrderUploadStatusRepo azureFileConfigRepo;

  private final EndMarketConfigurationService endMarketConfigurationSrv;

  private final AzureFileConfigService azureFileConfigService;

  public InputStream downloadFile(Long configId) {
    try {
      return downloadFile(azureFileConfigRepo.findById(configId)
          .orElseThrow(() -> new IllegalStateException("No config with id " + configId)));
    } catch (Exception e) {
      throw new IllegalStateException(e);
    }
  }

  public void deleteFiles (List<BulkOrderUploadStatus> filesToDelete){
    String blobEndpoint = filesToDelete.get(0).getUploadedUrl();
    LOGGER.info("Deleting files for blob: "+blobEndpoint + " files size: "+filesToDelete.size());
    EndMarketConfiguration configuration = getEndMarketConfiguration();
    try {
      CloudBlobContainer container = BlobStorageUtils.
          getCloudBlobContainer(configuration.getConnectionString(), filesToDelete.get(0).getContainerName());
      filesToDelete.stream().filter(file -> !StringUtils.isEmpty(file.getFilePath()))
          .forEach(fileToDelete -> {
            LOGGER.info("Deleting file " + fileToDelete.getFilePath());
            try {
              CloudBlob azureFile = container.getAppendBlobReference(fileToDelete.getFilePath());
              boolean deleted = azureFile.deleteIfExists();
              if (deleted) {
                LOGGER.info("Deleted successfully, changing status");
                azureFileConfigService.updateDeletedFileStatus(fileToDelete.getId());
              } else {
                LOGGER.info("File in path "+fileToDelete.getFilePath()+" could not be deleted successfully.");
              }
            }catch (Exception e){ LOGGER.warn("Azure storage exception: "+e.getLocalizedMessage());}
          });
    }catch (Exception e){ throw  new IllegalStateException(e);}
    LOGGER.info("Deleting process for "+blobEndpoint + " finished.");
  }

  public Optional<BulkOrderUploadStatus> uploadFileToAzure(ByteArrayOutputStream file, Long configId) {
    EndMarketConfiguration endMarketConfiguration = getGlobalEndMarketAzureConfig();
    BulkOrderUploadStatus bulkOrderUploadStatus = azureFileConfigService.findBulkOrderByConfigId(configId);
    if (endMarketConfiguration != null) {
      try {
        String fileName = FilenameUtils.getErrorFileName(bulkOrderUploadStatus.getFileName(), ".csv");
        String containerName = endMarketConfiguration.getContainerName();
        BlobStorageUtils.uploadBlob(file, endMarketConfiguration.getConnectionString(), fileName, containerName);

        BulkOrderUploadStatus uploadedBulk = createBulkOrderUploadStatus(endMarketConfiguration, fileName, containerName);
        return Optional.of(uploadedBulk);

      } catch (URISyntaxException | InvalidKeyException | StorageException | IOException e) {
        LOGGER.warn("Exception during error file uploading: "+e.getLocalizedMessage());
      }
    }
    return Optional.empty();
  }

  private BulkOrderUploadStatus createBulkOrderUploadStatus(EndMarketConfiguration endMarketConfiguration, String fileName, String containerName) throws UnsupportedEncodingException {
    BulkOrderUploadStatus uploadedBulk = new BulkOrderUploadStatus();
    String encodedFilename = URLEncoder.encode(fileName, "UTF-8");
    uploadedBulk.setFileName(encodedFilename);
    uploadedBulk.setFilePath(encodedFilename);
    uploadedBulk.setContainerName(containerName);
    uploadedBulk.setUploadedUrl(endMarketConfiguration.getBlobEndpoint());
    return uploadedBulk;
  }

  public void updateBulkUploadConfig(long bulkOrderId, BulkOrderUploadStatus uploadResult){
    azureFileConfigService.findBulkOrderAndSetupErrorFile(bulkOrderId, uploadResult.getFileName());
  }

  private EndMarketConfiguration getGlobalEndMarketAzureConfig() {
    return endMarketConfigurationSrv.getGlobalActiveEndMarketConfig(RecordTypeValue.EDI.getTypeName());
  }


  private InputStream getAzureFileInputStream(BulkOrderUploadStatus azureFileConfig)
      throws StorageException, URISyntaxException, InvalidKeyException {
    EndMarketConfiguration azureConfig = getEndMarketConfiguration();
    return getCloudBlobInputStream(azureConfig.getConnectionString(), azureFileConfig);
  }

  private EndMarketConfiguration getEndMarketConfiguration() {
    return endMarketConfigurationSrv.getActiveMarketConfig(RecordTypeValue.EDI.getTypeName(),MarketISO.BR.getValue());
  }

  private InputStream downloadFile(BulkOrderUploadStatus azureFileConfig) throws StorageException, URISyntaxException, IOException, InvalidKeyException {
    LOGGER.info("Downloading a file with a path "+azureFileConfig.getFilePath());
    InputStream stream = null;
    String blobEndpoint = azureFileConfig.getUploadedUrl();
    String fileType = azureFileConfig.getFileType();
    if (AzureFileType.CSV.getName().equals(fileType)) {
      stream = getAzureFileInputStream(azureFileConfig);
    } else if (AzureFileType.ZIP.getName().equals(fileType)) {
      stream = getAzureZipFileInputStream(azureFileConfig, blobEndpoint);
    }
    return stream;
  }

  private InputStream getAzureZipFileInputStream(BulkOrderUploadStatus azureFileConfig, String blobEndpoint)
      throws StorageException, URISyntaxException, IOException, InvalidKeyException {
    ZipInputStream zipStream = new ZipInputStream(getAzureFileInputStream(azureFileConfig));
    zipStream.getNextEntry();
    return zipStream;
  }

  protected InputStream getCloudBlobInputStream(String connectionString, BulkOrderUploadStatus azureFileConfig)
      throws StorageException, URISyntaxException, InvalidKeyException {
    return BlobStorageUtils.getCloudBlobInputStream(connectionString, azureFileConfig);
  }

}
