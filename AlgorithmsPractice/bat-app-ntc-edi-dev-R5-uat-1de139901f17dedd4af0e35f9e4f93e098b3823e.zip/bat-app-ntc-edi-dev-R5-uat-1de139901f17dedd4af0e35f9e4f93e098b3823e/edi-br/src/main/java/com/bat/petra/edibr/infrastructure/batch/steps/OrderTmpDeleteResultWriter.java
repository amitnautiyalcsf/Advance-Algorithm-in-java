package com.bat.petra.edibr.infrastructure.batch.steps;


import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmpRepo;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmpRepo;

import com.bat.petra.edibr.domain.orderlinetmp.OrderPaymentInstructionsTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderPaymentInstructionsTmpRepo;
import lombok.Getter;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-06-04.
 */
@Component
@StepScope
public class OrderTmpDeleteResultWriter implements ItemWriter<OrderHerokuTmp> {
  @Autowired
  private OrderLineHerokuTmpRepo orderLineHerokuTmpRepo;
  @Autowired
  private OrderHerokuTmpRepo orderTmpRepo;
  @Autowired
  private OrderPaymentInstructionsTmpRepo instructionsTmpRepo;

  @Override
  @Transactional
  public void write(List<? extends OrderHerokuTmp> orderHerokuTmps) throws Exception {
    ItemTmpHolder holder = new ItemTmpHolder();
    orderHerokuTmps.forEach(orderTmp -> {
      List<OrderLineHerokuTmp> lines = orderLineHerokuTmpRepo.findAllByOrderHerokuExternalId(orderTmp.getHerokuExternalId());
      holder.getLines().addAll(lines);
      holder.getOrders().add(orderTmp);
      holder.getInstructions().add(orderTmp.getPaymentInstructions());
    });

    orderTmpRepo.deleteInBatch(holder.getOrders());
    orderLineHerokuTmpRepo.deleteInBatch(holder.getLines());
    instructionsTmpRepo.deleteInBatch(holder.getInstructions());

  }

  @Getter
  private class ItemTmpHolder{
    private List<OrderHerokuTmp> orders = new ArrayList<>();
    private List<OrderPaymentInstructionsTmp> instructions = new ArrayList<>();
    private List<OrderLineHerokuTmp> lines = new ArrayList<>();


  }

}
