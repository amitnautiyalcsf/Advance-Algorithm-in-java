package com.bat.petra.edibr.domain.orderitem.validation.validator;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemListValidator;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author arkadiusz.wronski, created on 2019-06-26.
 */
public class MultipleSKUValidatorBR implements OrderItemListValidator {
  @Override
  public List<OrderItem> validateOrderItemList(List<? extends OrderItem> orderItemList) {
    ((List<OrderItem>)orderItemList).stream()
        .filter(item -> StringUtils.isNotEmpty(item.getProductInternalId()))
        .collect(Collectors.groupingBy(OrderItem::getProductInternalId))
        .entrySet().stream()
        .filter(entry -> entry.getValue().size() > 1)
        .flatMap(entry -> entry.getValue().stream())
        .forEach(item -> item.setErrorMsg(item.hasPoNumber() ? "Duplicate SKUs " + item.getProductInternalId()
            + " for the same PO number " + item.getPoNumber() : "Duplicate SKUs " + item.getProductInternalId() + " for the same order"));
    return ((List<OrderItem>)orderItemList);
  }
}
