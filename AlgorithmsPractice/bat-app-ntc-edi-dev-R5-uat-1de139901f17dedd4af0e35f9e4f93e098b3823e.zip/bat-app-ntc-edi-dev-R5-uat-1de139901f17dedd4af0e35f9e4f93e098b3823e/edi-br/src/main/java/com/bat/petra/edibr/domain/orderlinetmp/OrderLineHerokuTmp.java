package com.bat.petra.edibr.domain.orderlinetmp;

import com.bat.petra.commons.domain.model.OrderLineBase;
import lombok.Data;
import lombok.ToString;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author arkadiusz.wronski, created on 2019-03-14.
 */
@Entity
@Table(name = "order_line_item__c__tmp", schema = "salesforce")
@Data
@ToString(callSuper = true)
public class OrderLineHerokuTmp extends OrderLineBase {
}
