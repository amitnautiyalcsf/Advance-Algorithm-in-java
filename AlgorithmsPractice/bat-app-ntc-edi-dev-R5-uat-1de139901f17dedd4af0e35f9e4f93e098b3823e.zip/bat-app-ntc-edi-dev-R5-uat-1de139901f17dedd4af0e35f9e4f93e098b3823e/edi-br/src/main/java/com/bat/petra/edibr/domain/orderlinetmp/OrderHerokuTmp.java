package com.bat.petra.edibr.domain.orderlinetmp;

import com.bat.petra.commons.domain.model.OrderBase;
import lombok.Data;
import lombok.ToString;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author arkadiusz.wronski, created on 2019-03-14.
 */
@Entity
@Table(name = "order__c__tmp", schema = "salesforce")
@Data
@ToString(callSuper = true)
public class OrderHerokuTmp extends OrderBase {
  @Column(name = "job_id")
  private String jobId;
  @OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL, orphanRemoval = true)
  @JoinColumn(name = "instruction_id")
  @ToString.Exclude
  private OrderPaymentInstructionsTmp paymentInstructions;

}
