package com.bat.petra.edibr.infrastructure.batch.steps;


import com.bat.petra.commons.domain.model.Order;
import com.bat.petra.commons.domain.model.OrderLineItem;
import com.bat.petra.commons.domain.model.OrderPaymentInstructions;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmp;
import com.bat.petra.commons.domain.order.repository.OrderPaymentInstructionsRepo;
import com.bat.petra.commons.domain.order.repository.OrderRepo;
import com.bat.petra.commons.domain.orderline.OrderLineItemRepo;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineTmpMapper;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmp;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmpRepo;
import com.bat.petra.edibr.domain.ordertmp.service.OrderInstructionsTmpMapper;
import com.bat.petra.edibr.domain.ordertmp.service.OrderTmpMapper;
import lombok.Getter;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-03-18.
 */
@Component
@StepScope
public class OrderTmpProcessingResultWriter implements ItemWriter<OrderHerokuTmp> {
  @Autowired
  private OrderLineHerokuTmpRepo orderLineHerokuTmpRepo;
  @Autowired
  private OrderRepo orderRepo;
  @Autowired
  private OrderLineItemRepo orderLineItemRepo;
  @Autowired
  private OrderPaymentInstructionsRepo instructionsRepo;

  @Override
  @Transactional
  public void write(List<? extends OrderHerokuTmp> orderHerokuTmps) throws Exception {

    ItemsHolder holder = new ItemsHolder();
    orderHerokuTmps.forEach(orderTmp -> {
      Order order = OrderTmpMapper.INSTANCE.mapOrderHerokuToOrder(orderTmp);
      OrderPaymentInstructions instruction = OrderInstructionsTmpMapper.INSTANCE
          .mapInstructionsTmpToInstructions(orderTmp.getPaymentInstructions());
      instruction.setOrderHerokuExternalId(order.getHerokuExternalId());
      List<OrderLineHerokuTmp> linesTmp = orderLineHerokuTmpRepo.findAllByOrderHerokuExternalId(orderTmp.getHerokuExternalId());
      order.setNumberOfLines(new Double(linesTmp.size()));
      List<OrderLineItem> lines = new ArrayList<>();
      linesTmp.forEach(line -> lines.add(OrderLineTmpMapper.MAPPER.mapOrderLineTmpToOrderLine(line)));

      holder.getOrders().add(order);
      holder.getOrderLines().addAll(lines);
      holder.getOrderPaymentInstructions().add(instruction);

    });
    orderRepo.saveAll(holder.getOrders());
    orderLineItemRepo.saveAll(holder.getOrderLines());
    instructionsRepo.saveAll(holder.getOrderPaymentInstructions());
  }


  @Getter
  private class ItemsHolder{
    private List<Order> orders = new ArrayList<>();
    private List<OrderLineItem> orderLines = new ArrayList<>();
    private List<OrderPaymentInstructions> orderPaymentInstructions = new ArrayList<>();
  }
}
