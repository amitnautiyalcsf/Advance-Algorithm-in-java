package com.bat.petra.edibr.infrastructure.batch.config;

import com.bat.petra.edibr.domain.orderitemerror.OrderLineItemWithError;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmp;
import com.bat.petra.edibr.infrastructure.batch.listener.ItemWriteSpeedListener;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.edibr.infrastructure.batch.steps.AzureFileService;
import com.bat.petra.edibr.infrastructure.batch.steps.OrderProcessingResultWriter;
import com.bat.petra.edibr.infrastructure.batch.steps.OrderTmpDeleteResultWriter;
import com.bat.petra.edibr.infrastructure.batch.steps.OrderTmpErrorProcessingResultWriter;
import com.bat.petra.edibr.infrastructure.batch.steps.OrderTmpProcessingResultWriter;
import com.bat.petra.edibr.infrastructure.batch.steps.StatusUpdateListener;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepScope;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.item.database.HibernateCursorItemReader;
import org.springframework.batch.item.database.builder.HibernateCursorItemReaderBuilder;
import org.springframework.batch.item.file.FlatFileItemReader;
import org.springframework.batch.item.file.builder.FlatFileItemReaderBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.InputStreamResource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;

import javax.persistence.EntityManagerFactory;
import java.util.HashMap;
import java.util.Map;

/**
 * @author arkadiusz.wronski, created on 2019-02-07.
 */
@Configuration
public class BatchConfiguration extends DefaultBatchConfigurer {
  private final static Logger LOGGER = LoggerFactory.getLogger(BatchConfiguration.class);

  @Autowired
  private JobBuilderFactory jobBuilderFactory;
  @Autowired
  private StepBuilderFactory stepBuilderFactory;
  @Autowired
  private CsvFileConfig csvFileConfig;
  @Autowired
  private EntityManagerFactory entityManagerFactory;
  @Autowired
  private OrderProcessingResultWriter orderProcessingResultWriter;
  @Autowired
  private AzureFileService azureFileService;
  @Autowired
  private JobRegistry jobRegistry;
  @Autowired
  private StatusUpdateListener statusUpdateListener;
  @Autowired
  private OrderTmpProcessingResultWriter orderTmpProcessingResultWriter;
  @Autowired
  private OrderTmpErrorProcessingResultWriter orderTmpErrorProcessingResultWriter;
  @Autowired
  private OrderTmpDeleteResultWriter orderTmpDeleteResultWriter;

  @Bean
  public Job azureJob() {
    return jobBuilderFactory.get("persistFileFromAzure")
        .incrementer(new RunIdIncrementer())
        .start(processCsvFileStep())
        .next(copyCompletedOrder())
        .next(processErrorsStep())
        .next(deleteTmpsStep())
        .build();
  }


  @Bean
  @StepScope
  public FlatFileItemReader<OrderItem> azureFileReader(@Value("#{jobParameters['configId']}") Long configId) {
    return new FlatFileItemReaderBuilder<OrderItem>()
        .name("azureFileReader")
        .targetType(OrderItem.class)
        .delimited()
        .delimiter(csvFileConfig.getFieldSeparator())
        .names(csvFileConfig.getColumnNames())
        .resource(new InputStreamResource(azureFileService.downloadFile(configId)))
        .linesToSkip(1)
        .build();
  }

  @Bean
  public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor() {
    JobRegistryBeanPostProcessor processor = new JobRegistryBeanPostProcessor();
    processor.setJobRegistry(jobRegistry);
    return processor;
  }

  private Step processCsvFileStep() {
    return stepBuilderFactory
        .get("processCsvFileStep")
        .transactionManager(txManager())
        .listener(statusUpdateListener)
        .<OrderItem, OrderItem>chunk(50)
        .reader(azureFileReader(null))
        .writer(orderProcessingResultWriter)
        .listener(new ItemWriteSpeedListener("processCsvFileStep", 5))
        .build();
  }

  private Step copyCompletedOrder() {
    return stepBuilderFactory
        .get("processCompletedOrders")
        .transactionManager(txManager())
        .<OrderHerokuTmp, OrderHerokuTmp>chunk(50)
        .reader(completedOrderTmpReader(null))
        .writer(orderTmpProcessingResultWriter)
        .build();
  }

  private Step processErrorsStep() {
    return stepBuilderFactory
        .get("processErrorsStep")
        .transactionManager(txManager())
        .<OrderLineItemWithError, OrderLineItemWithError>chunk(1000000)
        .reader(errorLineItemReader(null))
        .writer(orderTmpErrorProcessingResultWriter)
        .build();
  }

  private Step deleteTmpsStep() {
    return stepBuilderFactory
        .get("deleteTmpsStep")
        .transactionManager(txManager())
        .<OrderHerokuTmp, OrderHerokuTmp>chunk(500)
        .reader(deleteOrderTmpReader(null))
        .writer(orderTmpDeleteResultWriter)
        .build();
  }

  @Bean
  @StepScope
  public HibernateCursorItemReader<OrderLineItemWithError> errorLineItemReader(@Value("#{jobParameters['ID']}") String jobId) {
    Map<String, Object> params = new HashMap<>();
    params.put("jobId", jobId);
    return new HibernateCursorItemReaderBuilder<OrderLineItemWithError>()
        .name("errorLineItemReader")
        .queryString("from OrderLineItemWithError where jobId = :jobId")
        .parameterValues(params)
        .entityClass(OrderLineItemWithError.class)
        .sessionFactory(entityManagerFactory.unwrap(SessionFactory.class))
        .build();
  }

  @Bean
  @StepScope
  public HibernateCursorItemReader<OrderHerokuTmp> completedOrderTmpReader(@Value("#{jobParameters['ID']}") String jobId) {
    Map<String, Object> params = new HashMap<>();
    params.put("jobId", jobId);
    return new HibernateCursorItemReaderBuilder<OrderHerokuTmp>()
        .name("completedOrderTmpReader")
        .queryString("from OrderHerokuTmp oHT " +
            " join fetch oHT.paymentInstructions " +
            " join fetch oHT.shipTo " +
            " where oHT.status='Completed' and oHT.jobId = :jobId")
        .parameterValues(params)
        .entityClass(OrderHerokuTmp.class)
        .sessionFactory(entityManagerFactory.unwrap(SessionFactory.class))
        .build();
  }

  @Bean
  @StepScope
  public HibernateCursorItemReader<OrderHerokuTmp> deleteOrderTmpReader(@Value("#{jobParameters['ID']}") String jobId){
    Map<String, Object> params = new HashMap<>();
    params.put("jobId", jobId);
    return new HibernateCursorItemReaderBuilder<OrderHerokuTmp>()
        .name("completedOrderTmpReader")
        .queryString("from OrderHerokuTmp oHT join fetch oHT.paymentInstructions where oHT.jobId = :jobId")
        .parameterValues(params)
        .entityClass(OrderHerokuTmp.class)
        .sessionFactory(entityManagerFactory.unwrap(SessionFactory.class))
        .build();
  }


  @Primary
  @Bean
  public PlatformTransactionManager txManager() {
    return new JpaTransactionManager(entityManagerFactory);
  }

}
