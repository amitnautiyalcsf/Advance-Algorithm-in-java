package com.bat.petra.edibr.infrastructure.service;


import com.bat.petra.edibr.domain.orderitemerror.OrderLineItemWithError;
import com.bat.petra.edibr.domain.orderitemerror.OrderLineItemWithErrorRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

/**
 * @author arkadiusz.wronski, created on 2019-03-13.
 */
@Service
public class OrderErrorService {

  @Autowired
  private OrderLineItemWithErrorRepo orderLineItemWithErrorRepo;

  @Transactional
  public void addErrorWithMsg(String bulkOrderSfid, String msg){
    OrderLineItemWithError error = new OrderLineItemWithError();
    error.setBulkOrderSfid(bulkOrderSfid);
    error.setErrorDesc(msg);
    orderLineItemWithErrorRepo.save(error);
  }

}
