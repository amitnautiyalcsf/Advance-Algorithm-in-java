package com.bat.petra.edibr.domain.orderlinetmp;

import com.bat.petra.commons.domain.model.OrderPaymentInstructionsBase;
import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToOne;
import javax.persistence.Table;

/**
 * @author arkadiusz.wronski, created on 2019-05-29.
 */
@Data
@Entity
@Table(name = "order_payment_instructions__c__tmp", schema = "salesforce")
public class OrderPaymentInstructionsTmp extends OrderPaymentInstructionsBase {
  @OneToOne(fetch = FetchType.LAZY, mappedBy = "paymentInstructions")
  private OrderHerokuTmp orderTmp;
}
