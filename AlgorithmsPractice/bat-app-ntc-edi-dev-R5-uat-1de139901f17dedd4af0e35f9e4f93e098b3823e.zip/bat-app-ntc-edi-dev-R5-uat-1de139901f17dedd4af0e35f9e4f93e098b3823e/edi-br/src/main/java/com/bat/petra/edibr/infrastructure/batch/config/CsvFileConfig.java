package com.bat.petra.edibr.infrastructure.batch.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * @author arkadiusz.wronski, created on 2019-02-08.
 */
@ConfigurationProperties(prefix = "csv.file")
@Component
@Data
public class CsvFileConfig {
  private String[] columnNames;
  private String fieldSeparator;
}
