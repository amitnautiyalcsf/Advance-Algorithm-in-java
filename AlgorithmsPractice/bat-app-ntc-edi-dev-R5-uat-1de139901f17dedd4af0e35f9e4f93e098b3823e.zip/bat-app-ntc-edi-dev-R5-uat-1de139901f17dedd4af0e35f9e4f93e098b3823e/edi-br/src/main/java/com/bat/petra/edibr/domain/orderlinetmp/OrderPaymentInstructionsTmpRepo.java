package com.bat.petra.edibr.domain.orderlinetmp;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author arkadiusz.wronski, created on 2019-06-05.
 */
@Repository
public interface OrderPaymentInstructionsTmpRepo extends JpaRepository<OrderPaymentInstructionsTmp, Long> {
}
