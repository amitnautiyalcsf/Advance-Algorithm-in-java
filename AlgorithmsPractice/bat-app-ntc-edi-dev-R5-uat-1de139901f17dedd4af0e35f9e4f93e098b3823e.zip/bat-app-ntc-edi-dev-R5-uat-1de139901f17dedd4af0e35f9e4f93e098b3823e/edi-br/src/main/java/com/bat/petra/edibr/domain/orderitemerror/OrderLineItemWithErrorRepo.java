package com.bat.petra.edibr.domain.orderitemerror;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * @author arkadiusz.wronski, created on 2019-07-02.
 */
@Repository
public interface OrderLineItemWithErrorRepo extends JpaRepository<OrderLineItemWithError,Long> {
}
