package com.bat.petra.edibr.domain.orderitem.service;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.service.OrderItemMapper;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.edibr.domain.orderitemerror.OrderLineItemWithError;
import com.bat.petra.edibr.domain.orderlinetmp.OrderLineHerokuTmp;
import org.springframework.stereotype.Service;

/**
 * @author arkadiusz.wronski, created on 2019-07-01.
 */
@Service
public class OrderItemMapperSrv implements OrderItemMapper {
  @Override
  public OrderLineItemWithError mapOrderItemToError(OrderItem orderLineItem, OrderItemValidationContext context) {
    return com.bat.petra.edibr.domain.orderitem.service.OrderItemMapper.MAPPER.mapOrderLineItemToError(orderLineItem);
  }

  public OrderLineHerokuTmp mapOrderItemToOrderLineTmp(OrderItem orderItem) {
    return com.bat.petra.edibr.domain.orderitem.service.OrderItemMapper.MAPPER.mapOrderItemToOrderLineTmp(orderItem);
  }
}
