package com.bat.petra.edibr.domain.ordertmp.service;

import com.bat.petra.commons.domain.model.Order;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.edibr.domain.orderlinetmp.OrderHerokuTmp;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.ReportingPolicy;
import org.mapstruct.factory.Mappers;

/**
 * @author arkadiusz.wronski, created on 2019-07-02.
 */
@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface OrderTmpMapper {
  OrderTmpMapper INSTANCE = Mappers.getMapper(OrderTmpMapper.class);

  @Mapping(target = "id", ignore = true)
  @Mapping(target = "status", constant = "")
  Order mapOrderHerokuToOrder(OrderHerokuTmp herokuOrder);

  @Mapping(target = "poNumber", source = "purchaseOrderNumber")
  @Mapping(target = "accountMarketISO", source = "marketISO")
  OrderItem mapOrderTmpToOrderItem(OrderHerokuTmp herokuTmp);
}
