package com.bat.petra.edibr.infrastructure.batch.listener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ItemWriteListener;

import java.util.List;

public class ItemWriteSpeedListener implements ItemWriteListener<Object> {

  public static final Logger LOGGER = LoggerFactory.getLogger(ItemWriteSpeedListener.class);

  private long writeCount = 0;

  private long startDate;

  private long previousChunkDate;

  private final String listenerName;

  private int loggingPeriod;

  public ItemWriteSpeedListener(String listenerName, int loggingPeriod) {
    this.listenerName = listenerName;
    this.loggingPeriod = loggingPeriod;
  }

  @Override
  public void beforeWrite(List<?> list) {
    if (startDate == 0) {
      startDate = System.currentTimeMillis();
    }
  }

  @Override
  public void afterWrite(List<?> list) {
    writeCount += list.size();
    double jobDuration = (System.currentTimeMillis() - startDate) / 1000d;
    double lastChunkDuration = (System.currentTimeMillis() - previousChunkDate) / 1000d;
    previousChunkDate = System.currentTimeMillis();
    LOGGER.info(listenerName + " speed " + writeCount / jobDuration + " items/s (last chunk speed " + list.size() / lastChunkDuration + " items/s)");
  }

  @Override
  public void onWriteError(Exception e, List<?> list) {

  }
}
