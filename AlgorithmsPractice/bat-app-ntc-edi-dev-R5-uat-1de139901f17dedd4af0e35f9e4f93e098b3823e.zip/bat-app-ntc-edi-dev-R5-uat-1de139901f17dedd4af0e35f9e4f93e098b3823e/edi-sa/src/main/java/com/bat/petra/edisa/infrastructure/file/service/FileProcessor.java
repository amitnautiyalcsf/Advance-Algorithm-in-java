package com.bat.petra.edisa.infrastructure.file.service;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.OrderItemProcessor;
import com.bat.petra.commons.domain.orderitem.ProcessorHolder;
import com.bat.petra.edisa.domain.file.csv.reader.CSVReader;
import com.bat.petra.edisa.domain.orderitem.service.ErrorHandler;
import com.bat.petra.edisa.domain.orderitem.service.ResultWriter;
import com.bat.petra.edisa.domain.orderitemerror.OrderLineItemWithError;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-07-03.
 */
@Log4j2
@Service
public class FileProcessor {

  @Autowired
  private OrderItemProcessor itemProcessor;
  @Autowired
  private ResultWriter resultWriter;

  @Transactional
  public List<OrderLineItemWithError> processFile(ByteArrayOutputStream output)throws Exception{
    List<OrderItem> orderItemSAS = (List<OrderItem>) CSVReader.readFile(output);
    List<List<OrderItem>> list = new ArrayList<>();
    list.add(orderItemSAS);
    ProcessorHolder processorHolder = new ProcessorHolder();
    List<ProcessorHolder.ResultHolder> futures = itemProcessor.processOrderItemOrder(list);
    ProcessorHolder.ProcessingState state = processorHolder.new ProcessingState();
    List<ProcessorHolder.OrderLineResultHolder> orderLinesFutures = itemProcessor.processOrderItemLines(futures, state);
    itemProcessor.processValidOrders(orderLinesFutures, state);
    resultWriter.persistValidItems(state);
    return (List<OrderLineItemWithError>)state.getOrderLineItemWithErrors();
  }
}
