package com.bat.petra.edisa.domain.orderitem.validation.validator;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemListValidator;
import com.bat.petra.edisa.domain.orderitem.OrderItemSA;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @author arkadiusz.wronski, created on 2019-06-26.
 */
public class MultipleSKUValidatorSA implements OrderItemListValidator {
  @Override
  public List<OrderItemSA> validateOrderItemList(List<? extends OrderItem> orderItemList) {
    ((List<OrderItemSA>)orderItemList).stream()
        .filter(item -> StringUtils.isNotEmpty(item.getEANCode()))
        .collect(Collectors.groupingBy(OrderItemSA::getEANCode))
        .entrySet().stream()
        .filter(entry -> entry.getValue().size() > 1)
        .flatMap(entry -> entry.getValue().stream())
        .forEach(item -> item.setErrorMsg(item.hasPoNumber() ? "Duplicate SKUs " + item.getEANCode()
            + " for the same PO number " + item.getPoNumber() : "Duplicate SKUs " + item.getEANCode() + " for the same order"));
    return (List<OrderItemSA>)orderItemList;
  }
}
