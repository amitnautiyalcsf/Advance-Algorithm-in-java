package com.bat.petra.edisa.domain.order.validation.validator;

import com.bat.petra.commons.domain.order.repository.AccountRepository;
import com.bat.petra.commons.domain.model.Account;
import com.bat.petra.commons.domain.order.validation.OrderValidationResult;
import com.bat.petra.commons.domain.order.validation.OrderValidator;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.edisa.domain.orderitem.OrderItemSA;

import java.math.BigInteger;
import java.util.Map;
import java.util.Optional;

import static com.bat.petra.commons.domain.order.validation.OrderValidationResult.withError;

/**
 * @author arkadiusz.wronski, created on 2019-06-28.
 */
public class GLNNumberValidator implements OrderValidator {
  private AccountRepository accountRepository;

  public GLNNumberValidator(AccountRepository accountRepository){
    this.accountRepository = accountRepository;
  }

  @Override
  public OrderValidationResult validateOrder(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    OrderItemSA item = (OrderItemSA)orderItem;
    Map<String,Object> validationParams = context.getValidationParams();
    Optional<Account> mainAccount = accountRepository.findByGlnNumber(item.getMainGLNNumber());
    if (!mainAccount.isPresent()) {
      return withError("GLN Code  " + item.getMainGLNNumber() + " for this customer not found.");
    }
    Account soldTo = mainAccount.get();
    if (soldTo.isBlockedToSales()) {
      return withError("The account is blocked for sales");
    }
    Optional<Account> shipToAccount = accountRepository.findByGlnNumber(item.getShipToGLNNumber());
    if (!shipToAccount.isPresent()) {
      return withError("GLN Code " + item.getShipToGLNNumber() + " for this customer not found.");
    }
    item.setSapCustomerId(soldTo.getSapCustomerId());
    addContextParameters(validationParams, soldTo, shipToAccount.get());
    return validResult();
  }

  private void addContextParameters(Map<String, Object> validationParams, Account mainAccount, Account shipToAccount) {
    validationParams.put(OrderItemValidationObject.MAIN_ACCOUNT.name(), mainAccount);
    validationParams.put(OrderItemValidationObject.SHIP_TO_ACCOUNT.name(), shipToAccount);
    validationParams.put(OrderItemValidationObject.SAP_CUSTOMER_ID.name(), mainAccount.getSapCustomerId());
    validationParams.put(OrderItemValidationObject.SHIP_TO_SAP_CUSTOMER_ID.name(), shipToAccount.getSapCustomerId());
    validationParams.put(OrderItemValidationObject.PREFERRED_DELIVERY_DAY.name(),shipToAccount.getPreferredDeliveryDay());
    validationParams.put(OrderItemValidationObject.BASE_DELIVERY_LEAD_TIME.name(),shipToAccount.getBaseDeliveryLeadTime());
    validationParams.put(OrderItemValidationObject.LOCATION_HIERARCHY.name(),shipToAccount.getLocationHierarchy());
  }
}
