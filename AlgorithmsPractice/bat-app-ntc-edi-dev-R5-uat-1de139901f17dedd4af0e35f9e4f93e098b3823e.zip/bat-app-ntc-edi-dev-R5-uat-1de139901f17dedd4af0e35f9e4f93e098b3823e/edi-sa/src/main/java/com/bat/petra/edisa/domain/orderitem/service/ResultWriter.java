package com.bat.petra.edisa.domain.orderitem.service;

import com.bat.petra.commons.domain.model.Account;
import com.bat.petra.commons.domain.model.Order;
import com.bat.petra.commons.domain.model.OrderLineItem;
import com.bat.petra.commons.domain.model.OrderPaymentInstructions;
import com.bat.petra.commons.domain.order.repository.OrderPaymentInstructionsRepo;
import com.bat.petra.commons.domain.order.repository.OrderRepo;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.ProcessorHolder;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.domain.orderline.OrderLineItemRepo;
import com.bat.petra.edisa.domain.order.OrderFactory;
import com.bat.petra.edisa.domain.orderitem.OrderItemSA;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-07-04.
 */
@Service
@Log4j2
public class ResultWriter {
  @Autowired
  private OrderFactory orderFactory;
  @Autowired
  private OrderRepo orderRepo;
  @Autowired
  private OrderLineItemRepo orderLineItemRepo;
  @Autowired
  private OrderPaymentInstructionsRepo instructionsRepo;

  public void persistValidItems(ProcessorHolder.ProcessingState state) {
    List<Order> orders = new ArrayList<>();
    List<OrderPaymentInstructions> orderInstructions = new ArrayList<>();
    List<OrderLineItem> lines = new ArrayList<>();
    state.getOrders().entrySet().stream().filter(entry -> entry.getValue().isValid() == true)
        .forEach(entry -> {
          OrderItemSA orderItemSA = (OrderItemSA) entry.getValue().getOrder();
          OrderItemValidationContext context = entry.getValue().getContext();
          List<OrderItem> ordersLines = state.getOrderLineItems().get(orderItemSA.getHerokuExternalId());
          orderItemSA.setOderLinesNo(new Double(ordersLines.size()));
          orders.add(orderFactory.createOrder(orderItemSA, context));
          lines.addAll(orderFactory.createOrderLines(ordersLines,context));
          try {
            Account account = (Account) context.getValidationParams().get(OrderItemValidationObject.MAIN_ACCOUNT.name());
            orderInstructions.add(orderFactory.createPaymentInstructions(orderItemSA,account.getSfId(),account.getDefaultPaymentMethod()));
          }catch (NullPointerException ex){
            log.warn(""+ex.getLocalizedMessage());
          }
        });
    orderRepo.saveAll(orders);
    orderLineItemRepo.saveAll(lines);
    instructionsRepo.saveAll(orderInstructions);
  }
}
