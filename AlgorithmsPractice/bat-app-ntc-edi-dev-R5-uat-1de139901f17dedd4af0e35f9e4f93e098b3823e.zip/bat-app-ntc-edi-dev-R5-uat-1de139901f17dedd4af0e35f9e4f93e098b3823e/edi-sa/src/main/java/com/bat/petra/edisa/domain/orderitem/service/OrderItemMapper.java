package com.bat.petra.edisa.domain.orderitem.service;

import com.bat.petra.commons.domain.model.OrderLineItem;
import com.bat.petra.edisa.domain.orderitem.OrderItemSA;
import com.bat.petra.edisa.domain.orderitemerror.OrderLineItemWithError;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

/**
 * @author arkadiusz.wronski, created on 2019-07-03.
 */
@Mapper
public interface OrderItemMapper {
  OrderItemMapper MAPPER = Mappers.getMapper(OrderItemMapper.class);

  @Mapping(source = "errorMsg", target = "errorDesc")
  OrderLineItemWithError mapOrderItemToError(OrderItemSA orderItemSA);

  @Mapping(source = "herokuExternalId", target = "orderHerokuExternalId")
  @Mapping(source = "orderType", target = "lineItemType")
  OrderLineItem mapOrderItemToOrderLine(OrderItemSA orderItemSA);
}
