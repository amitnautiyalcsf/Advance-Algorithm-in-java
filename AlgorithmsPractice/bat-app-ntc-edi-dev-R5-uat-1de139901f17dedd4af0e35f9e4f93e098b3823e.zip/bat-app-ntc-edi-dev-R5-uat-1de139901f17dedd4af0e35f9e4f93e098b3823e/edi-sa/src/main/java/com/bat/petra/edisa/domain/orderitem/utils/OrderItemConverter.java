package com.bat.petra.edisa.domain.orderitem.utils;

import com.bat.petra.edisa.domain.orderitem.OrderItemSA;

/**
 * @author arkadiusz.wronski, created on 2019-07-03.
 */
public class OrderItemConverter {
  public static OrderItemSA convertToOrderItemSA(String[] elements){
    OrderItemSA orderItemSA = new OrderItemSA();
    orderItemSA.setMainGLNNumber(elements[0]);
    orderItemSA.setShipToGLNNumber(elements[1]);
    orderItemSA.setDeliveryDate(elements[2]);
    orderItemSA.setPoNumber(elements[3]);
    orderItemSA.setEANCode(elements[4]);
    orderItemSA.setSalesUomHigh(elements[5]);
    orderItemSA.setSalesUomLow(elements[6]);
    orderItemSA.setOrderUploadDate(elements[7]);
    return orderItemSA;
  }
}
