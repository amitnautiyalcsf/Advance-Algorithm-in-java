package com.bat.petra.edisa.domain.orderitem.service;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.service.OrderItemMapper;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.edisa.domain.orderitem.OrderItemSA;
import com.bat.petra.edisa.domain.orderitemerror.OrderLineItemWithError;
import org.springframework.stereotype.Service;

/**
 * @author arkadiusz.wronski, created on 2019-07-03.
 */
@Service
public class OrderItemMapperSrv implements OrderItemMapper {
  @Override
  public OrderLineItemWithError mapOrderItemToError(OrderItem orderLineItem, OrderItemValidationContext context) {
    OrderLineItemWithError errorLine = com.bat.petra.edisa.domain.orderitem.service.OrderItemMapper.MAPPER
        .mapOrderItemToError((OrderItemSA)orderLineItem);
    Object shipToCustomer= context.getValidationParams().get(OrderItemValidationObject.SHIP_TO_SAP_CUSTOMER_ID);
    errorLine.setShipToSapId(shipToCustomer != null ? shipToCustomer.toString() : "");
    return errorLine;
  }
}
