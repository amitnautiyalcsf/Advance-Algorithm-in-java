package com.bat.petra.edisa.domain.order;

import com.bat.petra.commons.domain.model.Account;
import com.bat.petra.commons.domain.model.Order;
import com.bat.petra.commons.domain.model.OrderLineItem;
import com.bat.petra.commons.domain.model.OrderPaymentInstructions;
import com.bat.petra.commons.domain.model.Product;
import com.bat.petra.commons.domain.model.types.OrderItemStatus;
import com.bat.petra.commons.domain.model.types.OrderType;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.repository.CreditDetailsRepo;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.utils.DateUtils;
import com.bat.petra.edisa.domain.orderitem.OrderItemSA;
import com.bat.petra.edisa.domain.orderitem.service.OrderItemMapper;
import lombok.extern.log4j.Log4j2;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * @author arkadiusz.wronski, created on 2019-07-04.
 */
@Service
@Log4j2
public class OrderFactory {
  @Autowired
  private CreditDetailsRepo creditDetailsRepo;

  public Order createOrder(OrderItemSA item, OrderItemValidationContext context) {
    Order order = null;
    try {
      Account mainAccount = (Account) context.getValidationParams().get(OrderItemValidationObject.MAIN_ACCOUNT.name());
      Account shipToAccount = (Account) context.getValidationParams().get(OrderItemValidationObject.SHIP_TO_ACCOUNT.name());
      order = createOrder(item, mainAccount, shipToAccount);
    } catch (NullPointerException ex) {
      log.warn("Has not found validation param " + OrderItemValidationObject.MAIN_ACCOUNT.name());
      ex.printStackTrace();
    }
    return order;
  }

  public OrderPaymentInstructions createPaymentInstructions(OrderItemSA item, String accountSfId, String methodPayment) {
    OrderPaymentInstructions instructions = new OrderPaymentInstructions();
    instructions.setOrderHerokuExternalId(item.getHerokuExternalId());
    instructions.setPaymentMode(methodPayment);
    creditDetailsRepo.findFirstByAccountSfIdOrderByCreatedDateDesc(accountSfId)
        .ifPresent(creditDetails ->
            instructions.setCreditDays(creditDetails.getBaseCreditDays() != null ? creditDetails.getBaseCreditDays() : BigInteger.ZERO)
        );
    instructions.setDueDate(DateUtils.addDaysToDate
        (item.getDeliveryDate(), instructions.getCreditDays() != null ? instructions.getCreditDays().longValue() : 0));
    instructions.setPaymentInstructionDate(item.getOrderUploadDate());
    instructions.setSplitPercentage(BigInteger.valueOf(100));
    return instructions;
  }

  private Order createOrder(OrderItemSA item, Account mainAccount, Account shipToAccount) {
    Order order = new Order();
    order.setDeliveryDate(DateUtils.parseLocalDate(item.getDeliveryDate()));
    order.setPurchaseOrderNumber(item.getPoNumber());
    order.setOrderType(OrderType.TPO.getTypeName());
    order.setStore(mainAccount);
    order.setShipTo(shipToAccount);
    order.setPayer(mainAccount);
    order.setBillTo(mainAccount);
    order.setHerokuExternalId(item.getHerokuExternalId());
    order.setOwnerId(item.getOwnerId());
    order.setMarketISO(mainAccount.getMarketISO());
    order.setOrderUploadDate(item.getOrderUploadDate());
    order.setNumberOfLines(item.getOderLinesNo());
    //order.setStatus(OrderItemStatus.ONHOLD.getStatusName()); //PTX-25640 // According to FSD we do not set status
    return order;
  }

  public List<OrderLineItem> createOrderLines(List<OrderItem> orderItem, OrderItemValidationContext context) {
    List<OrderLineItem> lines = new ArrayList<>();
    orderItem.forEach(item -> {
      try {
        Product product = (Product) context.getValidationParams().get(OrderItemValidationObject.PRODUCT.name() + "_" +
            item.getProductInternalId());
        lines.add(createOrderLine((OrderItemSA) item, product));
      } catch (NullPointerException ex) {
        log.warn("Has not found validation param " + OrderItemValidationObject.PRODUCT.name());
      }
    });
    return lines;
  }

  private OrderLineItem createOrderLine(OrderItemSA item, Product product) {
    OrderLineItem orderLineItem = OrderItemMapper.MAPPER.mapOrderItemToOrderLine(item);
    orderLineItem.setUom2price(StringUtils.isNotEmpty(item.getSalesUomHigh()) ? new BigInteger(item.getSalesUomHigh()) : null);
    orderLineItem.setUom1price(StringUtils.isNotEmpty(item.getSalesUomLow()) ? new BigInteger(item.getSalesUomLow()) : null);
    orderLineItem.setMigrationExternalId(UUID.randomUUID().toString());
    orderLineItem.setProduct(product);
    return orderLineItem;
  }

}
