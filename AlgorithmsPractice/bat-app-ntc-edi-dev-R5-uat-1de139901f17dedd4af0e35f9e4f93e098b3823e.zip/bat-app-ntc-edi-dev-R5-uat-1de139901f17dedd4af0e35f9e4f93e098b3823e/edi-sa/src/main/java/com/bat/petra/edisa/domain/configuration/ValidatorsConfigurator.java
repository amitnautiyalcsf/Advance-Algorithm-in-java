package com.bat.petra.edisa.domain.configuration;

import com.bat.petra.commons.domain.order.repository.AccountRepository;
import com.bat.petra.commons.domain.order.service.OrderFacade;
import com.bat.petra.commons.domain.order.validation.validator.DeliveryDateValidator;
import com.bat.petra.commons.domain.order.validation.validator.MaxDeliveryLeadTimeValidator;
import com.bat.petra.commons.domain.order.validation.validator.PoNumberExtraConditionValidator;
import com.bat.petra.commons.domain.orderitem.repository.ProductRepo;
import com.bat.petra.commons.domain.orderitem.repository.ProductUOMRepo;
import com.bat.petra.commons.domain.orderitem.validation.ValidatorsFactory;
import com.bat.petra.commons.domain.orderitem.validation.validator.MandatoryFieldsValidator;
import com.bat.petra.commons.domain.orderitem.validation.validator.PriceValidator;
import com.bat.petra.commons.domain.orderitem.validation.validator.ProductInternalIdValidator;
import com.bat.petra.commons.utils.DateUtils;
import com.bat.petra.edisa.domain.order.validation.validator.GLNNumberValidator;
import com.bat.petra.edisa.domain.orderitem.validation.validator.MultipleSKUValidatorSA;
import com.bat.petra.edisa.domain.orderitem.validation.validator.ProductProductUOMValidator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;
import java.util.Arrays;

/**
 * @author arkadiusz.wronski, created on 2019-06-27.
 */
@Configuration
public class ValidatorsConfigurator {

  @Autowired
  private AccountRepository accountRepository;
  @Autowired
  OrderFacade orderFacade;
  @Autowired
  ProductUOMRepo productUOMRepo;
  @Autowired
  ProductRepo productRepo;

  @PostConstruct
  public void init(){
    DateUtils.initDateDateFormatter(DateUtils.DateFormat.SOUTH_AFRICA.getStringPattern());
  }

  @Bean
  public ValidatorsFactory southAfricaOrderItemValidatorsFactory(){
    ValidatorsFactory factorySA = new ValidatorsFactorySA();
    initOrderItemValidators(factorySA);
    initOrderValidators(factorySA);
    initOrderItemListValidators(factorySA);
    return factorySA;
  }

  private void initOrderItemListValidators(ValidatorsFactory factorySA) {
    factorySA.getOrderItemListValidators().addAll(Arrays.asList(new MultipleSKUValidatorSA()));
  }

  private void initOrderValidators(ValidatorsFactory factorySA) {
    factorySA.getOrderValidators().addAll(Arrays.asList(
        new GLNNumberValidator(accountRepository),
        new PoNumberExtraConditionValidator(orderFacade),
        new DeliveryDateValidator(),
        new MaxDeliveryLeadTimeValidator(orderFacade)

    ));
  }

  private void initOrderItemValidators(ValidatorsFactory factorySA) {
    factorySA.getOrderItemValidators().addAll(Arrays.asList(
        new ProductProductUOMValidator(productUOMRepo), //must be first because it sets up productInternalId
        new ProductInternalIdValidator(productRepo),
        new MandatoryFieldsValidator(),
        new PriceValidator()
    ));
  }
}
