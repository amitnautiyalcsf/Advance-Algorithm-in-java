package com.bat.petra.edisa.domain.orderitemerror;

import com.bat.petra.edisa.domain.orderitem.OrderItemSA;
import lombok.Data;
import lombok.ToString;

/**
 * @author arkadiusz.wronski, created on 2019-07-03.P
 */
@Data
@ToString(callSuper = true)
public class OrderLineItemWithError extends OrderItemSA {
  private Long id;
  private String errorDesc;
  private String shipToSapId;
}
