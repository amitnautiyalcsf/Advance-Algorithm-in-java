package com.bat.petra.edisa.infrastructure.service;

import com.bat.petra.commons.domain.model.BulkOrderUploadStatus;
import com.bat.petra.edisa.domain.file.service.BulkOrderFacade;
import com.bat.petra.edisa.domain.orderitem.service.ErrorHandler;
import com.bat.petra.edisa.domain.orderitemerror.OrderLineItemWithError;
import com.bat.petra.edisa.infrastructure.file.service.FileProcessor;
import com.microsoft.azure.storage.OperationContext;
import com.microsoft.azure.storage.StorageException;
import com.microsoft.azure.storage.blob.CloudBlob;
import com.microsoft.azure.storage.blob.DeleteSnapshotsOption;
import com.microsoft.azure.storage.blob.ListBlobItem;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-06-27.
 */
@Service
@Log4j2
@RequiredArgsConstructor
public class SchedulingService {

  public static final String FILE_ALREADY_LOCKED = "LeaseAlreadyPresent";

  private final AzureBlobService azureBlobService;

  private final FileProcessor fileProcessor;

  private final BulkOrderFacade bulkOrderFacade;

  private final ErrorHandler errorHandler;


  @Scheduled(cron = "${worker.scheduling.job.cron}")
  public void processAzureFiles() {
    List<ListBlobItem> files = azureBlobService.getAzureFileList();
    files.forEach(file -> {
      ByteArrayOutputStream output = new ByteArrayOutputStream();
      try {
        String leaseId = lockBlob((CloudBlob) file, output);

        BulkOrderUploadStatus bulkOrder = bulkOrderFacade.createBulkOrderWithInitialStatus(
            ((CloudBlob) file).getName(),
            ((CloudBlob) file).getName(),
            file.getContainer().getName(),
            file.getContainer().getServiceClient().getStorageUri().getPrimaryUri().toString()
        );

        ((CloudBlob) file).download(output);
        List<OrderLineItemWithError> errors = fileProcessor.processFile(output);
        if (errors.isEmpty()) {
          handleDeletion((CloudBlob) file, leaseId, bulkOrder);
        } else {
          handleErrors((CloudBlob) file, bulkOrder, errors);
        }
      } catch (StorageException se) {
        logStorageException((CloudBlob) file, se);
      } catch (Exception e) {
        e.printStackTrace();
      }
    });
  }

  private void handleErrors(CloudBlob file, BulkOrderUploadStatus bulkOrder, List<OrderLineItemWithError> errors) {
    errorHandler.saveErrorFile(file.getName(), errors)
        .ifPresent(errorFileName -> bulkOrderFacade.markAsFailedWithErrorFile(bulkOrder.getId(), errorFileName));
  }

  private void handleDeletion(CloudBlob file, String leaseId, BulkOrderUploadStatus bulkOrder) throws StorageException {
    deleteProcessedBlob(file, leaseId);
    bulkOrderFacade.markAsDeleted(bulkOrder.getId());
  }

  private void logStorageException(CloudBlob file, StorageException se) {
    if (FILE_ALREADY_LOCKED.equals(se.getErrorCode())) {
      //log.info("File " + file.getName() + " already locked");
    } else {
      se.printStackTrace();
    }
  }

  private void deleteProcessedBlob(CloudBlob file, String leaseId) throws StorageException {
    HashMap<String, String> userHeaders = new HashMap<>();
    userHeaders.put("x-ms-lease-id", leaseId);
    OperationContext context = new OperationContext();
    context.setUserHeaders(userHeaders);

    file.delete(DeleteSnapshotsOption.NONE, null, null, context);
    log.info("File {} with leaseId {} deleted.", file.getName(), leaseId);
  }

  private String lockBlob(CloudBlob file, ByteArrayOutputStream output) throws StorageException {
    String leaseId = file.acquireLease();
    log.info("Successfully locked file: {}; leaseId: {}", file.getName(), leaseId);
    return leaseId;
  }

}
