package com.bat.petra.edisa.domain.orderitem.service;

import com.bat.petra.commons.domain.config.EndMarketConfigurationService;
import com.bat.petra.commons.domain.model.EndMarketConfiguration;
import com.bat.petra.commons.domain.model.types.MarketISO;
import com.bat.petra.commons.domain.model.types.RecordTypeValue;
import com.bat.petra.commons.utils.BlobStorageUtils;
import com.bat.petra.commons.utils.DateUtils;
import com.bat.petra.commons.utils.FilenameUtils;
import com.bat.petra.edisa.domain.orderitemerror.OrderLineItemWithError;
import com.bat.petra.edisa.infrastructure.file.service.CsvFileConfig;
import com.microsoft.azure.storage.StorageException;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.security.InvalidKeyException;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author arkadiusz.wronski, created on 2019-07-04.
 */
@Component
@RequiredArgsConstructor
@Log4j2
public class ErrorHandler {
  private static final String ERROR_COLUMN_NAME = "ERROR MESSAGE";

  private final CsvFileConfig csvFileConfig;

  private final EndMarketConfigurationService marketSrv;

  public Optional<String> saveErrorFile(String fileName, List<OrderLineItemWithError> allErrorLines){
    String errorFileName;
    EndMarketConfiguration marketConfig = marketSrv
        .getGlobalActiveEndMarketConfig(RecordTypeValue.EDI.getTypeName());
    try {
      errorFileName = FilenameUtils.getErrorFileName(fileName,".csv");
      BlobStorageUtils.uploadBlob(getCSVErrorStream(allErrorLines), marketConfig.getConnectionString(), errorFileName
          , marketConfig.getContainerName());
    } catch (URISyntaxException | InvalidKeyException | StorageException | IOException e) {
      log.warn("Exception during error file uploading: "+e.getLocalizedMessage());
      errorFileName = null;
    }
    return Optional.ofNullable(errorFileName);
  }

  private ByteArrayOutputStream getCSVErrorStream(List<OrderLineItemWithError> allErrorLines) {
    ByteArrayOutputStream baos = new ByteArrayOutputStream();
    try {
      baos.write(getColumnNames().getBytes(Charset.forName("UTF-8")));
      Map<String, List<OrderLineItemWithError>> ordersWithErrorLines = allErrorLines.stream()
          .collect(Collectors.groupingBy(error -> Optional.ofNullable(error.getHerokuExternalId()).orElse("")));
      writeLinesToStream(baos, ordersWithErrorLines);
    } catch (IOException ex) {
      log.error("Exception during error file generation " + ex.getLocalizedMessage());
    }
    return baos;
  }

  private void writeLinesToStream(ByteArrayOutputStream baos, Map<String, List<OrderLineItemWithError>> ordersWithErrorLines) {
    ordersWithErrorLines.entrySet().forEach(entry ->
        entry.getValue().forEach(errorLine -> {
          try {
            baos.write(generateLineFromOrderLineError(errorLine).getBytes(Charset.forName("UTF-8")));
          } catch (IOException ex) {
            log.warn("Exception during error line converting " + ex.getLocalizedMessage());
          }
        })
    );
  }

  private String generateLineFromOrderLineError(OrderLineItemWithError errorLine) {
    StringBuilder sb = new StringBuilder(
        errorLine.getMainGLNNumber());
    sb.append(",").append(errorLine.getShipToGLNNumber())
        .append(",").append(errorLine.getDeliveryDate())
        .append(",").append(errorLine.getPoNumber())
        .append(",").append(errorLine.getEANCode())
        .append(",").append(errorLine.getSalesUomHigh())
        .append(",").append(errorLine.getSalesUomLow())
        .append(",").append(DateUtils.formatDate(errorLine.getOrderUploadDate()))
        .append(",").append(errorLine.getSapCustomerId())
        .append(",").append(errorLine.getShipToSapId())
        .append(",").append(errorLine.getProductInternalId())
        .append(",").append(errorLine.getErrorDesc())
        .append("\n");
    return sb.toString().replaceAll("null", "");
  }

  private String getColumnNames() {
    String columnNames = String.join(",", csvFileConfig.getColumnNames());
    return columnNames + "," + ERROR_COLUMN_NAME + "\n";
  }
}
