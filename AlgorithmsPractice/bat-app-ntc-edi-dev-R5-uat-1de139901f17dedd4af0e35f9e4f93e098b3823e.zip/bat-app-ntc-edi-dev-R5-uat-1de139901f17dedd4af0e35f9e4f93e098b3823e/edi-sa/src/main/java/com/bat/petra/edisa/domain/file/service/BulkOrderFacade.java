package com.bat.petra.edisa.domain.file.service;

import com.bat.petra.commons.domain.config.AzureFileConfigService;
import com.bat.petra.commons.domain.config.EndMarketConfigurationService;
import com.bat.petra.commons.domain.model.BulkOrderUploadStatus;
import com.bat.petra.commons.domain.model.EndMarketConfiguration;
import com.bat.petra.commons.domain.model.types.AzureFileStatus;
import com.bat.petra.commons.domain.model.types.MarketISO;
import com.bat.petra.commons.domain.model.types.RecordTypeValue;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

/**
 * @author arkadiusz.wronski, created on 2019-07-18.
 */
@Service
@RequiredArgsConstructor
public class BulkOrderFacade {

  private final EndMarketConfigurationService endMarketService;
  private final AzureFileConfigService azureFileService;

  public BulkOrderUploadStatus createBulkOrderWithInitialStatus(String filePath, String fileName, String containerName,
                                                                String uploadedUrl){
    EndMarketConfiguration endMarketConfig = endMarketService.getActiveMarketConfig
        (RecordTypeValue.EDI.getTypeName(), MarketISO.SA.getValue());
    BulkOrderUploadStatus bulkOrder = new BulkOrderUploadStatus();
    bulkOrder.setFilePath(filePath);
    bulkOrder.setFileName(fileName);
    bulkOrder.setStatus(AzureFileStatus.PROCESSING.getStatusName());
    bulkOrder.setUploadedUrl(uploadedUrl);
    bulkOrder.setOwnerId(endMarketConfig.getDesignatedUser());
    bulkOrder.setDesignatedUser(endMarketConfig.getDesignatedUser());
    bulkOrder.setContainerName(containerName);
    azureFileService.saveBulkOrder(bulkOrder);
    return bulkOrder;
  }

  public void markAsDeleted(Long bulkOrderId){
    azureFileService.updateDeletedFileStatus(bulkOrderId);
  }
  public void markAsFailedWithErrorFile(Long bulkOrderId, String errorFile){
    azureFileService.findBulkOrderAndSetupErrorFile(bulkOrderId,errorFile);
  }
}
