package com.bat.petra.edisa.domain.orderitem;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import lombok.Data;
import lombok.ToString;

import javax.persistence.MappedSuperclass;

/**
 * @author arkadiusz.wronski, created on 2019-07-01.
 */
@Data
@MappedSuperclass
@ToString(callSuper = true)
public class OrderItemSA extends OrderItem {
  private String mainGLNNumber;
  private String shipToGLNNumber;
  private String EANCode;
  private Double oderLinesNo;
}
