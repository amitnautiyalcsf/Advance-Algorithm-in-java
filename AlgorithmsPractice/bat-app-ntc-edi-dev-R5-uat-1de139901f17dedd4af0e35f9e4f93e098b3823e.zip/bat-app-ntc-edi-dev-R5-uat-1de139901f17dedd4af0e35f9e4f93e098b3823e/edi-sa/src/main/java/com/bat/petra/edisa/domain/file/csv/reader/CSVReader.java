package com.bat.petra.edisa.domain.file.csv.reader;

import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.edisa.domain.orderitem.OrderItemSA;
import com.bat.petra.edisa.domain.orderitem.utils.OrderItemConverter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-07-03.
 */
public class CSVReader {

  private static final Logger LOGGER = LoggerFactory.getLogger(CSVReader.class);

  public static List<? extends OrderItem> readFile(ByteArrayOutputStream outputStream){
    List<OrderItemSA> ordersList = new ArrayList<>();
    try {
      BufferedReader reader = new BufferedReader(
          new InputStreamReader(new ByteArrayInputStream(outputStream.toByteArray())));
      String line;
      //skipping headers
      reader.readLine();
      while((line = reader.readLine()) != null){
        String[] elements = line.split(",");
        ordersList.add(OrderItemConverter.convertToOrderItemSA(elements));
      }
    }catch (IOException ex){
      LOGGER.warn("Exception during reading csv file: "+ex.getLocalizedMessage());
    }
    return ordersList;
  }
}
