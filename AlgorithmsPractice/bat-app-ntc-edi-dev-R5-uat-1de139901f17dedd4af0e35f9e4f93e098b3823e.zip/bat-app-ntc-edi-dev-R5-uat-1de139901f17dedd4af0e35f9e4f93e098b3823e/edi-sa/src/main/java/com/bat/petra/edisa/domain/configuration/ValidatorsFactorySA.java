package com.bat.petra.edisa.domain.configuration;

import com.bat.petra.commons.domain.order.validation.OrderValidator;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemListValidator;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidator;
import com.bat.petra.commons.domain.orderitem.validation.ValidatorsFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-06-27.
 */
public class ValidatorsFactorySA  implements ValidatorsFactory {
  private List<OrderItemValidator> orderItemValidators = new ArrayList<>();
  private List<OrderValidator> orderValidators = new ArrayList<>();
  private List<OrderItemListValidator> orderItemListValidators = new ArrayList<>();

  @Override
  public List<OrderItemValidator> getOrderItemValidators() {
    return this.orderItemValidators;
  }

  @Override
  public List<OrderValidator> getOrderValidators() {
    return this.orderValidators;
  }

  @Override
  public List<OrderItemListValidator> getOrderItemListValidators() {
    return this.orderItemListValidators;
  }
}
