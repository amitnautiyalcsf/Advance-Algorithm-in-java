package com.bat.petra.edisa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @author arkadiusz.wronski, created on 2019-06-27.
 */
@SpringBootApplication(scanBasePackages = {"com.bat.petra.commons","com.bat.petra.edisa"})
@EntityScan(basePackages = "com.bat.petra.commons")
@EnableJpaRepositories(basePackages = "com.bat.petra.commons")
@EnableScheduling
@EnableConfigurationProperties
public class EDISAApplication {

  public static void main(String[] args){
    SpringApplication.run(EDISAApplication.class,args);
  }
}
