package com.bat.petra.edisa.domain.orderitem.validation.validator;

import com.bat.petra.commons.domain.model.ProductUOM;
import com.bat.petra.commons.domain.orderitem.OrderItem;
import com.bat.petra.commons.domain.orderitem.repository.ProductUOMRepo;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationContext;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationException;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationObject;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidationResult;
import com.bat.petra.commons.domain.orderitem.validation.OrderItemValidator;
import com.bat.petra.edisa.domain.orderitem.OrderItemSA;

import java.util.Optional;

/**
 * @author arkadiusz.wronski, created on 2019-07-01.
 */
public class ProductProductUOMValidator  implements OrderItemValidator {
  private ProductUOMRepo productUOMRepo;

  public ProductProductUOMValidator(ProductUOMRepo productUOMRepo){
    this.productUOMRepo = productUOMRepo;
  }
  @Override
  public OrderItemValidationResult validateOrderItem(OrderItem orderItem, OrderItemValidationContext context) throws OrderItemValidationException {
    if(orderItem instanceof OrderItemSA) {
      OrderItemSA orderItemSA = (OrderItemSA)orderItem;
      Optional<ProductUOM> productUOM = productUOMRepo.findByBarCode(orderItemSA.getEANCode());
      if (!productUOM.isPresent()) {
        return OrderItemValidationResult.withError("EAN Code " + orderItemSA.getEANCode() + " for this product not found.");
      }
      orderItem.setProductInternalId(productUOM.get().getProduct().getInternalId().toString());
      context.getValidationParams().put(OrderItemValidationObject.PRODUCT.name()+"_"+orderItemSA.getEANCode(), productUOM.get().getProduct());
    }else {
      throw new OrderItemValidationException("Object has incorrect type. Validation skipped.");
    }
    return validResult();
  }
}
