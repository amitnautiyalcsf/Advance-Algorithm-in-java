package com.bat.petra.edisa.infrastructure.service;

import com.bat.petra.commons.domain.config.EndMarketConfigurationService;
import com.bat.petra.commons.domain.model.EndMarketConfiguration;
import com.bat.petra.commons.domain.model.types.MarketISO;
import com.bat.petra.commons.domain.model.types.RecordTypeValue;
import com.bat.petra.commons.utils.BlobStorageUtils;
import com.microsoft.azure.storage.blob.ListBlobItem;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * @author arkadiusz.wronski, created on 2019-06-27.
 */
@Service
@RequiredArgsConstructor
@Log4j2
public class AzureBlobService {
  private final EndMarketConfigurationService endMarketConfigurationService;

  public List<ListBlobItem> getAzureFileList(){
    List<ListBlobItem> result = new ArrayList<>();
    EndMarketConfiguration endMarketConfig =  getEndMarketConfiguration();
    try {
      result = BlobStorageUtils.getBlobFileList(endMarketConfig.getConnectionString(), endMarketConfig.getContainerName());
    }catch (Exception ex){log.error("Exception during obtaining Azure connection: "+ex.getLocalizedMessage());}
    return result;
  }

  private EndMarketConfiguration getEndMarketConfiguration() {
    return endMarketConfigurationService.getActiveMarketConfig(RecordTypeValue.EDI.getTypeName(), MarketISO.SA.getValue());
  }

}
