package com.bat.petra.contractmngmt.serviceWrapper.service

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import spock.lang.Specification

@SpringBootTest
class SessionVerificationSeriveSpec extends Specification {

  @Autowired
  private SessionVerificationService service

  def "should route to proper service when given proper id"() {

    when:
    def result = service.isFromMobile(sessionId)

    then:
    result == expected

    where:
    sessionId                                                                                                          | expected
    "0Ak1l00000CwwtJCAR"                                                                                               | false
    "00D1q0000008eXk!AQkAQE7J3vr7lHb66s8_TcdrnGRrUsYC0bm6jpZv4JtNEtyt239yZqI13Pn8GdLYt0tTlg4Dr2emlhvj_1PyWRmzgI9NVPIB" | true
  }
}
