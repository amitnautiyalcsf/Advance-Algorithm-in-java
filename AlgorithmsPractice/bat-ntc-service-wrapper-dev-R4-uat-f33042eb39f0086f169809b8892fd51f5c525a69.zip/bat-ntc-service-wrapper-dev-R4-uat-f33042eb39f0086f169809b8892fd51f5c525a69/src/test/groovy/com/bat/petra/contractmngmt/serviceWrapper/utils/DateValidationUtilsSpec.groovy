package com.bat.petra.contractmngmt.serviceWrapper.utils

import spock.lang.Specification

import java.time.LocalDateTime

class DateValidationUtilsSpec extends Specification {

  def "Should validate if date plus some seconds is younger than now."() {

    given:

    LocalDateTime parsedCreatedDate = LocalDateTime.now().plusHours(createdDateOffset)

    when: "Validation invoked."

    def result = DateValidationUtils.validateIfExpired(parsedCreatedDate, secondsToExpiration)

    then: "All results should be with proper result"

    result == expectedResult

    where:

    createdDateOffset | secondsToExpiration | expectedResult
    0                 | 7200                | true
    1                 | 7200                | true
    -1                | 7200                | true
    -5                | 7200                | false
  }
}
