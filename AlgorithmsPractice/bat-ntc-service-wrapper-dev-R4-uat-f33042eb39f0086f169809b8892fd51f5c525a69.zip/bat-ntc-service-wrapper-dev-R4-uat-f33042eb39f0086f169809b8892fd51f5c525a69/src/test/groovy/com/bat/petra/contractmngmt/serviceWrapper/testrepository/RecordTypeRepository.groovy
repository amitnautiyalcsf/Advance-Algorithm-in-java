package com.bat.petra.contractmngmt.serviceWrapper.testrepository;

import com.bat.petra.contractmngmt.serviceWrapper.model.RecordType
import org.springframework.data.jpa.repository.JpaRepository
import org.springframework.stereotype.Repository

@Repository
interface RecordTypeRepository extends JpaRepository<RecordType, String> {
}
