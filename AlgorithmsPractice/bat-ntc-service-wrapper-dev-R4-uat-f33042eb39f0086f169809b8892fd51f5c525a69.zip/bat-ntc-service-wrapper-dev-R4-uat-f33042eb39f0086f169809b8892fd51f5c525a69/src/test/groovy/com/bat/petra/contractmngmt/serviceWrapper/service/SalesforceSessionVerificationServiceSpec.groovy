package com.bat.petra.contractmngmt.serviceWrapper.service

import com.bat.petra.contractmngmt.serviceWrapper.model.Session
import com.bat.petra.contractmngmt.serviceWrapper.repository.SessionRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock
import org.springframework.http.MediaType
import spock.lang.Specification

import java.time.OffsetDateTime
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse
import static com.github.tomakehurst.wiremock.client.WireMock.get
import static com.github.tomakehurst.wiremock.client.WireMock.post
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching
import static com.github.tomakehurst.wiremock.client.WireMock.urlPathEqualTo

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWireMock(port = 0)
class SalesforceSessionVerificationServiceSpec extends Specification {

  @Autowired
  SalesforceSessionVerificationService service

  @Autowired
  SessionRepository repository

  @Value('${wiremock.server.port}')
  private String wireMockServerPort

  def setup() {

    def now = ZonedDateTime.now()
    def formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

    def session = new Session()
    session.setId(1)
    session.setSfid("0Ak1l00000BieuHCAR")
    session.setCreatedDate(now.minusHours(1).format(formatter))
    session.setLastModifiedDate(now.minusHours(1).format(formatter))
    repository.save(session)
  }

  def cleanup() {

    repository.deleteAll()
  }

  def "Should verify session with database when given session ID"() {

    given: "Session ID is passed for verification"

    def sessionId = "0Ak1l00000BieuHCAR"

    when: "Service is invoked"

    def result = service.verifySessionIdWithDatabase(sessionId)

    then: "Should return value that equals to true."

    result
  }

  def "Should verify session with Salesforce when given session ID."() {

    given: "Session ID passed for verification"

    def sessionId = "0Ak1l00000Bj3cnCAB"

    def lastModifiedDate = OffsetDateTime.now().minusHours(1).format(
        DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ")
    )

    stubFor(post(urlPathEqualTo("/services/oauth2/token"))
        .willReturn(aResponse()
          .withBody("{}")
          .withHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE)))

    stubFor(get(urlMatching("/services/data/v44.0/sobjects/AuthSession/id/.*"))
        .willReturn(aResponse()
          .withBody('{"LastModifiedDate": "' + lastModifiedDate + '", "NumSecondsValid":7200}')
          .withHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE)))

    service.urlToAuthorize = "http://localhost:${wireMockServerPort}/services/oauth2/token"
    service.urlToApi = "http://localhost:${wireMockServerPort}/services/data/v44.0/sobjects/AuthSession/id/"

    when: "Service is invoked"

    def result = service.verifySessionIdWithSalesforceApi(sessionId)

    then: "Should return value that equals to true."

    result
  }
}
