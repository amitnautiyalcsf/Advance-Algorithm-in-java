package com.bat.petra.contractmngmt.serviceWrapper.service

import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock
import org.springframework.http.MediaType
import org.springframework.web.reactive.function.client.WebClientResponseException
import spock.lang.Specification

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse
import static com.github.tomakehurst.wiremock.client.WireMock.get
import static com.github.tomakehurst.wiremock.client.WireMock.stubFor
import static com.github.tomakehurst.wiremock.client.WireMock.urlMatching

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWireMock(port = 0)
class MobileSessionVerificationServiceSpec extends Specification {

  @Autowired
  private MobileSessionVerificationService service

  @Value('${wiremock.server.port}')
  private String wireMockServerPort

  def "Should verify session with Salesforce when given session ID. Happy path."() {

    given:

    def sessionId = "00D1q0000008eXk!AQkAQMtmpmgmrdAwaJb5YWhthfEuiSJtt2_Yze3m2Sdly0zM2SMe1nmS5wHLzsV02_sTvALDhQCE2_UWmYl3orT9CbUdvGeM"

    stubFor(get(urlMatching("/services/data/v44.0/sobjects/OauthToken/"))
        .willReturn(aResponse()
        .withStatus(200)
        .withBody('{}')
        .withHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE)))

    service.urlToApi = "http://localhost:${wireMockServerPort}/services/data/v44.0/sobjects/OauthToken/"

    when: "Service is invoked"

    def result = service.verifySessionIdWithSalesforceApi(sessionId)

    then: "Should return value that equals to true."

    result
  }

  def "Should verify session with Salesforce when given session ID. Negative path."() {

    given:

    def sessionId = "00D1q0000008eXk!AQkAQJN3ADZ2zS2ea4bc3bPIMD8br2M5y2mKerOYiyPQuYpoGjnceldQmW1T9YSKf_8PuSLB2R6vW_Qhha_mhX2ZcjsFEDkP"

    stubFor(get(urlMatching("/services/data/v44.0/sobjects/OauthToken/"))
        .willReturn(aResponse()
        .withStatus(401)
        .withBody('{\n' +
            '        "message": "Session expired or invalid",\n' +
            '        "errorCode": "INVALID_SESSION_ID"\n' +
            '    }')
        .withHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE)))

    service.urlToApi = "http://localhost:${wireMockServerPort}/services/data/v44.0/sobjects/OauthToken/"

    when: "Service is invoked"

    def result = service.verifySessionIdWithSalesforceApi(sessionId)

    then: "Should return value that equals to false."

    notThrown(WebClientResponseException)
    !result
  }
}
