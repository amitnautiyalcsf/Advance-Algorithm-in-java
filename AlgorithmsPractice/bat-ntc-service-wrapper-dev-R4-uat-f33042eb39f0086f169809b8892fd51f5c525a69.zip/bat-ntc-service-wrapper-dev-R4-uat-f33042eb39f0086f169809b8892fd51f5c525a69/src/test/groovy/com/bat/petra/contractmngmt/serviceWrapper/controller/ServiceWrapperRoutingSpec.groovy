package com.bat.petra.contractmngmt.serviceWrapper.controller

import com.bat.petra.contractmngmt.serviceWrapper.model.RecordType
import com.bat.petra.contractmngmt.serviceWrapper.model.Session
import com.bat.petra.contractmngmt.serviceWrapper.model.ValidatorService
import com.bat.petra.contractmngmt.serviceWrapper.repository.SessionRepository
import com.bat.petra.contractmngmt.serviceWrapper.repository.ValidatorServiceRepository
import com.bat.petra.contractmngmt.serviceWrapper.service.MobileSessionVerificationService
import com.bat.petra.contractmngmt.serviceWrapper.service.SalesforceSessionVerificationService
import com.bat.petra.contractmngmt.serviceWrapper.testrepository.RecordTypeRepository
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock
import org.springframework.http.MediaType
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders
import spock.lang.Ignore
import spock.lang.Specification

import java.time.LocalDateTime
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter

import static com.github.tomakehurst.wiremock.client.WireMock.*
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status

/**
 * @author arkadiusz.wronski , created on 2019-02-06.
 */

@AutoConfigureMockMvc
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWireMock(port = 0)
class ServiceWrapperRoutingSpec extends Specification {

  public static final String SF_SESSION_ID = "1234567890"
  @Autowired
  private ServiceWrapperRouting routing
  @Autowired
  private MockMvc mockMvc
  @Autowired
  private ValidatorServiceRepository validatorServiceRepository
  @Autowired
  private SessionRepository sessionRepository
  @Autowired
  private RecordTypeRepository recordTypeRepository
  @Value('${wiremock.server.port}')
  private String wireMockServerPort
  @Autowired
  private MobileSessionVerificationService verificationServiceNew
  @Autowired
  private SalesforceSessionVerificationService sfVerificationService

  def setup() {
    def recordType = new RecordType(id: '0121l0000000UPCAA2', name: 'End Market API Configuration')
    recordTypeRepository.save(recordType)
    validatorServiceRepository.save(new ValidatorService(
        id: 1,
        marketIso: "ISO",
        serviceType: "serviceType1",
        active: true,
        serviceAddress: "http://localhost:${wireMockServerPort}/validate1",
        timeout: 15.123,
        recordType: recordType))
    validatorServiceRepository.save(new ValidatorService(
        id: 2,
        marketIso: "ISO2",
        active: true,
        serviceAddress: "http://localhost:${wireMockServerPort}/validate2",
        timeout: 15,
        recordType: recordType))
    validatorServiceRepository.save(new ValidatorService(
        id: 3,
        marketIso: "ISO",
        active: false,
        serviceAddress: "http://localhost:${wireMockServerPort}/validate3",
        timeout: 15,
        recordType: recordType))
    sessionRepository.save(new Session(
        id: 1,
        sfid: "mockSessionId",
        createdDate: LocalDateTime.now().minusSeconds(3).format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"))))

  }

  def cleanup() {
    validatorServiceRepository.deleteAll()
    sessionRepository.deleteAll()
  }

  def "Wrong response from mobile gives 500"() {
//    FIXME: whatif mobile returns 4xx / 5xx or times out?
//    given:
//    verificationServiceNew.urlToApi = "http://localhost:${wireMockServerPort}/services/data/v44.0/sobjects/OauthToken/"
//    stubFor(get(urlMatching("/services/data/v44.0/sobjects/OauthToken/"))
//        .willReturn(aResponse()
//            .withStatus(403)
//            .withBody('{}')
//            .withHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE)))
//    when: "Json sent to routing service"
//    def json = getJson("ISO")
//    def builder = MockMvcRequestBuilders.post("/validate")
//        .contentType(MediaType.APPLICATION_JSON)
//        .content(json)
//    then:
//    mockMvc.perform(builder)
//        .andExpect(status(500))
  }

  def "Create account mobile - Empty response from mobile gives 403"() {
    given:
    verificationServiceNew.urlToApi = "http://localhost:${wireMockServerPort}/services/data/v44.0/sobjects/OauthToken/"
    stubFor(post(urlEqualTo("/validate1"))
        .willReturn(aResponse().withBody('{"valid":true}')))
    stubFor(get(urlMatching("/services/data/v44.0/sobjects/OauthToken/"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBody()
            .withHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE)))
    when: "Json sent to routing service"
    def json = getMobileJson("ISO")
    def builder = MockMvcRequestBuilders.post("/validate")
        .contentType(MediaType.APPLICATION_JSON)
        .content(json)
    then:
    mockMvc.perform(builder)
        .andExpect(status().isForbidden())
  }

  def "Update account mobile - Empty response from mobile gives 403"() {
    given:
    verificationServiceNew.urlToApi = "http://localhost:${wireMockServerPort}/services/data/v44.0/sobjects/OauthToken/"
    stubFor(put(urlEqualTo("/validate1"))
        .willReturn(aResponse().withBody('{"valid":true}')))
    stubFor(get(urlMatching("/services/data/v44.0/sobjects/OauthToken/"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBody()
            .withHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE)))
    when: "Json sent to routing service"
    def json = getMobileJson("ISO")
    def builder = MockMvcRequestBuilders.post("/validate")
        .contentType(MediaType.APPLICATION_JSON)
        .content(json)
    then:
    mockMvc.perform(builder)
        .andExpect(status().isForbidden())
  }

  def "Mobile routing works"() {
    given: "Validator Service returns response"
    stubFor(post(urlEqualTo("/validate1"))
        .willReturn(aResponse().withBody('{"valid":true}')))
    stubFor(get(urlMatching("/services/data/v44.0/sobjects/OauthToken/"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBody('{}')
            .withHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE)))
    verificationServiceNew.urlToApi = "http://localhost:${wireMockServerPort}/services/data/v44.0/sobjects/OauthToken/"
    when: "Json sent to routing service"
    def json = getMobileJson("ISO")
    def builder = MockMvcRequestBuilders.post("/validate")
        .contentType(MediaType.APPLICATION_JSON)
        .content(json)
    then: "Proper method is invoked and status ok and body matches with "
    mockMvc.perform(builder)
        .andExpect(status().isOk())
        .andExpect(content().json('{"valid":true}'))
  }

  @Ignore
  def "SF routing works"() {
    given: "Validator Service returns response"
    stubFor(post(urlEqualTo("/validate1"))
        .willReturn(aResponse().withBody('{"valid":true}')))
    // "LastModifiedDate": "2019-07-02T11:01:16.000+0000",
    String date = ZonedDateTime.now().minusSeconds(10).format(DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSZ"))
    stubFor(get(urlMatching("/services/oauth2/token/" + SF_SESSION_ID))
        .willReturn(aResponse()
            .withStatus(200)
            .withBody('{"LastModifiedDate":"' + date + '","NumSecondsValid":"7200"}')
            .withHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE)))
    sfVerificationService.urlToApi = "http://localhost:${wireMockServerPort}/services/oauth2/token/"
    when: "Json sent to routing service"
    def json = getSfJson("ISO")
    def builder = MockMvcRequestBuilders.post("/validate")
        .contentType(MediaType.APPLICATION_JSON)
        .content(json)
    then: "Proper method is invoked and status ok and body matches with "
    mockMvc.perform(builder)
        .andExpect(status().isOk())
        .andExpect(content().json('{"valid":true}'))
  }

  def "Default validation works"() {
    given: "Json sent to routing service with ISO unmached to any validator"
    def json = getMobileJson("UNKNOWN_ISO")
    def builder = MockMvcRequestBuilders.post("/validate")
        .contentType(MediaType.APPLICATION_JSON)
        .content(json)
    stubFor(get(urlMatching("/services/data/v44.0/sobjects/OauthToken/"))
        .willReturn(aResponse()
            .withStatus(200)
            .withBody('{}')
            .withHeader("Content-Type", MediaType.APPLICATION_JSON_UTF8_VALUE)))
    verificationServiceNew.urlToApi = "http://localhost:${wireMockServerPort}/services/data/v44.0/sobjects/OauthToken/"
    expect: "Response equals request with wrappers added"
    mockMvc.perform(builder)
        .andExpect(status().isOk())
        .andExpect(content().json("""
          {
            "user": {
              "marketISO": "UNKNOWN_ISO",
              "sessionId": "00D1q0000008eXk!AQkAQMtmpmgmrdAwaJb5YWhthfEuiSJtt2_Yze3m2Sdly0zM2SMe1nmS5wHLzsV02_sTvALDhQCE2_UWmYl3orT9CbUdvGeM",
              "serviceType": "serviceType1"
            },
            "contract": {
              "phone": {
                "value": "123",
                "hasError": false
              }
            }
          }
        """))
  }

  def getMobileJson(marketIso) {
    return getJson(marketIso, "00D1q0000008eXk!AQkAQMtmpmgmrdAwaJb5YWhthfEuiSJtt2_Yze3m2Sdly0zM2SMe1nmS5wHLzsV02_sTvALDhQCE2_UWmYl3orT9CbUdvGeM")
  }

  def getSfJson(marketIso) {
    return getJson(marketIso, SF_SESSION_ID)
  }

  def getJson(marketIso, sessionId) {
    return """
      {
        "user": {
          "marketISO": "${marketIso}",
          "sessionId": "${sessionId}",
          "serviceType": "serviceType1"
        },
        "contract": {
          "phone": "123"
        }
      }
    """
  }
}
