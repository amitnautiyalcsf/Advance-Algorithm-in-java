package com.bat.petra.contractmngmt.serviceWrapper.service


import com.bat.petra.contractmngmt.serviceWrapper.model.SystemConfiguration
import com.bat.petra.contractmngmt.serviceWrapper.model.SystemConfigurationKey
import com.bat.petra.contractmngmt.serviceWrapper.repository.SystemConfigurationRepository
import spock.lang.Specification

import static com.bat.petra.contractmngmt.serviceWrapper.model.SystemConfigurationKey.PRIVATE_KEY
import static com.bat.petra.contractmngmt.serviceWrapper.model.SystemConfigurationKey.PUBLIC_KEY

/**
 * @author arkadiusz.wronski , created on 2019-02-06.
 */

class PublicKeyServiceSpec extends Specification {


  def "Key are generated when not exists in config"() {
    given: "Configuration table is empty"
    def systemConfigurationRepository = Mock(SystemConfigurationRepository)
    when: "Application is started"
    def keyService = new KeyService(systemConfigurationRepository)
    keyService.onApplicationEvent(null)
    then: "Key pair was generated"
    keyService.publicKey != null
    keyService.privateKey != null
    and: "saved to db"
    1 * systemConfigurationRepository.save({it.key == PRIVATE_KEY && it.value.length() > 300} as SystemConfiguration)
    1 * systemConfigurationRepository.save({it.key == PUBLIC_KEY && it.value.length() > 300} as SystemConfiguration)
  }

  def "Key are fetched from db"() {
    given: "Configuration table has both keys"
    SystemConfigurationRepository systemConfigurationRepository = Stub()
    def privateKeyBase64 = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCY71agybKHf/MpCvb/imusxnEJmvFlQ7GnsjW11IdxVEvVSyWCxuEDwqPKlebpm3iNEO98sVS7zZhWWwLpM0h10hkSOYdjmkVbcFArilSK71cMszPni/kIMJtVcGbzoF324u4SFXArnTair35UP02bM3d1j3bZYFYQS9fWiMF0UUrZh4o3xk7Wmz9HRLtdRaqTKxgcSZaft84EuAfgGkxh/ODezUTFpfZ6f3tAQyv/m9UkSJswwJpa7godHFdGJIHD6Kigakw3OCowWnv9qrcyIW+E/TdEYXa12SjEDaXBEG/NLtmy8sN/XsmCQ7/JDUuwMW8EI3graiJRoVmzJrQrAgMBAAECggEAdDPG2rzmjdZGaDUQn/IJBmpxkR7NtGfPIOBjtxkZIJ8wT4ydn9SFPFo0IcXsgivDWUw468HB5EC/Mz5L4+03bW6J5jMYEDIz6NpZz/t3aWmZ9uhi09ijC/oCzNRvJUYAn4ql4c+wPzNhRBOcJV9EFFzys7yiTWDJg/Bcu4GFnF7EmAkCvgfxrhKcDbV2hy90K2MwCStti8Q5blcO0w/JM0emJSsJnsBdEL0FaPH37NbdrZ8g7TPrAOaw2Us44DVCQCy2ySCkfwFNnVqGln/IY40imzUriG5LFMKjL/AegaplkWGUPd/CAo/eSuk3OMpTSqRWdG6G6rmzaBM2j9UHIQKBgQD1XEHBf/j3QNofMY2Iw6a+Z1AwL4plMUyFtyiKSSYHiF6Fb/A/VeJiZEuheNxfZ6symxx+iHbviw1o+Bm8Cv97ZpbFSM4QCAbPMZ58bOLlrROTRdCZ1q6JKId14CB44/FoR/CsN/76vQiZa2FN8dp+psdP0u607JcslpynecU47QKBgQCfkRE/5AVxIrKocUIgS30EF9RES8Z/+BCRpCcPpOdVOUcJF0vTZTmdvwA5aVhw7P+c8KAJwefyTvlmZMIGSiUyggLdx89T+oT3D7gseMp00jO6Ww9hKwV5VGj08uvOMu4CTGNZTgUpS3J1dSwtBgO1jD51g/iDiDFg2/1Hlax2dwKBgQDw65DJjn4JUk2bOY3vD6YH6ewMFHJBIKIx3gHZny/PT7D4N0zg89Thpfe5arKAn4uzmijledvHJHObcZnbUbVBFx/OQcnMZgVBp0gmhshYm5TQFEpa9DjXBsvUC6n26mNdcN46TJV64OiztIOMBIH1wI+OquCnGHTsXEsgC2qDlQKBgAfn2RHwSzC6xl1AF0WgV9ZPE+46TuBiOvfsSR8mTWvUhad2pwQXPM6K+wjdJkuaAmQVK+iv2b0QmpyvG0nSfJtPA7NXRfdkLxhKiBZz+ZvmGjf+cPmgdwn226hfLL2vmkk03as8CVdtbINTRdgJNz/UbffGjRZ/NesVmyvjx4KrAoGAJn69guTOnZ1GNCwdQTcTRdpe9F7Ai/yFNAv+hpF/b4Pzx2YmLxWTn9s61bghSKZelRzBE3UP72plrDYX02QGJWZhWaxgZTmBcwO7HkZFcz90GM1M+5E2bAGA5v7vudE6mbDT27+t0unHWZQrIPWa8dazPCfNy6mlu/r5fvOXwHI="
    def publicKeyBase64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmO9WoMmyh3/zKQr2/4prrMZxCZrxZUOxp7I1tdSHcVRL1UslgsbhA8KjypXm6Zt4jRDvfLFUu82YVlsC6TNIddIZEjmHY5pFW3BQK4pUiu9XDLMz54v5CDCbVXBm86Bd9uLuEhVwK502oq9+VD9NmzN3dY922WBWEEvX1ojBdFFK2YeKN8ZO1ps/R0S7XUWqkysYHEmWn7fOBLgH4BpMYfzg3s1ExaX2en97QEMr/5vVJEibMMCaWu4KHRxXRiSBw+iooGpMNzgqMFp7/aq3MiFvhP03RGF2tdkoxA2lwRBvzS7ZsvLDf17JgkO/yQ1LsDFvBCN4K2oiUaFZsya0KwIDAQAB"
    systemConfigurationRepository.getByKey(PRIVATE_KEY) >> new SystemConfiguration(PRIVATE_KEY, privateKeyBase64)
    systemConfigurationRepository.getByKey(PUBLIC_KEY) >> new SystemConfiguration(PUBLIC_KEY, publicKeyBase64)

    when: "Application is started"
    def keyService = new KeyService(systemConfigurationRepository)
    keyService.onApplicationEvent(null)
    then: "Keys was fetched from db"
    systemConfigurationRepository.getByKey(PRIVATE_KEY)
    systemConfigurationRepository.getByKey(PUBLIC_KEY)
    then: "Key pair was generated"
    keyService.privateKey.encoded == Base64.getDecoder().decode(privateKeyBase64)
    keyService.publicKey.encoded == Base64.getDecoder().decode(publicKeyBase64)
    and: "No modification was performed"
    0 * systemConfigurationRepository.save(_)
    0 * systemConfigurationRepository.deleteByKey(_ as SystemConfigurationKey)
  }
}
