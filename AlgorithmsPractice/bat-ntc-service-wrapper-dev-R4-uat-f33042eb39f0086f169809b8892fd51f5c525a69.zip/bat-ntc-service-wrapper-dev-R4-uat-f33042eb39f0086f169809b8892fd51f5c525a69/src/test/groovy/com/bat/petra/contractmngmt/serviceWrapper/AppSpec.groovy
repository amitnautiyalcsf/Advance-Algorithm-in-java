package com.bat.petra.contractmngmt.serviceWrapper

import com.bat.petra.contractmngmt.serviceWrapper.controller.ServiceWrapperRouting
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import spock.lang.Specification

/**
 * @author arkadiusz.wronski , created on 2019-02-05.
 */
@SpringBootTest
class AppSpec extends Specification {

  @Autowired
  private ServiceWrapperRouting serviceWrapperRouting

  def "Application is running"() {
    expect:
    serviceWrapperRouting
  }
}
