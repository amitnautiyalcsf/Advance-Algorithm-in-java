package com.bat.petra.contractmngmt.serviceWrapper.controller

import com.bat.petra.contractmngmt.serviceWrapper.service.KeyService
import org.hamcrest.BaseMatcher
import org.hamcrest.Description
import org.slf4j.Logger
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.test.web.servlet.MockMvc
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders
import spock.lang.Specification

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status

/**
 * @author arkadiusz.wronski , created on 2019-02-06.
 */

@AutoConfigureMockMvc
@SpringBootTest
class PublicKeyControllerSpec extends Specification {
  private static final Logger LOGGER = LoggerFactory.getLogger(PublicKeyControllerSpec.class)

  @Autowired
  private PublicKeyController routing
  @Autowired
  private MockMvc mockMvc
  @Autowired
  private KeyService keyService

  def "Key was generated automatically after application start"() {
    when: "Public key was fetched"
    def builder = MockMvcRequestBuilders.get("/publicKey")
    then: "Generated public key was returned"
    mockMvc.perform(builder)
        .andExpect(status().isOk())
        .andExpect(content().string(isProperPublicKey()))
  }

  def "After second start same key is fetched from db"() {
    given: "Key pair was generated"
    def publicKey = keyService.publicKey
    def privateKey = keyService.privateKey
    when: "Application starts again and event is fired"
    keyService.onApplicationEvent(null)
    then: "Same public keys was fetched"
    publicKey == keyService.publicKey
    privateKey == keyService.privateKey
  }

  def isProperPublicKey() {
    return new BaseMatcher<String>() {
      @Override
      boolean matches(Object item) {
        return (item instanceof String) &&
            ((String) item).contains("-----BEGIN RSA PUBLIC KEY-----") &&
            ((String) item).contains("-----END RSA PUBLIC KEY-----") &&
            ((String) item).length() > 300
      }

      @Override
      void describeTo(Description description) {
        description.appendText(" does not meet public key requirements")
      }
    }
  }
}
