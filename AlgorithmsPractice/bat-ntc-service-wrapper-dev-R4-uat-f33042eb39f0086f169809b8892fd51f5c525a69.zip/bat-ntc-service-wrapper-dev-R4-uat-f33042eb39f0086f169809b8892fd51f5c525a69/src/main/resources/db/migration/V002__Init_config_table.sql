CREATE TABLE system_configuration
(
  id serial,
  key character varying(64),
  value character varying(2000),
  CONSTRAINT system_configuration_pkey PRIMARY KEY (id)
);

CREATE UNIQUE INDEX system_configuration_type_uq ON system_configuration (key);
