package com.bat.petra.contractmngmt.serviceWrapper.controller;

import com.bat.petra.contractmngmt.serviceWrapper.service.SessionVerificationService;
import com.bat.petra.contractmngmt.serviceWrapper.service.ValidatorServiceService;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpClientErrorException;

import java.util.AbstractMap;
import java.util.Map;
import java.util.Optional;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

/**
 * @author arkadiusz.wronski, created on 2019-02-05.
 */

@RestController
@AllArgsConstructor
public class ServiceWrapperRouting {
  private static final Logger LOGGER = LoggerFactory.getLogger(ServiceWrapperRouting.class);

  private ValidatorServiceService validatorServiceService;
  private SessionVerificationService sessionVerificationService;

  @PostMapping(value = "/validate", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
  @ResponseBody
  public ResponseEntity<String> routeCreateRequestToServiceValidator(@RequestBody Map<String, Object> jsonInput) {
    return errorIfSessionInvalid(jsonInput)
        .orElseGet(() -> validateRequest(jsonInput, HttpMethod.POST));
  }

  @PutMapping(value = "/validate", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
  @ResponseBody
  public ResponseEntity<String> routeUpdateRequestToServiceValidator(@RequestBody Map<String, Object> jsonInput) {
    return errorIfSessionInvalid(jsonInput)
        .orElseGet(() -> validateRequest(jsonInput, HttpMethod.PUT));
  }

  private Optional<ResponseEntity<String>> errorIfSessionInvalid(Map<String, Object> jsonInput) {
    LOGGER.info("-------------- Create request routing start --------------------");
    LOGGER.info(String.format("Incoming request: %s", jsonInput));
    boolean sessionValid;
    try {
      sessionValid = sessionVerificationService.verifySession(jsonInput);
    } catch (HttpClientErrorException ex) {
      LOGGER.info("HttpClientErrorException: " + ex.getStatusCode().toString() + " = " + ex.getResponseBodyAsString());
      LOGGER.info("sessionValid exception: Response: 500=" + ex.getResponseBodyAsString());
      LOGGER.info("-------------- Create request routing end --------------------");
      return Optional.of(ResponseEntity.status(500).body(ex.getResponseBodyAsString()));
    }
    if (!sessionValid) {
      LOGGER.info("sessionValid = false: Response: 403");
      LOGGER.info("-------------- Create request routing end --------------------");
      return Optional.of(ResponseEntity.status(403).build());
    }
    return Optional.empty();
  }

  private ResponseEntity<String> validateRequest(Map<String, Object> jsonInput, HttpMethod method) {
    AbstractMap.SimpleEntry<Integer, String> result = validatorServiceService.validateRequest(jsonInput, method);
    LOGGER.info(String.format("Response: %s", result));
    LOGGER.info("-------------- Create request routing end --------------------");
    return ResponseEntity.status(HttpStatus.valueOf(result.getKey())).body(result.getValue());
  }
}
