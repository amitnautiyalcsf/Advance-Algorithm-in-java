package com.bat.petra.contractmngmt.serviceWrapper.model;

import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "end_market_configuration__c", schema = "salesforce")
@Data
public class ValidatorService {

  @Id
  @Column(name = "id")
  private Integer id;

  @Column(name = "market_iso__c")
  private String marketIso;

  @Column(name = "service_type__c")
  private String serviceType;

  @Column(name = "service_address__c")
  private String serviceAddress;

  @Column(name = "time_out__c")
  private BigDecimal timeout;

  @Column(name = "Active__c")
  private boolean active;

  @JoinColumn(name = "recordtypeid")
  @ManyToOne
  private RecordType recordType;
}
