package com.bat.petra.contractmngmt.serviceWrapper.model.json;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * @author arkadiusz.wronski, created on 2019-02-05.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class User {

  private String marketISO;
  private String sessionId;
  private String serviceType;
}
