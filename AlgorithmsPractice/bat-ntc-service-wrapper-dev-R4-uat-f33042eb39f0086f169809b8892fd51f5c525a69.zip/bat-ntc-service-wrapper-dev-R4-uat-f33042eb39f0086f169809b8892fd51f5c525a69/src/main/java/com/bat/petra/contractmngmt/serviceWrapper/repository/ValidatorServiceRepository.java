package com.bat.petra.contractmngmt.serviceWrapper.repository;

import com.bat.petra.contractmngmt.serviceWrapper.model.ValidatorService;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ValidatorServiceRepository extends JpaRepository<ValidatorService, Integer> {

  ValidatorService findByMarketIsoAndServiceTypeAndActiveAndRecordTypeName(String marketIso, String serviceType, boolean active, String recordTypeName);
}
