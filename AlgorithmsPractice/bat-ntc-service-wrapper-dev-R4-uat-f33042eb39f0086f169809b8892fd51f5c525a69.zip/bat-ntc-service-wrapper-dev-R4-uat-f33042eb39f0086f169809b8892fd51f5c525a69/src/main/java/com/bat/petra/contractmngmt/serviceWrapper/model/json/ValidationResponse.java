package com.bat.petra.contractmngmt.serviceWrapper.model.json;

import lombok.Data;

@Data
public class ValidationResponse {

  private User user;
}
