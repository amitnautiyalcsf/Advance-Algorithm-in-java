package com.bat.petra.contractmngmt.serviceWrapper.utils;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class DateValidationUtils {

  private DateValidationUtils() {}

  public static boolean validateIfExpired(LocalDateTime dateCreated, int numberOfSecondsToExpiration) {
    return validateIfExpired(ZonedDateTime.of(dateCreated, ZoneId.systemDefault()), numberOfSecondsToExpiration);
  }

  public static boolean validateIfExpired(ZonedDateTime dateCreated, int numberOfSecondsToExpiration) {

    ZonedDateTime expirationDate = dateCreated.plusSeconds(numberOfSecondsToExpiration);
    int result = ZonedDateTime.now().compareTo(expirationDate);

    return result <= 0;
  }
}
