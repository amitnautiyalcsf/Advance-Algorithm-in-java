package com.bat.petra.contractmngmt.serviceWrapper.service;

import com.bat.petra.contractmngmt.serviceWrapper.model.ValidatorService;
import com.bat.petra.contractmngmt.serviceWrapper.model.json.ValidationRequest;
import com.bat.petra.contractmngmt.serviceWrapper.repository.ValidatorServiceRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Jwts;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import reactor.util.function.Tuple2;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.AbstractMap;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ValidatorServiceService {

  private static final Logger LOGGER = LoggerFactory.getLogger(ValidatorServiceService.class);

  @Value("${validatorservice.recordtype.name}")
  private String recordTypeName;

  private final ObjectMapper objectMapper = new ObjectMapper();

  private final ValidatorServiceRepository validatorServiceRepository;

  private final WebClient webClient;

  private final KeyService keyService;

  public AbstractMap.SimpleEntry<Integer, String> validateRequest(Map<String, Object> request, HttpMethod method) {
    try {
      ValidationRequest validationRequest = objectMapper.convertValue(request, ValidationRequest.class);

      ValidatorService validatorService = getValidatorServiceForRequest(validationRequest);

      if (validatorService == null) {
        fillValidValueWrappers(request);
        AbstractMap.SimpleEntry<Integer, String> defaultResponse = new AbstractMap.SimpleEntry<>(HttpStatus.OK.value(), objectMapper.writeValueAsString(request));
        return defaultResponse;
      }

      String body = encodeRequestToJWT(objectMapper.writeValueAsString(request));
      LOGGER.info("Calling " + validatorService.getServiceAddress() + " with body " + body);

      Tuple2<Integer, String> responseTuple = webClient
          .method(method)
          .uri(validatorService.getServiceAddress())
          .contentType(MediaType.TEXT_PLAIN)
          .accept(MediaType.APPLICATION_JSON)
          .syncBody(body)
          .exchange()
          .flatMap(clientResponse -> Mono.zip(Mono.just(clientResponse.statusCode().value()),
              clientResponse.bodyToMono(String.class)))
          .block(getDuration(validatorService.getTimeout()));

      return new AbstractMap.SimpleEntry<>(responseTuple.getT1() != null ?
          responseTuple.getT1() : HttpStatus.SERVICE_UNAVAILABLE.value(),
          responseTuple.getT2());

    } catch (JsonProcessingException e) {
      throw new IllegalArgumentException(e);
    }

  }

  private void fillValidValueWrappers(Map<String, Object> request) {
    for (String parentKey : request.keySet()) {
      if (!"user".equals(parentKey) && request.get(parentKey) instanceof Map) {
        Map<String, Object> parentMap = (Map<String, Object>) request.get(parentKey);
        for (String key : parentMap.keySet()) {
          parentMap.put(key, wrapObject(parentMap.get(key)));
        }
      }
    }
  }

  private Map<String, Object> wrapObject(Object object) {
    Map<String, Object> wrapper = new LinkedHashMap<>();
    wrapper.put("value", object);
    wrapper.put("hasError", false);
    return wrapper;
  }

  private Duration getDuration(BigDecimal timeout) {
    return Duration.ofMillis(timeout.multiply(BigDecimal.valueOf(1000)).intValue());
  }

  private ValidatorService getValidatorServiceForRequest(ValidationRequest validationRequest) {
    String marketIso = validationRequest.getUser().getMarketISO();
    String serviceType = validationRequest.getUser().getServiceType();
    return validatorServiceRepository.findByMarketIsoAndServiceTypeAndActiveAndRecordTypeName(
        marketIso, serviceType, true, recordTypeName);
  }

  private String encodeRequestToJWT(String request) {
    return Jwts.builder().signWith(keyService.getPrivateKey()).setPayload(request).compact();
  }

}
