package com.bat.petra.contractmngmt.serviceWrapper.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "recordtype", schema = "salesforce")
@Data
public class RecordType {

  @Id
  @Column(name = "sfid")
  private String id;

  @Column(name = "name")
  private String name;
}
