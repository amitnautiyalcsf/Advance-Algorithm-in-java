package com.bat.petra.contractmngmt.serviceWrapper.service;

public interface MobileSessionVerificationService {

  boolean verifySessionIdWithSalesforceApi(String sessionId);
}
