package com.bat.petra.contractmngmt.serviceWrapper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceWrapperApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceWrapperApplication.class, args);
	}
}
