package com.bat.petra.contractmngmt.serviceWrapper.service;

import com.bat.petra.contractmngmt.serviceWrapper.model.SystemConfiguration;
import com.bat.petra.contractmngmt.serviceWrapper.model.SystemConfigurationKey;
import com.bat.petra.contractmngmt.serviceWrapper.repository.SystemConfigurationRepository;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

@Component
@RequiredArgsConstructor
public class KeyService implements ApplicationListener<ContextRefreshedEvent> {

  private static final Logger LOGGER = LoggerFactory.getLogger(KeyService.class);

  private final SystemConfigurationRepository systemConfigurationRepository;

  private KeyPair keyPair;

  @Override
  public void onApplicationEvent(ContextRefreshedEvent event) {
    if (systemConfigurationRepository.getByKey(SystemConfigurationKey.PUBLIC_KEY) == null
        || systemConfigurationRepository.getByKey(SystemConfigurationKey.PRIVATE_KEY) == null) {
      KeyPair keyPair = Keys.keyPairFor(SignatureAlgorithm.RS256);
      saveNewKey(SystemConfigurationKey.PRIVATE_KEY, keyPair.getPrivate().getEncoded());
      saveNewKey(SystemConfigurationKey.PUBLIC_KEY, keyPair.getPublic().getEncoded());
      this.keyPair = keyPair;
    } else {
      readKeyPairFromDb();
    }
  }

  private void readKeyPairFromDb() {
    try {
      KeyFactory keyFactory = KeyFactory.getInstance("RSA");
      this.keyPair = new KeyPair(decodePublicKey(keyFactory), decodePrivateKey(keyFactory));
    } catch (InvalidKeySpecException | NoSuchAlgorithmException e) {
      LOGGER.error("", e);
    }
  }

  private void saveNewKey(SystemConfigurationKey systemConfigurationKey, byte[] key) {
    systemConfigurationRepository.deleteByKey(systemConfigurationKey);
    systemConfigurationRepository.save(new SystemConfiguration(systemConfigurationKey,
        Base64.getEncoder().encodeToString(key)));
  }

  private PublicKey decodePublicKey(KeyFactory keyFactory) throws InvalidKeySpecException {
    String encodedKey = systemConfigurationRepository.getByKey(SystemConfigurationKey.PUBLIC_KEY).getValue();
    X509EncodedKeySpec keySpecX509 = new X509EncodedKeySpec(Base64.getDecoder().decode(encodedKey));
    return keyFactory.generatePublic(keySpecX509);
  }

  private PrivateKey decodePrivateKey(KeyFactory keyFactory) throws InvalidKeySpecException {
    String encodedKey = systemConfigurationRepository.getByKey(SystemConfigurationKey.PRIVATE_KEY).getValue();
    PKCS8EncodedKeySpec pkcs8EncodedKeySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(encodedKey));
    return keyFactory.generatePrivate(pkcs8EncodedKeySpec);
  }

  public PublicKey getPublicKey() {
    return keyPair.getPublic();
  }

  public PrivateKey getPrivateKey() {
    return keyPair.getPrivate();
  }
}
