package com.bat.petra.contractmngmt.serviceWrapper.service;

import org.springframework.web.client.HttpClientErrorException;

public interface SalesforceSessionVerificationService {

  boolean verifySessionIdWithDatabase(String sessionId);
  boolean verifySessionIdWithSalesforceApi(String sessionId) throws HttpClientErrorException;
  boolean verifySession(String sessionId) throws HttpClientErrorException;
}
