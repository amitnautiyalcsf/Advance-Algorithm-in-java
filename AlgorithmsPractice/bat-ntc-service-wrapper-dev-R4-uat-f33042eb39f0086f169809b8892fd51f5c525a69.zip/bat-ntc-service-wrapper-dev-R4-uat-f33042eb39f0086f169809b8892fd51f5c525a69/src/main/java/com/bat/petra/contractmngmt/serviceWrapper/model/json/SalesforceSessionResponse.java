package com.bat.petra.contractmngmt.serviceWrapper.model.json;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.time.ZonedDateTime;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SalesforceSessionResponse {

  @JsonProperty("LastModifiedDate")
  @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSZ")
  private ZonedDateTime lastModifiedDate;

  @JsonProperty("NumSecondsValid")
  private int validForSeconds;
}
