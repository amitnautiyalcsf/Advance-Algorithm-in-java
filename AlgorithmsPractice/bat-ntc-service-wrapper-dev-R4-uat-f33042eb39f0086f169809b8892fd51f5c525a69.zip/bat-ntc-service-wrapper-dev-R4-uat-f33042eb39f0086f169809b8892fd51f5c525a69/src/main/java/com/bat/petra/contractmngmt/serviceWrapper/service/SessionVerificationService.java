package com.bat.petra.contractmngmt.serviceWrapper.service;

import org.springframework.web.client.HttpClientErrorException;

import java.util.Map;

public interface SessionVerificationService {

  boolean verifySession(Map<String, Object> object) throws HttpClientErrorException;
  boolean isFromMobile(String sessionId);
}
