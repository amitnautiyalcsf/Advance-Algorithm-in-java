package com.bat.petra.contractmngmt.serviceWrapper.service.impl;

import com.bat.petra.contractmngmt.serviceWrapper.model.json.ValidationRequest;
import com.bat.petra.contractmngmt.serviceWrapper.service.MobileSessionVerificationService;
import com.bat.petra.contractmngmt.serviceWrapper.service.SalesforceSessionVerificationService;
import com.bat.petra.contractmngmt.serviceWrapper.service.SessionVerificationService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;

import java.util.Map;

@Service
public class SessionVerificationServiceImpl implements SessionVerificationService {

  private final ObjectMapper objectMapper = new ObjectMapper();

  @Autowired
  private MobileSessionVerificationService mobileSessionVerificationService;

  @Autowired
  private SalesforceSessionVerificationService salesforceSessionVerificationService;

  @Override
  public boolean verifySession(Map<String, Object> object) throws HttpClientErrorException {

    ValidationRequest validationRequest = objectMapper.convertValue(object, ValidationRequest.class);
    String sessionId = validationRequest.getUser().getSessionId();
    return isFromMobile(sessionId) ?
        mobileSessionVerificationService.verifySessionIdWithSalesforceApi(sessionId) :
        salesforceSessionVerificationService.verifySession(sessionId);
  }

  @Override
  public boolean isFromMobile(String sessionId) {

    return sessionId.length() > 18;
  }
}
