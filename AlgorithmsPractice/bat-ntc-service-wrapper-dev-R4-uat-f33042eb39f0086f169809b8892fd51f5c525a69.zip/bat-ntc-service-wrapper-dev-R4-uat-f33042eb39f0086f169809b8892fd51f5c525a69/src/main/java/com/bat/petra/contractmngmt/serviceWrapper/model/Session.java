package com.bat.petra.contractmngmt.serviceWrapper.model;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "authsession", schema = "salesforce")
@Data
public class Session implements Serializable {

  @Id
  @Column(name = "id")
  private Integer id;

  @Column(name = "sfid")
  private String sfid;

  @Column(name = "createddate")
  private String createdDate;

  @Column(name = "lastmodifieddate")
  private String lastModifiedDate;
}
