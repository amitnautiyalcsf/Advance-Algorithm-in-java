package com.bat.petra.contractmngmt.serviceWrapper.service.impl;

import com.bat.petra.contractmngmt.serviceWrapper.service.MobileSessionVerificationService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.Optional;

@Service
public class MobileSessionVerificationImpl implements MobileSessionVerificationService {

  @Value("${salesforce.api-url-new}")
  private String urlToApi;

  @Override
  public boolean verifySessionIdWithSalesforceApi(String sessionId) {

    WebClient webClient = WebClient.create();

    String response = webClient
        .get()
        .uri(urlToApi)
        .accept(MediaType.APPLICATION_JSON)
        .header("Authorization", "Bearer " + sessionId)
        .retrieve()
        .onStatus(httpStatus -> httpStatus.isError(), clientResponse -> Mono.empty())
        .bodyToMono(String.class)
        .block();

    return Optional.ofNullable(response).isPresent();
  }
}
