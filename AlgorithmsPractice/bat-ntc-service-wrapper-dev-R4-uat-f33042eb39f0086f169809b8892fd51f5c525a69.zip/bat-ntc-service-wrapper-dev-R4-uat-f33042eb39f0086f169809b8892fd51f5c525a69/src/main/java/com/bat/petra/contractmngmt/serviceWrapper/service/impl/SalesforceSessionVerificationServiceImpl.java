package com.bat.petra.contractmngmt.serviceWrapper.service.impl;

import com.bat.petra.contractmngmt.serviceWrapper.model.Session;
import com.bat.petra.contractmngmt.serviceWrapper.model.json.SalesforceSessionResponse;
import com.bat.petra.contractmngmt.serviceWrapper.repository.SessionRepository;
import com.bat.petra.contractmngmt.serviceWrapper.service.SalesforceSessionVerificationService;
import com.bat.petra.contractmngmt.serviceWrapper.utils.DateValidationUtils;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Map;
import java.util.Optional;

@Service
@Log4j2
public class SalesforceSessionVerificationServiceImpl implements SalesforceSessionVerificationService {

  private static final int NUMBER_OF_SECONDS_BEFORE_EXPIRATION = 7200;

  @Autowired
  private SessionRepository sessionRepository;

  @Value("${salesforce.client.id}")
  private String clientId;

  @Value("${salesforce.client.secret}")
  private String clientSecret;

  @Value("${salesforce.client.name}")
  private String clientName;

  @Value("${salesforce.client.password}")
  private String clientPassword;

  @Value("${salesforce.authorize-url}")
  private String urlToAuthorize;

  @Value("${salesforce.api-url}")
  private String urlToApi;

  @Override
  public boolean verifySessionIdWithDatabase(String sessionId) {

    Optional<Session> session = sessionRepository.findSessionBySfid(sessionId);

    if(session.isPresent()) {

      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
      LocalDateTime parsedCreatedDate = LocalDateTime.parse(session.get().getLastModifiedDate(), formatter);
      return DateValidationUtils.validateIfExpired(parsedCreatedDate, NUMBER_OF_SECONDS_BEFORE_EXPIRATION);

    } else {

      return false;
    }
  }

  @Override
  public boolean verifySessionIdWithSalesforceApi(String sessionId) throws HttpClientErrorException {

    RestTemplate restTemplate = new RestTemplate();
    String token = fetchToken();
    HttpHeaders headers = new HttpHeaders();
    headers.set("Accept", "application/json");
    headers.set("Authorization", "Bearer " + token);
    HttpEntity request = new HttpEntity(headers);
    ResponseEntity<SalesforceSessionResponse> response = restTemplate.exchange(
        urlToApi + sessionId, HttpMethod.GET, request, SalesforceSessionResponse.class
    );

    SalesforceSessionResponse body = response.getBody();

    if(Optional.ofNullable(body).isPresent()) {
      return verifyIfSessionIsNotExpired(body);
    } else {
      return false;
    }
  }

  @Override
  public boolean verifySession(String sessionId) throws HttpClientErrorException {

    return verifySessionIdWithDatabase(sessionId) || verifySessionIdWithSalesforceApi(sessionId);
  }

  private String fetchToken() throws HttpClientErrorException {

    RestTemplate restTemplate = new RestTemplate();

    UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromUriString(this.urlToAuthorize)
        .queryParam("grant_type", "password")
        .queryParam("client_id", this.clientId)
        .queryParam("client_secret", this.clientSecret)
        .queryParam("username", this.clientName)
        .queryParam("password", this.clientPassword);

    log.info("Calling " + urlToAuthorize);
    Map<String, String> response;

    response = restTemplate.postForObject(uriComponentsBuilder.toUriString(), "", Map.class);

    if(Optional.ofNullable(response).isPresent()) {
      log.info("Token granted");
      return response.get("access_token");

    } else {

      return "";
    }
  }

  private boolean verifyIfSessionIsNotExpired(SalesforceSessionResponse sessionResponse) {

    return DateValidationUtils.validateIfExpired(
      sessionResponse.getLastModifiedDate(), sessionResponse.getValidForSeconds()
    );
  }
}
