package com.bat.petra.contractmngmt.serviceWrapper.repository;

import com.bat.petra.contractmngmt.serviceWrapper.model.SystemConfiguration;
import com.bat.petra.contractmngmt.serviceWrapper.model.SystemConfigurationKey;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SystemConfigurationRepository extends JpaRepository<SystemConfiguration, Long> {

  SystemConfiguration getByKey(SystemConfigurationKey key);

  void deleteByKey(SystemConfigurationKey key);
}
