package com.bat.petra.contractmngmt.serviceWrapper.model;

import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@Data
@NoArgsConstructor
public class SystemConfiguration {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private long id;

  @Column(name = "key", nullable = false)
  @Enumerated(EnumType.STRING)
  private SystemConfigurationKey key;

  @Column(length = 2000)
  private String value;

  public SystemConfiguration(SystemConfigurationKey key, String value) {
    this.key = key;
    this.value = value;
  }
}
