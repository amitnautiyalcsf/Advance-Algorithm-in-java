package com.bat.petra.contractmngmt.serviceWrapper.model;

public enum SystemConfigurationKey {

  PUBLIC_KEY,

  PRIVATE_KEY
}
