package com.bat.petra.contractmngmt.serviceWrapper.controller;

import com.bat.petra.contractmngmt.serviceWrapper.service.KeyService;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Base64;

@RestController
@AllArgsConstructor
public class PublicKeyController {

  private final KeyService keyService;

  @GetMapping(value = "/publicKey", produces = MediaType.TEXT_PLAIN_VALUE)
  public String getPublicKey() {
    return "-----BEGIN RSA PUBLIC KEY-----\n" +
        Base64.getEncoder().encodeToString(keyService.getPublicKey().getEncoded()) +
        "\n-----END RSA PUBLIC KEY-----\n";
  }

  @GetMapping(value = "/publicKeyRaw", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
  public byte[] getPublicKeyRaw() {
    return keyService.getPublicKey().getEncoded();
  }

}
